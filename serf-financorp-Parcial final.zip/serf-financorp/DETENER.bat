@echo off
title SERF - Detener
taskkill /FI "WINDOWTITLE eq SERF - Servidor*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq SERF - Pantallas*" /T /F >nul 2>&1
echo.
echo  SERF se detuvo. Para volver a usarlo haga doble clic en INICIAR.bat
echo.
timeout /t 4 >nul
