# Guía rápida para ejecutar SERF (sin conocimientos de sistemas)

Esta guía es para **Windows**. Se hace **una sola vez** (pasos 1 a 4). Después, para usar el sistema,
basta con el paso 5.

---

## Paso 1. Instalar Python 3.12 (una sola vez)

1. Entre a **https://www.python.org/downloads/release/python-31210/**
2. Baje hasta el final y haga clic en **"Windows installer (64-bit)"**.
3. Abra el archivo descargado.
4. **Importante:** marque la casilla **"Add python.exe to PATH"** (abajo de la ventana).
5. Haga clic en **"Install Now"** y espere a que diga *Setup was successful*.

> Use la versión **3.12**. Las versiones más nuevas (3.14, 3.15) todavía no son compatibles.

## Paso 2. Instalar MySQL (una sola vez)

1. Entre a **https://dev.mysql.com/downloads/mysql/**
2. Elija la versión **8.4 LTS**, sistema **Microsoft Windows**, y descargue el **MSI Installer**.
   Si le pide iniciar sesión, haga clic en **"No thanks, just start my download"**.
3. Abra el archivo, acepte todo con **Next** y elija **Typical**.
4. Al terminar se abre el **MySQL Configurator**. Pulse **Next** en todas las pantallas, excepto en:
   * **Accounts and Roles:** escriba una contraseña para *root* y **anótela en un papel**.
   * **Sample Databases:** deje las casillas sin marcar.
5. En **Apply Configuration** pulse **Execute** y luego **Finish**.
6. Agregue MySQL al PATH:
   * Pulse la tecla Windows y escriba **variables de entorno** → abra *"Editar las variables de
     entorno del sistema"* → botón **Variables de entorno**.
   * Abajo, en *Variables del sistema*, seleccione **Path** → **Editar** → **Nuevo** y pegue:
     `C:\Program Files\MySQL\MySQL Server 8.4\bin`
   * Pulse **Aceptar** tres veces.

## Paso 3. Copiar el proyecto (una sola vez)

1. Descomprima el archivo **serf-financorp-python-mysql.zip** (clic derecho → *Extraer todo*).
2. Abra la carpeta **serf-financorp**. Debe ver los archivos **INSTALAR.bat**, **INICIAR.bat** y
   **DETENER.bat**.

## Paso 4. Instalar el sistema (una sola vez)

1. Haga **doble clic en INSTALAR.bat**.
   *Si Windows muestra "Windows protegió su PC", haga clic en **Más información** → **Ejecutar de todas formas**.*
2. Cuando le pida la contraseña, escriba la **contraseña de root** del paso 2 y pulse **Enter**
   (mientras escribe no se ve nada; es normal).
3. Espere 2 o 3 minutos hasta que aparezca **LISTO**. Pulse cualquier tecla para cerrar.

## Paso 5. Usar el sistema (cada vez)

1. Haga **doble clic en INICIAR.bat**.
2. Se abren **dos ventanas negras**: **no las cierre** mientras use el sistema.
3. A los pocos segundos se abre el navegador con SERF en **http://localhost:5500**.
   Si no se abre solo, escriba esa dirección en Chrome o Edge.

**Para terminar:** haga doble clic en **DETENER.bat** (o cierre las dos ventanas negras).

---

## ¿Qué puedo hacer en el sistema?

| Pantalla | Para qué sirve |
|---|---|
| **Panel** | Ver ventas, ingresos y alertas de stock de todas las filiales en euros |
| **Productos** | Registrar productos importados desde China (costo en yuanes) |
| **Ventas** | Registrar una venta; el sistema descuenta el stock y convierte a euros |
| **Reportes** | Generar un reporte mensual, trimestral o anual con un clic, con marca de agua y firma digital |
| **Filiales** | Agregar una nueva filial (país) |
| **Configuración** | Cambiar los tipos de cambio y la marca de agua |

## Si algo sale mal

| Lo que ve | Qué hacer |
|---|---|
| "Falta Python 3.12" | Repita el paso 1 y marque **"Add python.exe to PATH"**. |
| "No se encontró MySQL" | Repita el punto 6 del paso 2 (agregar al PATH) y reinicie la PC. |
| "No se pudo crear la base de datos" | La contraseña de root no es correcta. Vuelva a ejecutar INSTALAR.bat. |
| La página dice "No se pudo conectar con la API" | Una ventana negra se cerró. Haga doble clic en DETENER.bat y luego en INICIAR.bat. |
| La ventana "SERF - Servidor" muestra "Can't connect to MySQL" | MySQL está apagado: tecla Windows → **Servicios** → **MySQL84** → **Iniciar**. |
