@echo off
title SERF - Iniciando
cd /d "%~dp0"
if not exist backend\.venv\Scripts\python.exe (
    echo.
    echo  Primero haga doble clic en INSTALAR.bat
    echo.
    pause
    exit /b 1
)
echo.
echo  Iniciando SERF... se abriran 2 ventanas negras: NO LAS CIERRE mientras use el sistema.
echo.
start "SERF - Servidor (no cerrar)" /D "%~dp0backend" cmd /k ".venv\Scripts\python.exe -m uvicorn app.main:app --port 8000"
start "SERF - Pantallas (no cerrar)" /D "%~dp0frontend" cmd /k "..\backend\.venv\Scripts\python.exe -m http.server 5500"
timeout /t 8 /nobreak >nul
start "" "http://localhost:5500"
exit /b 0
