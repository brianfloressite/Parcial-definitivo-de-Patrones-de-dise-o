/* Configuración usada dentro de Docker: nginx reenvía /api al backend, así que la API está en el mismo origen. */
window.SERF_CONFIG = {
    apiUrl: "",
};
