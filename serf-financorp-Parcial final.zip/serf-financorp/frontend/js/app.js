/* SERF · FinanCorp S.A. — frontend (JavaScript sin dependencias).
   Consume la API REST del backend Python/FastAPI (datos en MySQL). Toda la lógica de negocio vive en el
   servidor; la URL de la API se define en js/config.js. */
(() => {
    "use strict";

    const estado = { config: null, filiales: [], reporteActual: null, cssReporte: null };
    const $ = (sel, raiz = document) => raiz.querySelector(sel);
    const contenido = $("#contenido");

    if (new URLSearchParams(location.search).has("wireframe")) document.body.classList.add("wf");

    // ------------------------------------------------------------ utilidades
    const h = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    const SIMBOLO = { EUR: "€", PEN: "S/", USD: "US$", CNY: "¥", MXN: "MX$", COP: "COL$" };
    const dinero = (n, moneda = "EUR", dec) => {
        const d = dec ?? (moneda === "COP" ? 0 : 2);
        return `${SIMBOLO[moneda] ?? moneda} ${Number(n).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d })}`;
    };
    const compacto = (n) => Number(n).toLocaleString("en-US", { notation: "compact", maximumFractionDigits: 1 });
    const fecha = (iso) => { const [a, m, d] = iso.split("-"); return `${d}/${m}/${a}`; };
    const hoy = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

    const API_URL = String(window.SERF_CONFIG?.apiUrl ?? "").replace(/\/$/, "");

    async function api(ruta, opciones = {}) {
        let resp;
        try {
            resp = await fetch(`${API_URL}/api${ruta}`, {
                headers: { "Content-Type": "application/json", Accept: "application/json" },
                ...opciones,
                body: opciones.body ? JSON.stringify(opciones.body) : undefined,
            });
        } catch {
            throw new Error(`No se pudo conectar con la API (${API_URL || location.origin}). Verifique que el backend esté en ejecución.`);
        }
        const datos = resp.status === 204 ? null : await resp.json().catch(() => null);
        if (!resp.ok) throw new Error(datos?.mensaje ?? `Error ${resp.status}`);
        return datos;
    }

    function avisar(texto, tipo = "") {
        const el = document.createElement("div");
        el.className = `aviso ${tipo}`;
        el.textContent = texto;
        $("#avisos").append(el);
        setTimeout(() => el.remove(), 4200);
    }

    // ------------------------------------------------------- pizarra de cambio
    async function cargarConfiguracion(resaltar) {
        estado.config = await api("/configuracion");
        $("#moneda-corp").textContent = estado.config.monedaCorporativa;
        $("#pizarra-tasas").innerHTML = Object.entries(estado.config.tasas)
            .filter(([m]) => m !== estado.config.monedaCorporativa)
            .map(([m, t]) => `<li class="${m === resaltar ? "cambio" : ""}"><b>${h(m)}</b><span>${Number(t).toLocaleString("en-US", { maximumFractionDigits: 4 })}</span></li>`)
            .join("");
    }

    // ------------------------------------------------------------ enrutador
    const VISTAS = {
        panel: { titulo: "Panel", sub: "Resumen consolidado de todas las filiales", render: vistaPanel },
        productos: { titulo: "Productos importados", sub: "Catálogo e inventario por filial", render: vistaProductos },
        ventas: { titulo: "Ventas", sub: "Transacciones de las filiales convertidas a moneda corporativa", render: vistaVentas },
        reportes: { titulo: "Reportes financieros", sub: "Genera reportes corporativos listos para enviar", render: vistaReportes },
        filiales: { titulo: "Filiales", sub: "Sedes que consolidan información en SERF", render: vistaFiliales },
        configuracion: { titulo: "Configuración corporativa", sub: "Parámetros únicos para todo el sistema", render: vistaConfiguracion },
    };

    async function navegar() {
        const nombre = location.hash.replace("#/", "") || "panel";
        const vista = VISTAS[nombre] ?? VISTAS.panel;
        document.querySelectorAll(".lateral nav a").forEach((a) => { if (a.dataset.vista !== nombre) a.removeAttribute("aria-current"); else a.setAttribute("aria-current", "page"); });
        $("#titulo-vista").textContent = vista.titulo;
        $("#subtitulo-vista").textContent = vista.sub;
        document.title = `${vista.titulo} · SERF`;
        contenido.innerHTML = `<p class="vacio">Cargando…</p>`;
        try {
            await vista.render();
        } catch (e) {
            contenido.innerHTML = `<div class="error-form">No se pudo cargar la información: ${h(e.message)}. Verifica que el servidor esté en ejecución.</div>`;
        }
        contenido.focus({ preventScroll: true });
    }

    // ------------------------------------------------------------------ panel
    async function vistaPanel() {
        const d = await api("/dashboard");
        const maxPais = Math.max(...d.ingresosPorPais.map((x) => x.valor), 1);
        const maxMes = Math.max(...d.ingresosPorMes.map((x) => x.valor), 1);
        contenido.innerHTML = `
        <dl class="franja-kpi">
            <div class="kpi principal-kpi"><dt>Ingresos ${new Date().getFullYear() > 2026 ? 2026 : new Date().getFullYear()}</dt><dd>${dinero(d.ingresosAnio)}</dd><small>${d.ventasAnio} ventas en ${d.filiales} filiales</small></div>
            <div class="kpi"><dt>Margen bruto</dt><dd>${dinero(d.margenAnio)}</dd><small>${(d.margenAnio / d.ingresosAnio * 100 || 0).toFixed(1)}% sobre ingresos</small></div>
            <div class="kpi"><dt>${h(d.etiquetaUltimoMes)}</dt><dd>${dinero(d.ingresosUltimoMes)}</dd><small>Ingresos del último mes con ventas</small></div>
            <div class="kpi"><dt>Inventario valorizado</dt><dd>${dinero(d.inventarioValorizado)}</dd><small>${d.unidadesEnStock.toLocaleString("en-US")} unidades · ${d.productos} productos</small></div>
        </dl>
        <div class="dos-columnas">
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Ingresos por mes</h2><span class="enlace">${d.monedaCorporativa}</span></div>
                <div class="bloque-cuerpo"><div class="columnas" role="img" aria-label="Ingresos mensuales">
                    ${d.ingresosPorMes.map((m) => `<div class="columna" title="${h(m.etiqueta)}: ${dinero(m.valor)}"><span style="height:${(m.valor / maxMes * 100).toFixed(1)}%"></span><small>${h(m.etiqueta.slice(0, 3))}</small></div>`).join("")}
                </div></div>
            </section>
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Ingresos por país</h2><a href="#/reportes">Generar reporte</a></div>
                <div class="bloque-cuerpo barras">
                    ${d.ingresosPorPais.map((p) => `<div class="barra-fila"><span>${h(p.etiqueta)}</span><div class="barra-pista"><div class="barra-relleno" style="width:${(p.valor / maxPais * 100).toFixed(1)}%"></div></div><strong>€ ${compacto(p.valor)}</strong></div>`).join("")}
                </div>
            </section>
        </div>
        <div class="dos-columnas">
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Últimas ventas</h2><a href="#/ventas">Ver todas</a></div>
                <div class="bloque-cuerpo tabla-envoltura">${tablaVentas(d.ultimasVentas, true)}</div>
            </section>
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Stock por reponer</h2><span class="chip bajo">${d.productosStockBajo} producto(s)</span></div>
                <div class="bloque-cuerpo">
                    ${d.alertasStock.length ? `<ul class="lista-alertas">${d.alertasStock.map((p) => `<li><span>${h(p.nombre)}<br><small class="chip">${h(p.codigoFilial)}</small></span><strong>${p.stock} u.</strong></li>`).join("")}</ul>` : `<p class="vacio">Todo el inventario está sobre el umbral mínimo.</p>`}
                </div>
            </section>
        </div>`;
    }

    // -------------------------------------------------------------- productos
    async function vistaProductos() {
        const filtro = new URLSearchParams(location.hash.split("?")[1] ?? "").get("filial") ?? "";
        const productos = await api(`/productos${filtro ? `?filial=${encodeURIComponent(filtro)}` : ""}`);
        contenido.innerHTML = `
        <div class="fila-acciones">
            <div class="campo"><label for="f-filial">Filial</label>${selectorFiliales("f-filial", filtro, true)}</div>
            <div class="crece"></div>
            <button class="boton" id="btn-nuevo-producto" type="button">Registrar producto</button>
        </div>
        <section class="bloque"><div class="bloque-cuerpo tabla-envoltura">
            ${productos.length ? `<table class="datos">
                <thead><tr><th>Producto</th><th class="ocultar-movil">Categoría</th><th class="num ocultar-movil">Costo importación</th><th class="num">Precio sugerido</th><th class="num">Stock</th></tr></thead>
                <tbody>${productos.map((p) => `<tr>
                    <td><strong>${h(p.nombre)}</strong><small>${h(p.codigo)} · ${h(p.proveedor)}</small></td>
                    <td class="ocultar-movil">${h(p.categoriaEtiqueta)}</td>
                    <td class="num ocultar-movil">${dinero(p.costoImportacion, "CNY")}<small>≈ ${dinero(p.costoCorporativo)}</small></td>
                    <td class="num">${dinero(p.precioVentaSugerido, p.monedaLocal)}</td>
                    <td class="num"><span class="chip ${p.stockBajo ? "bajo" : "ok"}">${p.stock}</span></td>
                </tr>`).join("")}</tbody></table>` : `<p class="vacio">No hay productos en esta filial. Registra el primer lote importado.</p>`}
        </div></section>`;
        $("#f-filial").addEventListener("change", (e) => (location.hash = `#/productos${e.target.value ? `?filial=${e.target.value}` : ""}`));
        $("#btn-nuevo-producto").addEventListener("click", formularioProducto);
    }

    function selectorFiliales(id, seleccion = "", conTodas = false) {
        return `<select id="${id}" name="${id}">${conTodas ? `<option value="">Todas las filiales</option>` : ""}
            ${estado.filiales.map((f) => `<option value="${h(f.codigo)}" ${f.codigo === seleccion ? "selected" : ""}>${h(f.pais)} (${h(f.moneda)})</option>`).join("")}</select>`;
    }

    function formularioProducto() {
        abrirCajon("Registrar producto importado", `
        <form id="form-producto" novalidate>
            <div class="error-form" hidden></div>
            <div class="rejilla">
                <div class="campo"><label for="codigo">Código</label><input id="codigo" name="codigo" required placeholder="PE-SMP-010" autocomplete="off"></div>
                <div class="campo"><label for="codigoFilial">Filial que recibe el lote</label>${selectorFiliales("codigoFilial")}</div>
                <div class="campo ancho"><label for="nombre">Nombre</label><input id="nombre" name="nombre" required placeholder="Smartphone modelo X"></div>
                <div class="campo ancho"><label for="descripcionTecnica">Descripción técnica</label><textarea id="descripcionTecnica" name="descripcionTecnica" rows="2" placeholder="Pantalla, memoria, almacenamiento…"></textarea></div>
                <div class="campo"><label for="categoria">Categoría</label><select id="categoria" name="categoria"><option value="LAPTOP">Laptop</option><option value="SMARTPHONE">Smartphone</option><option value="ACCESORIO">Accesorio</option><option value="REDES">Equipo de redes</option></select></div>
                <div class="campo"><label for="proveedor">Proveedor</label><input id="proveedor" name="proveedor" required placeholder="Fabricante en Shenzhen"></div>
                <div class="campo"><label for="costoImportacionCny">Costo de importación (CNY)</label><input id="costoImportacionCny" name="costoImportacionCny" type="number" min="0.01" step="0.01" required inputmode="decimal"><span class="ayuda" id="ayuda-costo">Se convierte a EUR con la tasa vigente</span></div>
                <div class="campo"><label for="precioVentaSugerido">Precio sugerido (<span id="moneda-local">PEN</span>)</label><input id="precioVentaSugerido" name="precioVentaSugerido" type="number" min="0.01" step="0.01" required inputmode="decimal"></div>
                <div class="campo"><label for="fechaImportacion">Fecha de importación</label><input id="fechaImportacion" name="fechaImportacion" type="date" max="${hoy()}" value="${hoy()}" required></div>
                <div class="campo"><label for="stockInicial">Stock inicial</label><input id="stockInicial" name="stockInicial" type="number" min="0" step="1" required inputmode="numeric"></div>
            </div>
            <div class="cajon-pie"><button class="boton secundario" type="button" data-cerrar>Cancelar</button><button class="boton" type="submit">Registrar producto</button></div>
        </form>`);
        const form = $("#form-producto");
        const actualizarMoneda = () => ($("#moneda-local").textContent = estado.filiales.find((f) => f.codigo === form.codigoFilial.value)?.moneda ?? "");
        form.codigoFilial.addEventListener("change", actualizarMoneda);
        actualizarMoneda();
        form.costoImportacionCny.addEventListener("input", async (e) => {
            const v = Number(e.target.value);
            $("#ayuda-costo").textContent = v > 0 ? `≈ ${dinero((await api(`/configuracion/convertir?monto=${v}&moneda=CNY`)).montoConvertido)} con la tasa vigente` : "Se convierte a EUR con la tasa vigente";
        });
        enviarFormulario(form, async (datos) => {
            const p = await api("/productos", { method: "POST", body: { ...datos, costoImportacionCny: num(datos.costoImportacionCny), precioVentaSugerido: num(datos.precioVentaSugerido), stockInicial: int(datos.stockInicial) } });
            avisar(`Producto ${p.codigo} registrado con ${p.stock} unidades`, "ok");
            location.hash = `#/productos?filial=${p.codigoFilial}`;
            navegar();
        });
    }

    const num = (v) => (v === "" ? null : Number(v));
    const int = (v) => (v === "" ? null : parseInt(v, 10));

    // ----------------------------------------------------------------- ventas
    async function vistaVentas() {
        const filtro = new URLSearchParams(location.hash.split("?")[1] ?? "").get("filial") ?? "";
        const ventas = await api(`/ventas${filtro ? `?filial=${encodeURIComponent(filtro)}` : ""}`);
        const total = ventas.reduce((s, v) => s + v.totalCorporativo, 0);
        contenido.innerHTML = `
        <div class="fila-acciones">
            <div class="campo"><label for="f-filial">Filial</label>${selectorFiliales("f-filial", filtro, true)}</div>
            <p class="crece" style="margin:0 0 10px;color:var(--tenue)">${ventas.length} ventas · ${dinero(total)} en moneda corporativa</p>
            <button class="boton" id="btn-nueva-venta" type="button">Registrar venta</button>
        </div>
        <section class="bloque"><div class="bloque-cuerpo tabla-envoltura">${tablaVentas(ventas.slice(0, 120))}</div></section>`;
        $("#f-filial").addEventListener("change", (e) => (location.hash = `#/ventas${e.target.value ? `?filial=${e.target.value}` : ""}`));
        $("#btn-nueva-venta").addEventListener("click", () => formularioVenta(filtro));
    }

    function tablaVentas(ventas, compacta = false) {
        if (!ventas.length) return `<p class="vacio">Aún no hay ventas registradas.</p>`;
        return `<table class="datos"><thead><tr><th>Factura</th><th>Producto</th>${compacta ? "" : `<th class="ocultar-movil">Cliente</th><th class="num ocultar-movil">Importe local</th>`}<th class="num">Total EUR</th></tr></thead>
            <tbody>${ventas.map((v) => `<tr>
                <td><strong>${h(v.numeroFactura)}</strong><small>${fecha(v.fecha)} · ${h(v.codigoFilial)}</small></td>
                <td>${h(v.nombreProducto)}<small>${v.cantidad} u. · ${h(v.metodoPago)}</small></td>
                ${compacta ? "" : `<td class="ocultar-movil">${h(v.cliente)}<small>${h(v.vendedor)}</small></td><td class="num ocultar-movil">${dinero(v.totalLocal, v.monedaLocal)}<small>tasa ${Number(v.tasaAplicada).toLocaleString("en-US", { maximumFractionDigits: 4 })}</small></td>`}
                <td class="num"><strong>${dinero(v.totalCorporativo)}</strong></td>
            </tr>`).join("")}</tbody></table>`;
    }

    async function formularioVenta(filialInicial) {
        const filial = filialInicial || estado.filiales[0]?.codigo;
        abrirCajon("Registrar venta", `
        <form id="form-venta" novalidate>
            <div class="error-form" hidden></div>
            <div class="rejilla">
                <div class="campo"><label for="filial">Filial</label>${selectorFiliales("filial", filial)}</div>
                <div class="campo"><label for="numeroFactura">N.º de factura</label><input id="numeroFactura" name="numeroFactura" required placeholder="F001-000123" autocomplete="off"></div>
                <div class="campo ancho"><label for="codigoProducto">Producto</label><select id="codigoProducto" name="codigoProducto"></select><span class="ayuda" id="ayuda-stock"></span></div>
                <div class="campo"><label for="cantidad">Cantidad</label><input id="cantidad" name="cantidad" type="number" min="1" step="1" value="1" required inputmode="numeric"></div>
                <div class="campo"><label for="precioUnitario">Precio unitario (<span id="moneda-venta"></span>)</label><input id="precioUnitario" name="precioUnitario" type="number" min="0.01" step="0.01" required inputmode="decimal"></div>
                <div class="campo"><label for="fecha">Fecha</label><input id="fecha" name="fecha" type="date" max="${hoy()}" value="${hoy()}" required></div>
                <div class="campo"><label for="metodoPago">Método de pago</label><select id="metodoPago" name="metodoPago"><option value="EFECTIVO">Efectivo</option><option value="TARJETA" selected>Tarjeta</option><option value="TRANSFERENCIA">Transferencia</option></select></div>
                <div class="campo"><label for="cliente">Cliente</label><input id="cliente" name="cliente" required></div>
                <div class="campo"><label for="vendedor">Vendedor responsable</label><input id="vendedor" name="vendedor" required></div>
            </div>
            <div class="resumen-conversion" id="resumen-conversion" aria-live="polite"></div>
            <div class="cajon-pie"><button class="boton secundario" type="button" data-cerrar>Cancelar</button><button class="boton" type="submit">Confirmar venta</button></div>
        </form>`);
        const form = $("#form-venta");
        let productos = [];
        const moneda = () => estado.filiales.find((f) => f.codigo === form.filial.value)?.moneda ?? "EUR";
        const productoSel = () => productos.find((p) => p.codigo === form.codigoProducto.value);

        async function cargarProductos() {
            productos = (await api(`/productos?filial=${form.filial.value}`)).filter((p) => p.stock > 0);
            form.codigoProducto.innerHTML = productos.map((p) => `<option value="${h(p.codigo)}">${h(p.nombre)} — ${p.stock} disponibles</option>`).join("") || `<option value="">Sin productos con stock</option>`;
            $("#moneda-venta").textContent = moneda();
            elegirProducto();
        }
        function elegirProducto() {
            const p = productoSel();
            form.precioUnitario.value = p ? p.precioVentaSugerido : "";
            form.cantidad.max = p?.stock ?? 1;
            $("#ayuda-stock").textContent = p ? `Stock disponible: ${p.stock} u. · Precio sugerido ${dinero(p.precioVentaSugerido, p.monedaLocal)}` : "";
            previsualizar();
        }
        async function previsualizar() {
            const p = productoSel();
            const cant = Number(form.cantidad.value), precio = Number(form.precioUnitario.value);
            const caja = $("#resumen-conversion");
            if (!p || !(cant > 0) || !(precio > 0)) { caja.innerHTML = `<span class="tenue">Completa producto, cantidad y precio para ver el total.</span>`; return; }
            const totalLocal = cant * precio;
            const c = await api(`/configuracion/convertir?monto=${totalLocal}&moneda=${moneda()}`);
            const excede = cant > p.stock;
            caja.innerHTML = `<span>Total en ${moneda()}</span><strong>${dinero(totalLocal, moneda())}</strong>
                <span>Equivalente corporativo</span><strong>${dinero(c.montoConvertido)}</strong>
                <span class="tenue">${excede ? `⚠ La cantidad supera el stock disponible (${p.stock} u.). La venta será rechazada.` : `Tasa aplicada: 1 EUR = ${Number(c.tasa)} ${moneda()} · Stock tras la venta: ${p.stock - cant} u.`}</span>`;
        }
        form.filial.addEventListener("change", cargarProductos);
        form.codigoProducto.addEventListener("change", elegirProducto);
        form.cantidad.addEventListener("input", previsualizar);
        form.precioUnitario.addEventListener("input", previsualizar);
        await cargarProductos();

        enviarFormulario(form, async (d) => {
            const v = await api("/ventas", { method: "POST", body: { numeroFactura: d.numeroFactura, fecha: d.fecha, codigoProducto: d.codigoProducto, cantidad: int(d.cantidad), precioUnitario: num(d.precioUnitario), cliente: d.cliente, vendedor: d.vendedor, metodoPago: d.metodoPago } });
            avisar(`Venta ${v.numeroFactura} registrada: ${dinero(v.totalCorporativo)}. Stock actualizado.`, "ok");
            location.hash = `#/ventas?filial=${v.codigoFilial}`;
            navegar();
        });
    }

    // --------------------------------------------------------------- reportes
    async function vistaReportes() {
        const [historial, plantillas] = await Promise.all([api("/reportes"), api("/reportes/plantillas")]);
        const ahora = new Date();
        // Por defecto se propone el último mes cerrado (el mes en curso aún no tiene la información completa).
        const cierre = new Date(ahora.getFullYear(), ahora.getMonth() - 1, 1);
        const anio = cierre.getFullYear();
        const mes = cierre.getMonth() + 1;
        contenido.innerHTML = `
        <div class="generador">
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Nuevo reporte</h2></div>
                <form class="bloque-cuerpo" id="form-reporte" novalidate>
                    <div class="error-form" hidden></div>
                    <fieldset class="tipos" style="border:0;padding:0;margin:0 0 14px">
                        <legend class="campo" style="margin-bottom:6px"><label>Tipo de reporte</label></legend>
                        ${plantillas.map((p, i) => `<label class="tipo-opcion"><input type="radio" name="tipo" value="${h(p.tipo)}" ${i === 0 ? "checked" : ""}><span><strong>${h(p.nombre)}</strong><span>${h(p.descripcion)}</span></span></label>`).join("")}
                    </fieldset>
                    <div class="rejilla">
                        <div class="campo"><label for="anio">Año</label><select id="anio" name="anio">${[...new Set([ahora.getFullYear(), anio, anio - 1])].map((a) => `<option ${a === anio ? "selected" : ""}>${a}</option>`).join("")}</select></div>
                        <div class="campo" id="campo-mes"><label for="mes">Mes</label><select id="mes" name="mes">${["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"].map((m, i) => `<option value="${i + 1}" ${i + 1 === mes ? "selected" : ""}>${m}</option>`).join("")}</select></div>
                        <div class="campo" id="campo-trimestre" hidden><label for="trimestre">Trimestre</label><select id="trimestre" name="trimestre">${[1, 2, 3, 4].map((t) => `<option value="${t}" ${t === Math.ceil(mes / 3) ? "selected" : ""}>T${t}</option>`).join("")}</select></div>
                        <div class="campo ancho"><label for="codigoFilial">Alcance</label><select id="codigoFilial" name="codigoFilial"><option value="">Consolidado (todas)</option>${estado.filiales.map((f) => `<option value="${h(f.codigo)}">Solo ${h(f.pais)}</option>`).join("")}</select></div>
                        <div class="campo ancho"><label for="autor">Elaborado por</label><input id="autor" name="autor" value="Área de Contabilidad" required></div>
                    </div>
                    <p class="campo" style="margin:16px 0 6px"><label>Protección del documento</label></p>
                    <div class="capas">
                        <label><input type="checkbox" name="confidencial" checked> Franja de confidencialidad</label>
                        <label><input type="checkbox" name="marcaAgua" checked> Marca de agua corporativa</label>
                        <label><input type="checkbox" name="firmaDigital" checked> Firma digital (RSA + SHA-256)</label>
                    </div>
                    <button class="boton grande" type="submit">Generar reporte</button>
                </form>
            </section>
            <div style="display:grid;gap:20px">
                <section class="bloque">
                    <div class="bloque-cabecera"><h2>Reportes emitidos</h2><span class="chip">${historial.length}</span></div>
                    <div class="bloque-cuerpo">${historial.length ? historial.map((r) => `
                        <article class="historial-item">
                            <div><h3>${h(r.titulo)} · ${h(r.periodo)}</h3><p>${h(r.alcance)} · ${h(r.fechaGeneracion)} · ${h(r.autor)}</p>
                            <div class="capas-fila" style="margin-top:6px">${r.capas.slice(1).map((c) => `<span class="chip ${c === "Firma digital" ? "ok" : ""}">${h(c)}</span>`).join("")}</div></div>
                            <div><button class="boton secundario" type="button" data-abrir="${h(r.id)}">Abrir</button></div>
                        </article>`).join("") : `<p class="vacio">Todavía no se han emitido reportes. Elige un tipo y período, y genera el primero.</p>`}</div>
                </section>
                <section class="bloque">
                    <div class="bloque-cabecera"><h2>Qué hace el sistema al generar</h2></div>
                    <div class="bloque-cuerpo"><ol class="flujo">
                        <li>Lee moneda, tasas y formato de la <b>configuración única</b> (Singleton).</li>
                        <li>Consolida ventas, costos e inventario de las filiales en EUR.</li>
                        <li>Clona la <b>plantilla base</b> del tipo elegido y la adapta al país (Prototype).</li>
                        <li>Arma el reporte <b>paso a paso</b>: indicadores, tablas, gráficos y conclusiones (Builder).</li>
                        <li>Organiza <b>secciones y subsecciones</b> por país y categoría (Composite).</li>
                        <li>Añade confidencialidad, marca de agua y <b>firma digital</b> sin alterar el contenido (Decorator).</li>
                        <li>Todo lo anterior ocurre con <b>una sola acción</b> desde esta pantalla (Facade).</li>
                    </ol></div>
                </section>
            </div>
        </div>`;
        const form = $("#form-reporte");
        const ajustarPeriodo = () => {
            const tipo = form.tipo.value;
            $("#campo-mes").hidden = tipo !== "MENSUAL_INGRESOS";
            $("#campo-trimestre").hidden = tipo !== "TRIMESTRAL_GASTOS_INGRESOS";
        };
        form.addEventListener("change", ajustarPeriodo);
        ajustarPeriodo();
        contenido.querySelectorAll("[data-abrir]").forEach((b) => b.addEventListener("click", async () => abrirVisor(await api(`/reportes/${b.dataset.abrir}`))));
        enviarFormulario(form, async (d) => {
            const r = await api("/reportes", { method: "POST", body: {
                tipo: form.tipo.value, anio: int(d.anio), mes: int(d.mes), trimestre: int(d.trimestre),
                codigoFilial: d.codigoFilial, autor: d.autor, formato: "HTML",
                marcaAgua: form.marcaAgua.checked, confidencial: form.confidencial.checked, firmaDigital: form.firmaDigital.checked } });
            avisar(`Reporte ${r.id} generado`, "ok");
            await vistaReportes();
            abrirVisor(r);
        });
    }

    // ------------------------------------------------------------------ visor
    function abrirVisor(r) {
        estado.reporteActual = r;
        $("#visor-titulo").textContent = `${r.titulo} · ${r.periodo}`;
        $("#visor-estado").className = "visor-estado";
        $("#visor-estado").innerHTML = "";
        $("#visor-hoja").innerHTML = r.tipoContenido === "text/html" ? `<div class="hoja">${r.contenido}</div>` : `<pre class="hoja">${h(r.contenido)}</pre>`;
        const firmado = "firma.valor" in r.metadatos;
        $("#btn-verificar").hidden = !firmado;
        $("#btn-alterar").hidden = !firmado;
        $("#visor").hidden = false;
        $("#visor [data-cerrar-visor]").focus();
    }
    function mostrarVerificacion(v) {
        const el = $("#visor-estado");
        el.className = `visor-estado ${v.valido ? "valido" : "invalido"}`;
        el.innerHTML = `${v.valido ? "✔" : "✖"} ${h(v.mensaje)}<code>Hash registrado: ${h(v.hashRegistrado)}<br>Hash calculado: ${h(v.hashCalculado ?? "—")}</code>`;
    }
    $("#btn-verificar").addEventListener("click", async () => mostrarVerificacion(await api(`/reportes/${estado.reporteActual.id}/verificar`)));
    $("#btn-alterar").addEventListener("click", async () => mostrarVerificacion(await api(`/reportes/${estado.reporteActual.id}/verificar-alterado`, { method: "POST" })));
    $("#btn-imprimir").addEventListener("click", () => window.print());
    $("#btn-descargar").addEventListener("click", async () => {
        const r = estado.reporteActual;
        estado.cssReporte ??= await fetch("css/reporte.css").then((x) => x.text());
        const html = r.tipoContenido === "text/html"
            ? `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${h(r.titulo)} ${h(r.periodo)}</title><style>body{margin:0;background:#eef1f4}.hoja{max-width:900px;margin:24px auto;background:#fff}${estado.cssReporte}</style></head><body><div class="hoja">${r.contenido}</div></body></html>`
            : r.contenido;
        const enlace = Object.assign(document.createElement("a"), {
            href: URL.createObjectURL(new Blob([html], { type: r.tipoContenido })),
            download: `SERF_${r.tipo}_${r.periodo.replace(/\s+/g, "_")}_${r.id}.${r.tipoContenido === "text/html" ? "html" : "txt"}`,
        });
        enlace.click();
        URL.revokeObjectURL(enlace.href);
    });
    $("#visor [data-cerrar-visor]").addEventListener("click", () => ($("#visor").hidden = true));

    // --------------------------------------------------------------- filiales
    async function vistaFiliales() {
        estado.filiales = await api("/filiales");
        contenido.innerHTML = `
        <div class="fila-acciones"><p class="crece" style="margin:0;color:var(--tenue)">Una nueva filial empieza a operar y a consolidarse sin cambios en el sistema.</p><button class="boton" id="btn-nueva-filial" type="button">Registrar filial</button></div>
        <section class="bloque"><div class="bloque-cuerpo tabla-envoltura"><table class="datos">
            <thead><tr><th>Filial</th><th>Ciudad</th><th>Moneda local</th><th class="num">1 EUR equivale a</th></tr></thead>
            <tbody>${estado.filiales.map((f) => `<tr><td><strong>${h(f.nombre)}</strong> ${f.sedeCentral ? `<span class="chip sede">Sede central</span>` : ""}<small>${h(f.codigo)} · ${h(f.pais)}</small></td><td>${h(f.ciudad)}</td><td>${h(f.moneda)}</td><td class="num">${Number(estado.config.tasas[f.moneda]).toLocaleString("en-US", { maximumFractionDigits: 4 })} ${h(f.moneda)}</td></tr>`).join("")}</tbody>
        </table></div></section>`;
        $("#btn-nueva-filial").addEventListener("click", () => {
            abrirCajon("Registrar filial", `
            <form id="form-filial" novalidate>
                <div class="error-form" hidden></div>
                <div class="rejilla">
                    <div class="campo"><label for="codigo">Código de país</label><input id="codigo" name="codigo" maxlength="3" required placeholder="CL"><span class="ayuda">2 o 3 letras</span></div>
                    <div class="campo"><label for="moneda">Moneda local</label><select id="moneda" name="moneda">${Object.keys(estado.config.tasas).map((m) => `<option>${m}</option>`).join("")}</select></div>
                    <div class="campo ancho"><label for="nombre">Nombre</label><input id="nombre" name="nombre" required placeholder="FinanCorp Chile"></div>
                    <div class="campo"><label for="pais">País</label><input id="pais" name="pais" required></div>
                    <div class="campo"><label for="ciudad">Ciudad</label><input id="ciudad" name="ciudad" required></div>
                </div>
                <div class="cajon-pie"><button class="boton secundario" type="button" data-cerrar>Cancelar</button><button class="boton" type="submit">Registrar filial</button></div>
            </form>`);
            enviarFormulario($("#form-filial"), async (d) => {
                const f = await api("/filiales", { method: "POST", body: d });
                avisar(`${f.nombre} registrada`, "ok");
                navegar();
            });
        });
    }

    // ---------------------------------------------------------- configuración
    async function vistaConfiguracion() {
        await cargarConfiguracion();
        const c = estado.config;
        contenido.innerHTML = `
        <div class="dos-columnas">
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Tipos de cambio</h2><span class="tenue-texto">Actualizado ${h(c.ultimaActualizacion)}</span></div>
                <div class="bloque-cuerpo tabla-envoltura"><table class="datos medio">
                    <thead><tr><th>Moneda</th><th class="num">Unidades por 1 ${h(c.monedaCorporativa)}</th><th></th></tr></thead>
                    <tbody>${Object.entries(c.tasas).map(([m, t]) => `<tr><td><strong>${h(m)}</strong></td>
                        <td class="num">${m === c.monedaCorporativa ? "1 (base)" : `<input aria-label="Tasa ${h(m)}" data-moneda="${h(m)}" type="number" step="0.0001" min="0.0001" value="${Number(t)}" style="width:130px;text-align:right;border:1px solid var(--linea);border-radius:6px;padding:6px 8px">`}</td>
                        <td class="num">${m === c.monedaCorporativa ? "" : `<button class="boton secundario" type="button" data-guardar="${h(m)}">Guardar</button>`}</td></tr>`).join("")}</tbody>
                </table></div>
            </section>
            <section class="bloque">
                <div class="bloque-cabecera"><h2>Documento</h2></div>
                <form class="bloque-cuerpo" id="form-marca" novalidate>
                    <div class="error-form" hidden></div>
                    <div class="campo"><label for="texto">Texto de la marca de agua</label><input id="texto" name="texto" maxlength="60" value="${h(c.textoMarcaAgua)}"></div>
                    <div class="campo" style="margin-top:12px"><label>Firmante autorizado</label><input value="${h(c.firmante)}" disabled></div>
                    <button class="boton" type="submit" style="margin-top:16px">Guardar marca de agua</button>
                    <p style="color:var(--tenue);font-size:13px;margin:18px 0 0">Todos los módulos leen estos valores de una única instancia de configuración (id ${c.identidadInstancia}). Un cambio aquí se refleja de inmediato en ventas, conversiones y reportes, y queda guardado en la base de datos.</p>
                </form>
            </section>
        </div>
        <section class="bloque" style="margin-top:20px">
            <div class="bloque-cabecera"><h2>Base de datos y pool de conexiones</h2><span class="tenue-texto">Singleton · una sola instancia por servidor</span></div>
            <div class="bloque-cuerpo" id="estado-bd"><p class="tenue-texto">Consultando…</p></div>
        </section>`;
        api("/sistema/salud").then((s) => {
            const p = s.pool;
            const fila = (k, v) => `<div><dt>${h(k)}</dt><dd>${h(v ?? "—")}</dd></div>`;
            $("#estado-bd").innerHTML = `<dl class="ficha-bd">${fila("Motor", `${p.motor} ${s.versionBaseDatos}`)}${fila("Base de datos", `${p.baseDatos} @ ${p.servidor}`)}${fila("Tipo de pool", p.tipoPool)}${fila("Conexiones en el pool", p.tamano)}${fila("En uso ahora", p.enUso)}${fila("Identidad de la instancia", p.identidadInstancia)}</dl>
                <p style="color:var(--tenue);font-size:13px;margin:14px 0 0">Las conexiones a MySQL se reutilizan: cada petición toma una del pool y la devuelve al terminar.</p>`;
        }).catch((e) => { $("#estado-bd").innerHTML = `<p class="error-form">${h(e.message)}</p>`; });
        contenido.querySelectorAll("[data-guardar]").forEach((b) => b.addEventListener("click", async () => {
            const m = b.dataset.guardar;
            try {
                await api(`/configuracion/tasas/${m}`, { method: "PUT", body: { tasa: Number(contenido.querySelector(`[data-moneda="${m}"]`).value) } });
                await cargarConfiguracion(m);
                avisar(`Tasa de ${m} actualizada para todo el sistema`, "ok");
            } catch (e) { avisar(e.message, "error"); }
        }));
        enviarFormulario($("#form-marca"), async (d) => {
            await api("/configuracion/marca-agua", { method: "PUT", body: { texto: d.texto } });
            avisar("Marca de agua actualizada", "ok");
        }, false);
    }

    // ------------------------------------------------------- cajón y formularios
    function abrirCajon(titulo, html) {
        $("#cajon-titulo").textContent = titulo;
        $("#cajon-cuerpo").innerHTML = html;
        $("#cajon").hidden = false;
        $("#velo").hidden = false;
        setTimeout(() => $("#cajon-cuerpo input, #cajon-cuerpo select")?.focus(), 50);
    }
    function cerrarCajon() {
        $("#cajon").hidden = true;
        $("#velo").hidden = true;
    }
    document.addEventListener("click", (e) => { if (e.target.closest("[data-cerrar]") || e.target.id === "velo") cerrarCajon(); });
    document.addEventListener("keydown", (e) => {
        if (e.key !== "Escape") return;
        if (!$("#cajon").hidden) cerrarCajon(); else $("#visor").hidden = true;
    });

    function enviarFormulario(form, accion, cerrar = true) {
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const caja = form.querySelector(".error-form");
            caja.hidden = true;
            form.querySelectorAll(".campo").forEach((c) => c.classList.remove("invalido"));
            const faltantes = [...form.querySelectorAll("[required]")].filter((i) => !String(i.value).trim());
            if (faltantes.length) {
                faltantes.forEach((i) => i.closest(".campo")?.classList.add("invalido"));
                caja.textContent = `Completa los campos obligatorios: ${faltantes.map((i) => form.querySelector(`label[for="${i.id}"]`)?.textContent.replace(/\s*\(.*\)/, "")).join(", ")}.`;
                caja.hidden = false;
                faltantes[0].focus();
                return;
            }
            const boton = form.querySelector("[type=submit]");
            boton.disabled = true;
            try {
                await accion(Object.fromEntries(new FormData(form)));
                if (cerrar) cerrarCajon();
            } catch (err) {
                caja.textContent = err.message;
                caja.hidden = false;
            } finally {
                boton.disabled = false;
            }
        });
    }

    // ---------------------------------------------------------------- inicio
    async function iniciar() {
        try {
            await cargarConfiguracion();
            estado.filiales = await api("/filiales");
        } catch (e) {
            contenido.innerHTML = `<div class="error-form">No hay conexión con el servidor SERF. Inícialo con <code>mvn spring-boot:run</code> y recarga la página.</div>`;
            return;
        }
        window.addEventListener("hashchange", navegar);
        navegar();
    }
    iniciar();
})();
