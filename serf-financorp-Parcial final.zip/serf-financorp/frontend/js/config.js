/* Configuración del frontend SERF.
   apiUrl: dirección del backend FastAPI. En desarrollo local es http://localhost:8000.
   Con Docker se reemplaza este archivo por uno con apiUrl = "" (nginx reenvía /api al backend). */
window.SERF_CONFIG = {
    apiUrl: "http://localhost:8000",
};
