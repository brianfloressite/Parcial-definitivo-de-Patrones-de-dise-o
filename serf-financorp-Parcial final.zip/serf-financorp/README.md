# SERF · FinanCorp S.A. — Python + MySQL

Sistema Empresarial de Gestión de Reportes Financieros. Integra las ventas e inventarios de las filiales de
FinanCorp (Perú, España, México y Colombia), convierte todo a la moneda corporativa (EUR) y genera reportes
financieros con secciones jerárquicas, marca de agua y firma digital RSA.

| Capa | Tecnología | Carpeta |
|---|---|---|
| Frontend | HTML5 + CSS + JavaScript (SPA responsive, sin dependencias) | `frontend/` |
| Backend (API REST) | Python 3.11+ · FastAPI · SQLAlchemy 2 · Pydantic 2 | `backend/` |
| Base de datos | MySQL 8 (InnoDB, utf8mb4) | `database/` |
| Pruebas | pytest (108 pruebas, 93 % de cobertura) | `backend/tests/` |
| Documentación | UML (PlantUML fuente + PNG/SVG), capturas, resultados de pruebas | `docs/` |

## Patrones de diseño aplicados

| Patrón | Dónde | Qué resuelve del caso |
|---|---|---|
| **Singleton** | `config/configuracion_global.py`, `persistencia/pool_conexiones.py` (`config/singleton.py`) | Configuración corporativa única (moneda, tasas, formato) y **un solo pool de conexiones a MySQL** por servidor |
| **Prototype** | `reporte/prototype/plantillas.py` | Plantillas base de reporte clonadas en profundidad y adaptadas a cada país |
| **Builder** | `reporte/builder/reporte.py`, `director.py` | Reportes complejos construidos paso a paso con API fluida; HTML o texto con el mismo producto |
| **Composite** | `reporte/composite/componentes.py` | Secciones y subsecciones con anidamiento ilimitado (tablas, gráficos SVG, KPI) |
| **Decorator** | `reporte/decorator/documentos.py`, `reporte/firma/firmador.py` | Confidencialidad, marca de agua y firma digital SHA256withRSA sin tocar el reporte |
| **Facade** | `reporte/facade/generador.py` | `generar_reporte(solicitud)`: una sola llamada que integra todo lo anterior |

Además: **Unidad de Trabajo + Repositorios** (`servicio/puertos.py`, `persistencia/`) para que cada venta sea
atómica (`SELECT … FOR UPDATE` + `COMMIT`/`ROLLBACK`), y principios SOLID (servicios con una
responsabilidad, puertos abstractos, inyección por constructor en `api/contenedor.py`).

## Estructura

```
serf-python/
├── backend/
│   ├── app/
│   │   ├── api/            # FastAPI: rutas, esquemas JSON, errores, contenedor (Composition Root)
│   │   ├── config/         # Singleton: SingletonMeta, ConfiguracionGlobal, ajustes de entorno
│   │   ├── datos/          # carga de datos de demostración
│   │   ├── dominio/        # Producto, Venta, Filial, Dinero, enums, excepciones
│   │   ├── persistencia/   # PoolConexiones (Singleton), modelos ORM, repositorios, unidad de trabajo
│   │   ├── reporte/        # prototype · builder · composite · decorator · firma · facade
│   │   ├── servicio/       # casos de uso, puertos (interfaces), conversión, consolidación
│   │   └── main.py         # aplicación FastAPI
│   ├── tests/              # pytest (SQLite por defecto o MySQL con SERF_TEST_MYSQL_URL)
│   ├── requirements.txt · requirements-dev.txt · .env.example · Dockerfile
├── frontend/               # index.html, css/, js/app.js, js/config.js, Dockerfile (nginx)
├── database/               # crear_bd.sql (base y usuario) · schema.sql (tablas)
├── docs/                   # uml/ (puml + png + svg) · capturas/ · pruebas/
└── docker-compose.yml      # MySQL + backend + frontend
```

## Para usuarios sin conocimientos técnicos (Windows)

Siga la **[GUIA_RAPIDA.md](GUIA_RAPIDA.md)**: instale Python 3.12 y MySQL, y luego haga doble clic en
**INSTALAR.bat** (una sola vez) e **INICIAR.bat** (cada vez que use el sistema). **DETENER.bat** lo apaga.

> Use **Python 3.12 o 3.13**. Con Python 3.14/3.15 algunas librerías aún no tienen versión compatible y la instalación falla.

## Opción A — Ejecutar con Docker (recomendada)

Requisitos: Docker Desktop.

```bash
docker compose up --build
```

* Frontend: http://localhost:8080
* API y documentación interactiva (Swagger): http://localhost:8000/docs

La primera vez se crean las tablas y se cargan los datos de demostración (4 filiales, 16 productos y ~140
ventas de enero a octubre de 2026). Los datos quedan en el volumen `mysql_datos`.

## Opción B — Ejecutar en local (paso a paso)

Requisitos: **Python 3.11 a 3.13** (recomendado 3.12), **MySQL 8** (o MariaDB 10.6+) y un navegador.

### 1. Base de datos

```bash
mysql -u root -p < database/crear_bd.sql      # (en PowerShell: Get-Content database\crear_bd.sql | mysql -u root -p) crea la base "serf" y el usuario serf/serf
mysql -u serf -p serf < database/schema.sql   # opcional: la API crea las tablas que falten al arrancar
```

### 2. Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate      Linux/macOS: source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env                     # Windows: copy .env.example .env  — ajuste usuario/clave de MySQL
uvicorn app.main:app --reload --port 8000
```

Compruebe http://localhost:8000/api/sistema/salud (debe mostrar la versión de MySQL y el estado del pool).

### 3. Frontend (en otra terminal)

```bash
cd frontend
python -m http.server 5500
```

Abra http://localhost:5500. La dirección de la API se configura en `frontend/js/config.js`
(`apiUrl: "http://localhost:8000"`); el backend acepta ese origen por CORS (`SERF_CORS_ORIGINS`).

## Pruebas

```bash
cd backend
pytest                                   # 107 pruebas sobre SQLite en memoria (~7 s)
pytest --cov=app                         # con cobertura (requiere pytest-cov)

# Toda la suite contra MySQL real (base de pruebas vacía), incluida la prueba de ventas concurrentes:
mysql -u root -p -e "CREATE DATABASE serf_test CHARACTER SET utf8mb4; GRANT ALL ON serf_test.* TO 'serf'@'%';"
SERF_TEST_MYSQL_URL="mysql+pymysql://serf:serf@localhost:3306/serf_test?charset=utf8mb4" pytest
```

| Archivo | Qué prueba |
|---|---|
| `test_singleton.py` | instancia única (50 hilos), sin copias ni pickle, validación de tasas, pool único |
| `test_prototype.py` | clones independientes, copia profunda, adaptación por país, registro extensible |
| `test_builder.py` | API fluida, pasos y secciones obligatorias, builder de un solo uso, HTML vs texto |
| `test_composite.py` | anidamiento ilimitado, trato uniforme, ciclos, escape HTML |
| `test_decorator.py` | orden de capas, LSP, firma válida/alterada, clave persistente |
| `test_facade.py` | flujo completo del caso, historial en BD, verificación de integridad |
| `test_dominio.py` | encapsulamiento y reglas de `Dinero`, `Producto`, `Venta`, `Filial` |
| `test_servicios.py` | venta del caso (100 smartphones en PEN → EUR), stock, ROLLBACK atómico, consolidación |
| `test_api.py` | contrato JSON, códigos 201/400/404/409, CORS |
| `test_mysql_concurrencia.py` | dos ventas simultáneas de las últimas unidades: una pasa, la otra no; stock ≥ 0 |

Resultados guardados en `docs/pruebas/` (JUnit XML).

## API REST

| Método | Ruta | Descripción |
|---|---|---|
| GET/POST | `/api/filiales` | Listar / registrar filial |
| GET/POST | `/api/productos[?filial=PE]` · GET `/api/productos/{codigo}` | Catálogo e inventario |
| GET/POST | `/api/ventas[?filial=PE]` | Ventas (descuenta stock y convierte a EUR) |
| POST | `/api/reportes` | Genera un reporte con la fachada |
| GET | `/api/reportes` · `/api/reportes/{id}` · `/api/reportes/plantillas` | Historial y plantillas |
| GET / POST | `/api/reportes/{id}/verificar` · `/api/reportes/{id}/verificar-alterado` | Integridad de la firma |
| GET · PUT | `/api/configuracion` · `/tasas/{moneda}` · `/marca-agua` · GET `/convertir` | Singleton de configuración |
| GET | `/api/dashboard` | Panel consolidado |
| GET | `/api/sistema/salud` | Conexión a MySQL y estado del pool |

Ejemplo:

```bash
curl -X POST http://localhost:8000/api/reportes -H "Content-Type: application/json" \
     -d '{"tipo":"MENSUAL_INGRESOS","anio":2026,"mes":10,"marcaAgua":true,"confidencial":true,"firmaDigital":true}'
```

## Variables de entorno (`backend/.env`)

| Variable | Por defecto | Uso |
|---|---|---|
| `MYSQL_HOST` / `MYSQL_PORT` / `MYSQL_DATABASE` / `MYSQL_USER` / `MYSQL_PASSWORD` | localhost / 3306 / serf / serf / serf | Conexión |
| `SERF_DATABASE_URL` | — | URL completa (tiene prioridad) |
| `SERF_POOL_SIZE` / `SERF_POOL_MAX_OVERFLOW` / `SERF_POOL_RECYCLE` | 5 / 10 / 1800 | Pool de conexiones |
| `SERF_CORS_ORIGINS` | localhost:5500, :8080 | Orígenes del frontend |
| `SERF_CLAVE_FIRMA` | `claves/serf_firma_privada.pem` | Clave RSA (se genera sola; no se sube a git) |
| `SERF_CARGAR_DEMO` | true | Carga datos de demostración si la base está vacía |

## Diagramas UML

`docs/uml/*.puml` (fuente PlantUML, importable en StarUML con la extensión PlantUML) y `docs/uml/png`, `docs/uml/svg`:
casos de uso, arquitectura, dominio, los seis patrones, secuencias de reporte y de venta, actividad,
modelo de datos MySQL y despliegue.

## Equipo

| Integrante | Rol |
|---|---|
| [Integrante 1] | Líder técnico · backend y patrones |
| [Integrante 2] | Backend · base de datos MySQL |
| [Integrante 3] | Diseño UX/UI · wireframes y frontend |
| [Integrante 4] | Calidad · pruebas |

Curso: Patrones de Diseño de Software — Escuela de Tecnología, Zegel.
