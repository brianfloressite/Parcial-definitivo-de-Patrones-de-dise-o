-- =====================================================================
-- SERF · FinanCorp S.A. — Esquema MySQL 8 (generado desde app/persistencia/modelos.py)
-- Uso:  mysql -u root -p < database/crear_bd.sql
--       mysql -u serf -p serf < database/schema.sql
-- La API también crea las tablas que falten al arrancar.
-- =====================================================================
SET NAMES utf8mb4;


-- Filiales de FinanCorp; cada una opera en su moneda local
CREATE TABLE filial (
	codigo VARCHAR(3) NOT NULL, 
	nombre VARCHAR(80) NOT NULL, 
	pais VARCHAR(60) NOT NULL, 
	ciudad VARCHAR(60) NOT NULL, 
	moneda_local VARCHAR(3) NOT NULL, 
	sede_central BOOL NOT NULL, 
	creado_en DATETIME NOT NULL DEFAULT (now()), 
	PRIMARY KEY (codigo)
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Filiales de FinanCorp; cada una opera en su moneda local' COLLATE utf8mb4_unicode_ci;

-- Parámetros corporativos editables (marca de agua, etc.)
CREATE TABLE parametro (
	clave VARCHAR(40) NOT NULL, 
	valor VARCHAR(255) NOT NULL, 
	PRIMARY KEY (clave)
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Parámetros corporativos editables (marca de agua, etc.)' COLLATE utf8mb4_unicode_ci;

-- Historial de reportes emitidos (trazabilidad, RNF08)
CREATE TABLE reporte (
	id VARCHAR(8) NOT NULL, 
	titulo VARCHAR(150) NOT NULL, 
	tipo VARCHAR(30) NOT NULL, 
	periodo VARCHAR(40) NOT NULL, 
	alcance VARCHAR(120) NOT NULL, 
	autor VARCHAR(80) NOT NULL, 
	fecha_generacion VARCHAR(20) NOT NULL, 
	tipo_contenido VARCHAR(20) NOT NULL, 
	contenido LONGTEXT NOT NULL, 
	metadatos JSON NOT NULL, 
	capas JSON NOT NULL, 
	firmado BOOL NOT NULL, 
	creado_en DATETIME(6) NOT NULL, 
	PRIMARY KEY (id)
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Historial de reportes emitidos (trazabilidad, RNF08)' COLLATE utf8mb4_unicode_ci;
CREATE INDEX ix_reporte_creado ON reporte (creado_en);

-- Tipos de cambio vigentes: unidades de moneda por 1 EUR
CREATE TABLE tasa_cambio (
	moneda VARCHAR(3) NOT NULL, 
	unidades_por_euro NUMERIC(18, 6) NOT NULL, 
	actualizado_en DATETIME NOT NULL, 
	PRIMARY KEY (moneda), 
	CONSTRAINT ck_tasa_positiva CHECK (unidades_por_euro > 0)
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Tipos de cambio vigentes: unidades de moneda por 1 EUR' COLLATE utf8mb4_unicode_ci;

-- Productos importados desde China e inventario por filial
CREATE TABLE producto (
	codigo VARCHAR(20) NOT NULL, 
	nombre VARCHAR(120) NOT NULL, 
	descripcion_tecnica VARCHAR(255) NOT NULL, 
	categoria VARCHAR(20) NOT NULL, 
	costo_importacion NUMERIC(18, 2) NOT NULL, 
	moneda_costo VARCHAR(3) NOT NULL, 
	precio_venta_sugerido NUMERIC(18, 2) NOT NULL, 
	moneda_precio VARCHAR(3) NOT NULL, 
	proveedor VARCHAR(80) NOT NULL, 
	fecha_importacion DATE NOT NULL, 
	codigo_filial VARCHAR(3) NOT NULL, 
	stock_inicial INTEGER NOT NULL, 
	stock INTEGER NOT NULL, 
	creado_en DATETIME NOT NULL DEFAULT (now()), 
	PRIMARY KEY (codigo), 
	CONSTRAINT ck_producto_stock_no_negativo CHECK (stock >= 0), 
	CONSTRAINT ck_producto_stock_inicial CHECK (stock_inicial >= 0), 
	CONSTRAINT ck_producto_costo_positivo CHECK (costo_importacion > 0), 
	CONSTRAINT ck_producto_precio_positivo CHECK (precio_venta_sugerido > 0), 
	FOREIGN KEY(codigo_filial) REFERENCES filial (codigo) ON DELETE RESTRICT
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Productos importados desde China e inventario por filial' COLLATE utf8mb4_unicode_ci;
CREATE INDEX ix_producto_filial ON producto (codigo_filial);

-- Ventas confirmadas con su conversión a moneda corporativa (RN08)
CREATE TABLE venta (
	numero_factura VARCHAR(30) NOT NULL, 
	fecha DATE NOT NULL, 
	codigo_producto VARCHAR(20) NOT NULL, 
	nombre_producto VARCHAR(120) NOT NULL, 
	categoria VARCHAR(20) NOT NULL, 
	codigo_filial VARCHAR(3) NOT NULL, 
	cantidad INTEGER NOT NULL, 
	precio_unitario NUMERIC(18, 2) NOT NULL, 
	moneda_local VARCHAR(3) NOT NULL, 
	cliente VARCHAR(120) NOT NULL, 
	vendedor VARCHAR(80) NOT NULL, 
	metodo_pago VARCHAR(15) NOT NULL, 
	total_corporativo NUMERIC(18, 2) NOT NULL, 
	moneda_corporativa VARCHAR(3) NOT NULL, 
	tasa_aplicada NUMERIC(18, 6) NOT NULL, 
	costo_importacion_corporativo NUMERIC(18, 2) NOT NULL, 
	creado_en DATETIME NOT NULL DEFAULT (now()), 
	PRIMARY KEY (numero_factura), 
	CONSTRAINT ck_venta_cantidad_positiva CHECK (cantidad > 0), 
	FOREIGN KEY(codigo_producto) REFERENCES producto (codigo) ON DELETE RESTRICT, 
	FOREIGN KEY(codigo_filial) REFERENCES filial (codigo) ON DELETE RESTRICT
)ENGINE=InnoDB CHARSET=utf8mb4 COMMENT='Ventas confirmadas con su conversión a moneda corporativa (RN08)' COLLATE utf8mb4_unicode_ci;
CREATE INDEX ix_venta_fecha ON venta (fecha);
CREATE INDEX ix_venta_filial_fecha ON venta (codigo_filial, fecha);
