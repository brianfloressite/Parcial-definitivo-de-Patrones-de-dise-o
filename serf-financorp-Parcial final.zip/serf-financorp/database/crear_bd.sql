-- =====================================================================
-- SERF · FinanCorp S.A. — Creación de la base de datos y del usuario de la aplicación (MySQL 8)
-- Ejecutar como administrador:   mysql -u root -p < database/crear_bd.sql
-- Cambie la contraseña 'serf' en entornos reales y póngala en backend/.env (MYSQL_PASSWORD).
-- =====================================================================
CREATE DATABASE IF NOT EXISTS serf CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'serf'@'%' IDENTIFIED BY 'serf';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON serf.* TO 'serf'@'%';
FLUSH PRIVILEGES;
