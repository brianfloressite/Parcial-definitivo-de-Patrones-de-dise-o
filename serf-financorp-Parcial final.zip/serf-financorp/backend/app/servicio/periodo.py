"""Período contable de un reporte (mensual, trimestral o anual)."""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date

# Nombres fijos: no dependen del locale del sistema, así los reportes son reproducibles en cualquier máquina.
MESES = ("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
         "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")


def nombre_mes(mes: int) -> str:
    return MESES[mes - 1]


def parsear_fecha(texto: str | None, campo: str) -> date:
    """Fechas ISO (AAAA-MM-DD) con mensajes claros para el usuario (RN13)."""
    if isinstance(texto, date):
        return texto
    if texto is None or not str(texto).strip():
        raise ValueError(f"La {campo} es obligatoria")
    try:
        return date.fromisoformat(str(texto).strip())
    except ValueError:
        raise ValueError(f"La {campo} debe tener el formato AAAA-MM-DD") from None


@dataclass(frozen=True)
class Periodo:
    desde: date
    hasta: date
    etiqueta: str

    def __post_init__(self) -> None:
        if not isinstance(self.desde, date):
            raise ValueError("La fecha inicial es obligatoria")
        if not isinstance(self.hasta, date):
            raise ValueError("La fecha final es obligatoria")
        if self.hasta < self.desde:
            raise ValueError("El período es inválido: la fecha final es anterior a la inicial")

    @classmethod
    def mensual(cls, anio: int, mes: int) -> "Periodo":
        cls._validar_anio(anio)
        if not 1 <= int(mes) <= 12:
            raise ValueError("El mes debe estar entre 1 y 12")
        ultimo = calendar.monthrange(anio, mes)[1]
        return cls(date(anio, mes, 1), date(anio, mes, ultimo), f"{nombre_mes(mes)} {anio}")

    @classmethod
    def trimestral(cls, anio: int, trimestre: int) -> "Periodo":
        cls._validar_anio(anio)
        if not 1 <= int(trimestre) <= 4:
            raise ValueError("El trimestre debe estar entre 1 y 4")
        mes_inicial = (trimestre - 1) * 3 + 1
        mes_final = mes_inicial + 2
        return cls(date(anio, mes_inicial, 1), date(anio, mes_final, calendar.monthrange(anio, mes_final)[1]),
                   f"T{trimestre} {anio}")

    @classmethod
    def anual(cls, anio: int) -> "Periodo":
        cls._validar_anio(anio)
        return cls(date(anio, 1, 1), date(anio, 12, 31), f"Año {anio}")

    @staticmethod
    def _validar_anio(anio: int) -> None:
        actual = date.today().year
        if anio is None or not 2000 <= int(anio) <= actual:
            raise ValueError(f"El año debe estar entre 2000 y {actual}")
