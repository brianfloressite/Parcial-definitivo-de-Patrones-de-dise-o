"""Sincroniza el Singleton ConfiguracionGlobal con MySQL (tasas y marca de agua persisten entre reinicios)."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from ..config.configuracion_global import ConfiguracionGlobal
from ..dominio import Moneda
from .puertos import UnidadDeTrabajo, transaccion

PARAM_MARCA_AGUA = "texto_marca_agua"


class ConfiguracionService:
    """El Singleton valida y guarda el valor en memoria; este servicio lo persiste en la misma operación.
    Así el Singleton no depende de la base de datos (DIP) y la base es la copia durable."""

    def __init__(self, uow: UnidadDeTrabajo, configuracion: ConfiguracionGlobal) -> None:
        self._uow = uow
        self._config = configuracion

    def cargar_desde_bd(self) -> None:
        """Al arrancar: si la BD tiene valores, se aplican al Singleton; si está vacía, se siembran."""
        guardadas = self._uow.configuracion.tasas()
        with transaccion(self._uow):
            for moneda, valor in self._config.tasas.items():
                if moneda is self._config.moneda_corporativa:
                    continue
                if moneda in guardadas:
                    tasa, fecha = guardadas[moneda]
                    self._config.actualizar_tasa(moneda, tasa, fecha)
                else:
                    self._uow.configuracion.guardar_tasa(moneda, valor, self._config.ultima_actualizacion_tasas)
            parametros = self._uow.configuracion.parametros()
            if PARAM_MARCA_AGUA in parametros:
                self._config.texto_marca_agua = parametros[PARAM_MARCA_AGUA]
            else:
                self._uow.configuracion.guardar_parametro(PARAM_MARCA_AGUA, self._config.texto_marca_agua)

    def actualizar_tasa(self, moneda: str, unidades_por_euro: object) -> Decimal:
        moneda_enum = Moneda.desde_texto(moneda)
        anterior = self._config.tasa(moneda_enum)
        ahora = datetime.now()
        valor = self._config.actualizar_tasa(moneda_enum, unidades_por_euro, ahora)   # valida
        try:
            with transaccion(self._uow):
                self._uow.configuracion.guardar_tasa(moneda_enum, valor, ahora)
        except Exception:
            self._config.actualizar_tasa(moneda_enum, anterior)                       # deshace en memoria
            raise
        return valor

    def actualizar_marca_agua(self, texto: str) -> str:
        anterior = self._config.texto_marca_agua
        self._config.texto_marca_agua = texto                                            # valida
        try:
            with transaccion(self._uow):
                self._uow.configuracion.guardar_parametro(PARAM_MARCA_AGUA, self._config.texto_marca_agua)
        except Exception:
            self._config.texto_marca_agua = anterior
            raise
        return self._config.texto_marca_agua
