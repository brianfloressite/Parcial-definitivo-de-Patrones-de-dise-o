"""Datos de entrada de los casos de uso (independientes de la capa web)."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


@dataclass(frozen=True)
class SolicitudRegistroProducto:
    """CU01 – registrar un producto importado. El costo viene en CNY y el precio en moneda local."""
    codigo: str | None
    nombre: str | None
    descripcion_tecnica: str | None
    categoria: str | None
    costo_importacion_cny: Decimal | None
    precio_venta_sugerido: Decimal | None
    proveedor: str | None
    fecha_importacion: str | None
    codigo_filial: str | None
    stock_inicial: int | None


@dataclass(frozen=True)
class SolicitudRegistroVenta:
    """CU03 – registrar una venta en la filial dueña del producto."""
    numero_factura: str | None
    fecha: str | None
    codigo_producto: str | None
    cantidad: int | None
    precio_unitario: Decimal | None
    cliente: str | None
    vendedor: str | None
    metodo_pago: str | None
