"""Conversión de importes a la moneda corporativa (contrato + implementación con el Singleton)."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal

from ..config.configuracion_global import ConfiguracionGlobal
from ..dominio import Dinero


@dataclass(frozen=True)
class ResultadoConversion:
    """Conversión trazable (RN08): importe original, convertido, tasa (unidades por 1 EUR) y fecha."""
    original: Dinero
    convertido: Dinero
    tasa: Decimal
    fecha_referencia: datetime


class ConversorMoneda(ABC):
    """ISP: una sola responsabilidad. Ventas y reportes dependen de esta abstracción, no del Singleton
    (DIP), así se puede cambiar la fuente de tasas (p. ej. un servicio del BCRP) sin tocarlos."""

    @abstractmethod
    def a_corporativa(self, importe: Dinero) -> ResultadoConversion: ...


class ConversorMonedaCorporativo(ConversorMoneda):
    """Obtiene las tasas del Singleton ``ConfiguracionGlobal``."""

    def __init__(self, configuracion: ConfiguracionGlobal) -> None:
        self._config = configuracion

    def a_corporativa(self, importe: Dinero) -> ResultadoConversion:
        if not isinstance(importe, Dinero):
            raise ValueError("El importe a convertir es obligatorio")
        if importe.es_negativo():
            raise ValueError("No se pueden convertir importes negativos")
        destino = self._config.moneda_corporativa
        tasa = self._config.tasa(importe.moneda)
        monto = importe.monto if importe.moneda is destino else (importe.monto / tasa).quantize(
            Decimal("0.000001"), rounding=ROUND_HALF_UP)
        return ResultadoConversion(importe, Dinero(monto, destino), tasa, self._config.ultima_actualizacion_tasas)
