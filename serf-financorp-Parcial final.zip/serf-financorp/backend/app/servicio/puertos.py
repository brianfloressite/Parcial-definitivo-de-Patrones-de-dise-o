"""Puertos de persistencia (abstracciones). Los servicios dependen de estas interfaces y no de MySQL (DIP).

Cada interfaz expone solo las operaciones que el negocio usa (ISP). La implementación concreta con
SQLAlchemy + MySQL está en ``app/persistencia/repositorios``; en las pruebas se usa la misma con SQLite.

``UnidadDeTrabajo`` agrupa los repositorios que comparten una misma transacción: una venta descuenta
stock y se registra *atómicamente* — si algo falla, ``revertir()`` deshace ambos cambios (RN14).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Iterator

from ..dominio import Filial, Moneda, Producto, Venta

if TYPE_CHECKING:  # evita importación circular en tiempo de ejecución
    from ..reporte.facade.resultados import ReporteGenerado


class RepositorioFiliales(ABC):
    @abstractmethod
    def guardar(self, filial: Filial) -> Filial: ...

    @abstractmethod
    def buscar_por_codigo(self, codigo: str) -> Filial | None: ...

    @abstractmethod
    def listar_todas(self) -> list[Filial]: ...

    @abstractmethod
    def existe(self, codigo: str) -> bool: ...


class RepositorioProductos(ABC):
    @abstractmethod
    def guardar(self, producto: Producto) -> Producto: ...

    @abstractmethod
    def actualizar_stock(self, producto: Producto) -> None: ...

    @abstractmethod
    def buscar_por_codigo(self, codigo: str, *, bloquear: bool = False) -> Producto | None:
        """``bloquear=True`` reserva la fila hasta el fin de la transacción (SELECT ... FOR UPDATE)."""

    @abstractmethod
    def listar_todos(self) -> list[Producto]: ...

    @abstractmethod
    def listar_por_filial(self, codigo_filial: str) -> list[Producto]: ...

    @abstractmethod
    def existe(self, codigo: str) -> bool: ...


class RepositorioVentas(ABC):
    @abstractmethod
    def guardar(self, venta: Venta) -> Venta: ...

    @abstractmethod
    def existe_factura(self, numero_factura: str) -> bool: ...

    @abstractmethod
    def listar_todas(self, codigo_filial: str | None = None) -> list[Venta]:
        """Más recientes primero."""

    @abstractmethod
    def listar_entre(self, desde: date, hasta: date) -> list[Venta]:
        """En orden cronológico."""


class RepositorioReportes(ABC):
    @abstractmethod
    def guardar(self, reporte: "ReporteGenerado") -> "ReporteGenerado": ...

    @abstractmethod
    def buscar_por_id(self, identificador: str) -> "ReporteGenerado | None": ...

    @abstractmethod
    def listar_todos(self) -> list["ReporteGenerado"]: ...


class RepositorioConfiguracion(ABC):
    @abstractmethod
    def tasas(self) -> dict[Moneda, tuple[Decimal, datetime]]: ...

    @abstractmethod
    def guardar_tasa(self, moneda: Moneda, unidades_por_euro: Decimal, fecha: datetime) -> None: ...

    @abstractmethod
    def parametros(self) -> dict[str, str]: ...

    @abstractmethod
    def guardar_parametro(self, clave: str, valor: str) -> None: ...


class UnidadDeTrabajo(ABC):
    filiales: RepositorioFiliales
    productos: RepositorioProductos
    ventas: RepositorioVentas
    reportes: RepositorioReportes
    configuracion: RepositorioConfiguracion

    @abstractmethod
    def confirmar(self) -> None:
        """COMMIT de todos los cambios pendientes."""

    @abstractmethod
    def revertir(self) -> None:
        """ROLLBACK: deja la base de datos como estaba al inicio de la transacción."""


@contextmanager
def transaccion(uow: UnidadDeTrabajo) -> Iterator[UnidadDeTrabajo]:
    """Confirma si el bloque termina bien; si lanza una excepción, revierte todo y la propaga."""
    try:
        yield uow
        uow.confirmar()
    except BaseException:
        uow.revertir()
        raise
