"""Consolidación financiera (CU07): integra ventas e inventarios de todas las filiales en moneda corporativa."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from ..config.configuracion_global import ConfiguracionGlobal
from ..dominio import Dinero
from .catalogo import FilialService, ProductoService
from .periodo import Periodo, nombre_mes
from .ventas import VentaService


@dataclass(frozen=True)
class FilaProducto:
    codigo: str
    nombre: str
    categoria: str
    unidades: int
    ingresos: Dinero


@dataclass(frozen=True)
class DatosConsolidados:
    """Insumo normalizado que el Director/Builder transforma en un reporte."""
    periodo: Periodo
    alcance: str
    codigo_filial: str | None
    numero_ventas: int
    unidades_vendidas: int
    ingresos: Dinero
    costo_importacion: Dinero
    margen_bruto: Dinero
    ingresos_por_pais: dict[str, Dinero] = field(default_factory=dict)
    costo_por_pais: dict[str, Dinero] = field(default_factory=dict)
    ingresos_por_pais_y_categoria: dict[str, dict[str, Dinero]] = field(default_factory=dict)
    ingresos_por_categoria: dict[str, Dinero] = field(default_factory=dict)
    ingresos_por_mes: dict[str, Dinero] = field(default_factory=dict)
    ventas_por_metodo_pago: dict[str, int] = field(default_factory=dict)
    productos_mas_vendidos: list[FilaProducto] = field(default_factory=list)
    inventario_valorizado: Dinero | None = None
    productos_con_stock_bajo: int = 0

    @property
    def sin_movimientos(self) -> bool:
        return self.numero_ventas == 0

    @property
    def margen_porcentual(self) -> float:
        if not self.ingresos.es_positivo():
            return 0.0
        return float(self.margen_bruto.monto / self.ingresos.monto * 100)


def _ordenar_desc(mapa: dict[str, Dinero]) -> dict[str, Dinero]:
    return dict(sorted(mapa.items(), key=lambda kv: kv[1].monto, reverse=True))


class ConsolidacionService:

    def __init__(self, ventas: VentaService, productos: ProductoService, filiales: FilialService,
                 configuracion: ConfiguracionGlobal) -> None:
        self._ventas = ventas
        self._productos = productos
        self._filiales = filiales
        self._config = configuracion

    def consolidar(self, periodo: Periodo, codigo_filial: str | None = None) -> DatosConsolidados:
        if periodo is None:
            raise ValueError("El período es obligatorio")
        filtro = None
        alcance = "Consolidado corporativo"
        if codigo_filial and codigo_filial.strip():
            filial = self._filiales.obtener(codigo_filial)
            filtro, alcance = filial.codigo, f"Filial {filial.nombre}"

        corp = self._config.moneda_corporativa
        cero = Dinero.cero(corp)
        ventas = [v for v in self._ventas.listar_entre(periodo.desde, periodo.hasta)
                  if filtro is None or v.codigo_filial == filtro]
        nombre_pais = {f.codigo: f.pais for f in self._filiales.listar()}

        ingresos, costo, unidades = cero, cero, 0
        por_pais: dict[str, Dinero] = defaultdict(lambda: cero)
        costo_pais: dict[str, Dinero] = defaultdict(lambda: cero)
        pais_categoria: dict[str, dict[str, Dinero]] = defaultdict(lambda: defaultdict(lambda: cero))
        por_categoria: dict[str, Dinero] = defaultdict(lambda: cero)
        por_mes: dict[tuple[int, int], Dinero] = defaultdict(lambda: cero)
        por_metodo: dict[str, int] = defaultdict(int)
        por_producto: dict[str, FilaProducto] = {}

        for v in ventas:
            total = v.total_corporativo
            ingresos += total
            costo += v.costo_importacion_corporativo
            unidades += v.cantidad
            pais = nombre_pais.get(v.codigo_filial, v.codigo_filial)
            categoria = v.categoria.etiqueta
            por_pais[pais] += total
            costo_pais[pais] += v.costo_importacion_corporativo
            pais_categoria[pais][categoria] += total
            por_categoria[categoria] += total
            por_mes[(v.fecha.year, v.fecha.month)] += total
            por_metodo[v.metodo_pago.etiqueta] += 1
            previo = por_producto.get(v.codigo_producto)
            por_producto[v.codigo_producto] = FilaProducto(
                v.codigo_producto, v.nombre_producto, categoria,
                (previo.unidades if previo else 0) + v.cantidad,
                (previo.ingresos if previo else cero) + total)

        meses = {f"{nombre_mes(m)[:3]} {a}": d for (a, m), d in sorted(por_mes.items())}
        top = sorted(por_producto.values(), key=lambda f: f.ingresos.monto, reverse=True)[:5]
        inventario = self._productos.listar(filtro)
        valor_inventario = sum((self._productos.valor_inventario_corporativo(p) for p in inventario), cero)
        stock_bajo = sum(1 for p in inventario if p.stock_bajo)

        return DatosConsolidados(
            periodo=periodo, alcance=alcance, codigo_filial=filtro, numero_ventas=len(ventas),
            unidades_vendidas=unidades, ingresos=ingresos, costo_importacion=costo, margen_bruto=ingresos - costo,
            ingresos_por_pais=_ordenar_desc(dict(por_pais)), costo_por_pais=dict(costo_pais),
            ingresos_por_pais_y_categoria={p: dict(c) for p, c in pais_categoria.items()},
            ingresos_por_categoria=_ordenar_desc(dict(por_categoria)), ingresos_por_mes=meses,
            ventas_por_metodo_pago=dict(por_metodo), productos_mas_vendidos=top,
            inventario_valorizado=valor_inventario, productos_con_stock_bajo=stock_bajo)

