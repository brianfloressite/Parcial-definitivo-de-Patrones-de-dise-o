"""Módulo de Ventas (CU03–CU06): registra la venta, descuenta stock y convierte a la moneda corporativa."""
from __future__ import annotations

from datetime import date

from ..dominio import Dinero, MetodoPago, ReglaNegocioError, Venta, a_decimal
from .catalogo import FilialService, ProductoService
from .conversor import ConversorMoneda
from .periodo import parsear_fecha
from .puertos import UnidadDeTrabajo, transaccion
from .solicitudes import SolicitudRegistroVenta


class VentaService:
    """Flujo transaccional (RN14): valida datos → bloquea la fila del producto → descuenta stock →
    convierte a EUR → registra la venta → COMMIT. Si cualquier paso falla se hace ROLLBACK, de modo que
    nunca queda una venta registrada con el inventario incorrecto (ni stock descontado sin venta)."""

    def __init__(self, uow: UnidadDeTrabajo, productos: ProductoService, filiales: FilialService,
                 conversor: ConversorMoneda) -> None:
        self._uow = uow
        self._productos = productos
        self._filiales = filiales
        self._conversor = conversor

    def registrar(self, s: SolicitudRegistroVenta) -> Venta:
        if s is None:
            raise ValueError("La solicitud de venta es obligatoria")
        if not s.numero_factura or not s.numero_factura.strip():
            raise ValueError("El número de factura es obligatorio")
        if self._uow.ventas.existe_factura(s.numero_factura):
            raise ReglaNegocioError(f"La factura {s.numero_factura.strip().upper()} ya fue registrada")
        if s.cantidad is None or s.cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor que cero")
        precio = a_decimal(s.precio_unitario, "precio unitario")
        if precio <= 0:
            raise ValueError("El precio unitario debe ser mayor que cero")
        fecha = parsear_fecha(s.fecha, "fecha de venta")
        metodo_pago = MetodoPago.desde_texto(s.metodo_pago)

        with transaccion(self._uow):
            producto = self._productos.obtener(s.codigo_producto, bloquear=True)   # SELECT … FOR UPDATE
            filial = self._filiales.obtener(producto.codigo_filial)
            precio_unitario = Dinero(precio, filial.moneda_local)
            conversion = self._conversor.a_corporativa(precio_unitario.multiplicar(s.cantidad))
            costo = self._productos.costo_unitario_corporativo(producto).multiplicar(s.cantidad)
            venta = Venta(                                     # valida todo antes de tocar el stock
                numero_factura=s.numero_factura, fecha=fecha, codigo_producto=producto.codigo,
                nombre_producto=producto.nombre, categoria=producto.categoria, codigo_filial=filial.codigo,
                cantidad=s.cantidad, precio_unitario=precio_unitario, cliente=s.cliente, vendedor=s.vendedor,
                metodo_pago=metodo_pago, total_corporativo=conversion.convertido, tasa_aplicada=conversion.tasa,
                costo_importacion_corporativo=costo)
            producto.descontar_stock(s.cantidad)               # RN05 / RN06
            self._uow.productos.actualizar_stock(producto)
            self._uow.ventas.guardar(venta)
        return venta

    def listar(self, codigo_filial: str | None = None) -> list[Venta]:
        return self._uow.ventas.listar_todas(codigo_filial.strip().upper() if codigo_filial else None)

    def listar_entre(self, desde: date, hasta: date) -> list[Venta]:
        return self._uow.ventas.listar_entre(desde, hasta)
