"""Servicios de catálogo: filiales (CU02) y productos importados (CU01)."""
from __future__ import annotations

from ..dominio import (Categoria, Dinero, Filial, Moneda, Producto, RecursoNoEncontradoError,
                       ReglaNegocioError, a_decimal)
from .conversor import ConversorMoneda
from .periodo import parsear_fecha
from .puertos import UnidadDeTrabajo, transaccion
from .solicitudes import SolicitudRegistroProducto


class FilialService:
    """Incorporar nuevas filiales no exige modificar el sistema (escalabilidad, OCP)."""

    def __init__(self, uow: UnidadDeTrabajo) -> None:
        self._uow = uow

    def registrar(self, codigo: str, nombre: str, pais: str, ciudad: str, moneda: str,
                  sede_central: bool = False) -> Filial:
        filial = Filial(codigo, nombre, pais, ciudad, Moneda.desde_texto(moneda), sede_central)
        if self._uow.filiales.existe(filial.codigo):
            raise ReglaNegocioError(f"La filial {filial.codigo} ya se encuentra registrada")
        with transaccion(self._uow):
            self._uow.filiales.guardar(filial)
        return filial

    def obtener(self, codigo: str) -> Filial:
        filial = self._uow.filiales.buscar_por_codigo(codigo)
        if filial is None:
            raise RecursoNoEncontradoError("Filial", str(codigo))
        return filial

    def listar(self) -> list[Filial]:
        return self._uow.filiales.listar_todas()


class ProductoService:
    """Responsabilidad única: catálogo e inventario de productos importados."""

    UMBRAL_STOCK_BAJO = Producto.UMBRAL_STOCK_BAJO

    def __init__(self, uow: UnidadDeTrabajo, filiales: FilialService, conversor: ConversorMoneda) -> None:
        self._uow = uow
        self._filiales = filiales
        self._conversor = conversor

    def registrar(self, s: SolicitudRegistroProducto) -> Producto:
        if s is None:
            raise ValueError("La solicitud de registro es obligatoria")
        if s.codigo and self._uow.productos.existe(s.codigo):
            raise ReglaNegocioError(f"Ya existe un producto con el código {s.codigo.strip().upper()}")
        filial = self._filiales.obtener(s.codigo_filial)
        if s.costo_importacion_cny is None:
            raise ValueError("El costo de importación es obligatorio")
        if s.precio_venta_sugerido is None:
            raise ValueError("El precio de venta sugerido es obligatorio")
        if s.stock_inicial is None:
            raise ValueError("El stock inicial es obligatorio")
        producto = Producto(
            codigo=s.codigo, nombre=s.nombre, descripcion_tecnica=s.descripcion_tecnica,
            categoria=Categoria.desde_texto(s.categoria),
            costo_importacion=Dinero(a_decimal(s.costo_importacion_cny, "costo de importación"), Moneda.CNY),
            precio_venta_sugerido=Dinero(a_decimal(s.precio_venta_sugerido, "precio de venta"), filial.moneda_local),
            proveedor=s.proveedor, fecha_importacion=parsear_fecha(s.fecha_importacion, "fecha de importación"),
            codigo_filial=filial.codigo, stock_inicial=s.stock_inicial)
        with transaccion(self._uow):
            self._uow.productos.guardar(producto)
        return producto

    def obtener(self, codigo: str, *, bloquear: bool = False) -> Producto:
        producto = self._uow.productos.buscar_por_codigo(codigo, bloquear=bloquear)
        if producto is None:
            raise RecursoNoEncontradoError("Producto", str(codigo))
        return producto

    def listar(self, codigo_filial: str | None = None) -> list[Producto]:
        if codigo_filial and codigo_filial.strip():
            return self._uow.productos.listar_por_filial(codigo_filial)
        return self._uow.productos.listar_todos()

    def con_stock_bajo(self) -> list[Producto]:
        return [p for p in self._uow.productos.listar_todos() if p.stock_bajo]

    def costo_unitario_corporativo(self, producto: Producto) -> Dinero:
        """Costo de importación unitario expresado en moneda corporativa."""
        return self._conversor.a_corporativa(producto.costo_importacion).convertido

    def valor_inventario_corporativo(self, producto: Producto) -> Dinero:
        """Valor del inventario actual de un producto a costo de importación, en moneda corporativa."""
        return self.costo_unitario_corporativo(producto).multiplicar(producto.stock)
