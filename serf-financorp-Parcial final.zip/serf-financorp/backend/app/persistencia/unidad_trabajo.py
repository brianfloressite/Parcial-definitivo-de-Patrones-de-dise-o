"""Unidad de trabajo sobre una sesión SQLAlchemy: todos los repositorios comparten la misma transacción."""
from __future__ import annotations

from sqlalchemy.orm import Session

from ..servicio.puertos import UnidadDeTrabajo
from .repositorios.sqlalchemy_repos import (RepositorioConfiguracionSql, RepositorioFilialesSql,
                                            RepositorioProductosSql, RepositorioReportesSql,
                                            RepositorioVentasSql)


class UnidadDeTrabajoSql(UnidadDeTrabajo):
    def __init__(self, sesion: Session) -> None:
        self._sesion = sesion
        self.filiales = RepositorioFilialesSql(sesion)
        self.productos = RepositorioProductosSql(sesion)
        self.ventas = RepositorioVentasSql(sesion)
        self.reportes = RepositorioReportesSql(sesion)
        self.configuracion = RepositorioConfiguracionSql(sesion)

    def confirmar(self) -> None:
        self._sesion.commit()

    def revertir(self) -> None:
        self._sesion.rollback()

    def cerrar(self) -> None:
        """Devuelve la conexión al pool (descarta lo no confirmado)."""
        self._sesion.close()

    def __enter__(self) -> "UnidadDeTrabajoSql":
        return self

    def __exit__(self, tipo, *_):
        if tipo is not None:
            self.revertir()
        self.cerrar()
        return False
