"""Genera el DDL de MySQL a partir de los modelos (mantiene database/schema.sql sincronizado).

    python -m app.persistencia.generar_ddl > ../database/schema.sql
"""
from __future__ import annotations

from sqlalchemy.dialects import mysql
from sqlalchemy.schema import CreateIndex, CreateTable

from .modelos import Base

ENCABEZADO = """-- =====================================================================
-- SERF · FinanCorp S.A. — Esquema MySQL 8 (generado desde app/persistencia/modelos.py)
-- Uso:  mysql -u root -p < database/crear_bd.sql
--       mysql -u serf -p serf < database/schema.sql
-- La API también crea las tablas que falten al arrancar.
-- =====================================================================
SET NAMES utf8mb4;
"""


def generar() -> str:
    dialecto = mysql.dialect()
    partes = [ENCABEZADO]
    for tabla in Base.metadata.sorted_tables:
        partes.append(f"\n-- {tabla.comment or tabla.name}")
        partes.append(str(CreateTable(tabla).compile(dialect=dialecto)).strip() + ";")
        for indice in sorted(tabla.indexes, key=lambda i: i.name):
            partes.append(str(CreateIndex(indice).compile(dialect=dialecto)).strip() + ";")
    return "\n".join(partes) + "\n"


if __name__ == "__main__":  # pragma: no cover
    print(generar(), end="")
