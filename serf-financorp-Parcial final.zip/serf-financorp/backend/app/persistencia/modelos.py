"""Mapeo objeto-relacional (SQLAlchemy 2.0) de las tablas MySQL de SERF.

Estos modelos son *de persistencia*, no de dominio: los repositorios traducen fila <-> entidad, así las
reglas de negocio no dependen de la base de datos (DIP) y el esquema puede cambiar sin tocar el dominio.
El DDL equivalente para MySQL está en ``database/schema.sql`` (generado desde aquí).
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (JSON, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer,
                        Numeric, String, Text, func)
from sqlalchemy.dialects.mysql import DATETIME as MYSQL_DATETIME, LONGTEXT
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

DINERO = Numeric(18, 2)
TASA = Numeric(18, 6)
TEXTO_LARGO = Text().with_variant(LONGTEXT(), "mysql")
INSTANTE = DateTime().with_variant(MYSQL_DATETIME(fsp=6), "mysql")   # microsegundos: orden exacto del historial


OPCIONES_MYSQL = {"mysql_engine": "InnoDB", "mysql_charset": "utf8mb4", "mysql_collate": "utf8mb4_unicode_ci"}


class Base(DeclarativeBase):
    pass


class FilialFila(Base):
    __tablename__ = "filial"
    __table_args__ = {"comment": "Filiales de FinanCorp; cada una opera en su moneda local", **OPCIONES_MYSQL}

    codigo: Mapped[str] = mapped_column(String(3), primary_key=True)
    nombre: Mapped[str] = mapped_column(String(80))
    pais: Mapped[str] = mapped_column(String(60))
    ciudad: Mapped[str] = mapped_column(String(60))
    moneda_local: Mapped[str] = mapped_column(String(3))
    sede_central: Mapped[bool] = mapped_column(Boolean, default=False)
    creado_en: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class ProductoFila(Base):
    __tablename__ = "producto"
    __table_args__ = (
        CheckConstraint("stock >= 0", name="ck_producto_stock_no_negativo"),
        CheckConstraint("stock_inicial >= 0", name="ck_producto_stock_inicial"),
        CheckConstraint("costo_importacion > 0", name="ck_producto_costo_positivo"),
        CheckConstraint("precio_venta_sugerido > 0", name="ck_producto_precio_positivo"),
        Index("ix_producto_filial", "codigo_filial"),
        {"comment": "Productos importados desde China e inventario por filial", **OPCIONES_MYSQL},
    )

    codigo: Mapped[str] = mapped_column(String(20), primary_key=True)
    nombre: Mapped[str] = mapped_column(String(120))
    descripcion_tecnica: Mapped[str] = mapped_column(String(255), default="")
    categoria: Mapped[str] = mapped_column(String(20))
    costo_importacion: Mapped[Decimal] = mapped_column(DINERO)
    moneda_costo: Mapped[str] = mapped_column(String(3))
    precio_venta_sugerido: Mapped[Decimal] = mapped_column(DINERO)
    moneda_precio: Mapped[str] = mapped_column(String(3))
    proveedor: Mapped[str] = mapped_column(String(80))
    fecha_importacion: Mapped[date] = mapped_column(Date)
    codigo_filial: Mapped[str] = mapped_column(ForeignKey("filial.codigo", ondelete="RESTRICT"))
    stock_inicial: Mapped[int] = mapped_column(Integer)
    stock: Mapped[int] = mapped_column(Integer)
    creado_en: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class VentaFila(Base):
    __tablename__ = "venta"
    __table_args__ = (
        CheckConstraint("cantidad > 0", name="ck_venta_cantidad_positiva"),
        Index("ix_venta_fecha", "fecha"),
        Index("ix_venta_filial_fecha", "codigo_filial", "fecha"),
        {"comment": "Ventas confirmadas con su conversión a moneda corporativa (RN08)", **OPCIONES_MYSQL},
    )

    numero_factura: Mapped[str] = mapped_column(String(30), primary_key=True)
    fecha: Mapped[date] = mapped_column(Date)
    codigo_producto: Mapped[str] = mapped_column(ForeignKey("producto.codigo", ondelete="RESTRICT"))
    nombre_producto: Mapped[str] = mapped_column(String(120))
    categoria: Mapped[str] = mapped_column(String(20))
    codigo_filial: Mapped[str] = mapped_column(ForeignKey("filial.codigo", ondelete="RESTRICT"))
    cantidad: Mapped[int] = mapped_column(Integer)
    precio_unitario: Mapped[Decimal] = mapped_column(DINERO)
    moneda_local: Mapped[str] = mapped_column(String(3))
    cliente: Mapped[str] = mapped_column(String(120))
    vendedor: Mapped[str] = mapped_column(String(80))
    metodo_pago: Mapped[str] = mapped_column(String(15))
    total_corporativo: Mapped[Decimal] = mapped_column(DINERO)
    moneda_corporativa: Mapped[str] = mapped_column(String(3))
    tasa_aplicada: Mapped[Decimal] = mapped_column(TASA)
    costo_importacion_corporativo: Mapped[Decimal] = mapped_column(DINERO)
    creado_en: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class TasaCambioFila(Base):
    __tablename__ = "tasa_cambio"
    __table_args__ = (CheckConstraint("unidades_por_euro > 0", name="ck_tasa_positiva"),
                      {"comment": "Tipos de cambio vigentes: unidades de moneda por 1 EUR", **OPCIONES_MYSQL})

    moneda: Mapped[str] = mapped_column(String(3), primary_key=True)
    unidades_por_euro: Mapped[Decimal] = mapped_column(TASA)
    actualizado_en: Mapped[datetime] = mapped_column(DateTime)


class ParametroFila(Base):
    __tablename__ = "parametro"
    __table_args__ = {"comment": "Parámetros corporativos editables (marca de agua, etc.)", **OPCIONES_MYSQL}

    clave: Mapped[str] = mapped_column(String(40), primary_key=True)
    valor: Mapped[str] = mapped_column(String(255))


class ReporteFila(Base):
    __tablename__ = "reporte"
    __table_args__ = (Index("ix_reporte_creado", "creado_en"),
                      {"comment": "Historial de reportes emitidos (trazabilidad, RNF08)", **OPCIONES_MYSQL})

    id: Mapped[str] = mapped_column(String(8), primary_key=True)
    titulo: Mapped[str] = mapped_column(String(150))
    tipo: Mapped[str] = mapped_column(String(30))
    periodo: Mapped[str] = mapped_column(String(40))
    alcance: Mapped[str] = mapped_column(String(120))
    autor: Mapped[str] = mapped_column(String(80))
    fecha_generacion: Mapped[str] = mapped_column(String(20))
    tipo_contenido: Mapped[str] = mapped_column(String(20))
    contenido: Mapped[str] = mapped_column(TEXTO_LARGO)
    metadatos: Mapped[dict] = mapped_column(JSON)
    capas: Mapped[list] = mapped_column(JSON)
    firmado: Mapped[bool] = mapped_column(Boolean, default=False)
    creado_en: Mapped[datetime] = mapped_column(INSTANTE, default=datetime.now)
