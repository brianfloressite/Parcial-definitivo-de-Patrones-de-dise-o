"""Repositorios concretos sobre SQLAlchemy (MySQL en producción, SQLite en pruebas).

Traducen filas <-> entidades de dominio. Las consultas usan parámetros enlazados de SQLAlchemy, por lo que
no hay concatenación de SQL ni riesgo de inyección (OWASP A03).
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import case, select
from sqlalchemy.orm import Session

from ...dominio import Categoria, Dinero, Filial, MetodoPago, Moneda, Producto, Venta
from ...reporte.facade.resultados import ReporteGenerado
from ...servicio.puertos import (RepositorioConfiguracion, RepositorioFiliales, RepositorioProductos,
                                 RepositorioReportes, RepositorioVentas)
from ..modelos import (FilialFila, ParametroFila, ProductoFila, ReporteFila, TasaCambioFila, VentaFila)


class RepositorioFilialesSql(RepositorioFiliales):
    def __init__(self, sesion: Session) -> None:
        self._s = sesion

    def guardar(self, filial: Filial) -> Filial:
        self._s.add(FilialFila(codigo=filial.codigo, nombre=filial.nombre, pais=filial.pais,
                               ciudad=filial.ciudad, moneda_local=filial.moneda_local.name,
                               sede_central=filial.sede_central))
        self._s.flush()
        return filial

    def buscar_por_codigo(self, codigo: str) -> Filial | None:
        if not codigo:
            return None
        fila = self._s.get(FilialFila, codigo.strip().upper())
        return self._a_dominio(fila) if fila else None

    def listar_todas(self) -> list[Filial]:
        consulta = select(FilialFila).order_by(case((FilialFila.sede_central.is_(True), 0), else_=1),
                                               FilialFila.codigo)
        return [self._a_dominio(f) for f in self._s.scalars(consulta)]

    def existe(self, codigo: str) -> bool:
        return bool(codigo) and self._s.get(FilialFila, codigo.strip().upper()) is not None

    @staticmethod
    def _a_dominio(f: FilialFila) -> Filial:
        return Filial(f.codigo, f.nombre, f.pais, f.ciudad, Moneda[f.moneda_local], f.sede_central)


class RepositorioProductosSql(RepositorioProductos):
    def __init__(self, sesion: Session) -> None:
        self._s = sesion

    def guardar(self, producto: Producto) -> Producto:
        self._s.add(ProductoFila(
            codigo=producto.codigo, nombre=producto.nombre, descripcion_tecnica=producto.descripcion_tecnica,
            categoria=producto.categoria.name,
            costo_importacion=producto.costo_importacion.monto, moneda_costo=producto.costo_importacion.moneda.name,
            precio_venta_sugerido=producto.precio_venta_sugerido.monto,
            moneda_precio=producto.precio_venta_sugerido.moneda.name,
            proveedor=producto.proveedor, fecha_importacion=producto.fecha_importacion,
            codigo_filial=producto.codigo_filial, stock_inicial=producto.stock_inicial, stock=producto.stock))
        self._s.flush()
        return producto

    def actualizar_stock(self, producto: Producto) -> None:
        fila = self._s.get(ProductoFila, producto.codigo)
        if fila is None:
            raise LookupError(f"Producto no encontrado: {producto.codigo}")
        fila.stock = producto.stock
        self._s.flush()

    def buscar_por_codigo(self, codigo: str, *, bloquear: bool = False) -> Producto | None:
        if not codigo:
            return None
        consulta = select(ProductoFila).where(ProductoFila.codigo == codigo.strip().upper())
        if bloquear:
            consulta = consulta.with_for_update()
        fila = self._s.scalars(consulta).first()
        return self._a_dominio(fila) if fila else None

    def listar_todos(self) -> list[Producto]:
        return [self._a_dominio(f) for f in self._s.scalars(select(ProductoFila).order_by(ProductoFila.codigo))]

    def listar_por_filial(self, codigo_filial: str) -> list[Producto]:
        consulta = (select(ProductoFila).where(ProductoFila.codigo_filial == codigo_filial.strip().upper())
                    .order_by(ProductoFila.codigo))
        return [self._a_dominio(f) for f in self._s.scalars(consulta)]

    def existe(self, codigo: str) -> bool:
        return bool(codigo) and self._s.get(ProductoFila, codigo.strip().upper()) is not None

    @staticmethod
    def _a_dominio(f: ProductoFila) -> Producto:
        return Producto.reconstituir(
            codigo=f.codigo, nombre=f.nombre, descripcion_tecnica=f.descripcion_tecnica,
            categoria=Categoria[f.categoria],
            costo_importacion=Dinero(f.costo_importacion, Moneda[f.moneda_costo]),
            precio_venta_sugerido=Dinero(f.precio_venta_sugerido, Moneda[f.moneda_precio]),
            proveedor=f.proveedor, fecha_importacion=f.fecha_importacion, codigo_filial=f.codigo_filial,
            stock_inicial=f.stock_inicial, stock=f.stock)


class RepositorioVentasSql(RepositorioVentas):
    def __init__(self, sesion: Session) -> None:
        self._s = sesion

    def guardar(self, venta: Venta) -> Venta:
        self._s.add(VentaFila(
            numero_factura=venta.numero_factura, fecha=venta.fecha, codigo_producto=venta.codigo_producto,
            nombre_producto=venta.nombre_producto, categoria=venta.categoria.name,
            codigo_filial=venta.codigo_filial, cantidad=venta.cantidad,
            precio_unitario=venta.precio_unitario.monto, moneda_local=venta.precio_unitario.moneda.name,
            cliente=venta.cliente, vendedor=venta.vendedor, metodo_pago=venta.metodo_pago.name,
            total_corporativo=venta.total_corporativo.monto, moneda_corporativa=venta.total_corporativo.moneda.name,
            tasa_aplicada=venta.tasa_aplicada,
            costo_importacion_corporativo=venta.costo_importacion_corporativo.monto))
        self._s.flush()
        return venta

    def existe_factura(self, numero_factura: str) -> bool:
        return bool(numero_factura) and self._s.get(VentaFila, numero_factura.strip().upper()) is not None

    def listar_todas(self, codigo_filial: str | None = None) -> list[Venta]:
        consulta = select(VentaFila)
        if codigo_filial:
            consulta = consulta.where(VentaFila.codigo_filial == codigo_filial.strip().upper())
        consulta = consulta.order_by(VentaFila.fecha.desc(), VentaFila.numero_factura.desc())
        return [self._a_dominio(f) for f in self._s.scalars(consulta)]

    def listar_entre(self, desde: date, hasta: date) -> list[Venta]:
        consulta = (select(VentaFila).where(VentaFila.fecha.between(desde, hasta))
                    .order_by(VentaFila.fecha, VentaFila.numero_factura))
        return [self._a_dominio(f) for f in self._s.scalars(consulta)]

    @staticmethod
    def _a_dominio(f: VentaFila) -> Venta:
        corporativa = Moneda[f.moneda_corporativa]
        return Venta(
            numero_factura=f.numero_factura, fecha=f.fecha, codigo_producto=f.codigo_producto,
            nombre_producto=f.nombre_producto, categoria=Categoria[f.categoria], codigo_filial=f.codigo_filial,
            cantidad=f.cantidad, precio_unitario=Dinero(f.precio_unitario, Moneda[f.moneda_local]),
            cliente=f.cliente, vendedor=f.vendedor, metodo_pago=MetodoPago[f.metodo_pago],
            total_corporativo=Dinero(f.total_corporativo, corporativa), tasa_aplicada=Decimal(f.tasa_aplicada),
            costo_importacion_corporativo=Dinero(f.costo_importacion_corporativo, corporativa))


class RepositorioReportesSql(RepositorioReportes):
    def __init__(self, sesion: Session) -> None:
        self._s = sesion

    def guardar(self, r: ReporteGenerado) -> ReporteGenerado:
        self._s.add(ReporteFila(id=r.id, titulo=r.titulo, tipo=r.tipo, periodo=r.periodo, alcance=r.alcance,
                                autor=r.autor, fecha_generacion=r.fecha_generacion, tipo_contenido=r.tipo_contenido,
                                contenido=r.contenido, metadatos=dict(r.metadatos), capas=list(r.capas),
                                firmado=r.esta_firmado))
        self._s.flush()
        return r

    def buscar_por_id(self, identificador: str) -> ReporteGenerado | None:
        if not identificador:
            return None
        fila = self._s.get(ReporteFila, identificador.strip().upper())
        return self._a_dominio(fila) if fila else None

    def listar_todos(self) -> list[ReporteGenerado]:
        consulta = select(ReporteFila).order_by(ReporteFila.creado_en.desc())
        return [self._a_dominio(f) for f in self._s.scalars(consulta)]

    @staticmethod
    def _a_dominio(f: ReporteFila) -> ReporteGenerado:
        return ReporteGenerado(id=f.id, titulo=f.titulo, tipo=f.tipo, periodo=f.periodo, alcance=f.alcance,
                               autor=f.autor, fecha_generacion=f.fecha_generacion, tipo_contenido=f.tipo_contenido,
                               contenido=f.contenido, metadatos=dict(f.metadatos or {}), capas=tuple(f.capas or ()))


class RepositorioConfiguracionSql(RepositorioConfiguracion):
    def __init__(self, sesion: Session) -> None:
        self._s = sesion

    def tasas(self) -> dict[Moneda, tuple[Decimal, datetime]]:
        resultado = {}
        for f in self._s.scalars(select(TasaCambioFila)):
            if f.moneda in Moneda.__members__:
                resultado[Moneda[f.moneda]] = (Decimal(f.unidades_por_euro), f.actualizado_en)
        return resultado

    def guardar_tasa(self, moneda: Moneda, unidades_por_euro: Decimal, fecha: datetime) -> None:
        fila = self._s.get(TasaCambioFila, moneda.name)
        if fila is None:
            self._s.add(TasaCambioFila(moneda=moneda.name, unidades_por_euro=unidades_por_euro, actualizado_en=fecha))
        else:
            fila.unidades_por_euro = unidades_por_euro
            fila.actualizado_en = fecha
        self._s.flush()

    def parametros(self) -> dict[str, str]:
        return {f.clave: f.valor for f in self._s.scalars(select(ParametroFila))}

    def guardar_parametro(self, clave: str, valor: str) -> None:
        fila = self._s.get(ParametroFila, clave)
        if fila is None:
            self._s.add(ParametroFila(clave=clave, valor=valor))
        else:
            fila.valor = valor
        self._s.flush()
