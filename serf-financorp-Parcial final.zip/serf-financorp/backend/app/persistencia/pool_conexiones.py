"""Patrón Singleton – Pool de conexiones a MySQL.

Abrir una conexión TCP a MySQL es costoso; si cada petición creara la suya, el servidor se saturaría.
``PoolConexiones`` mantiene **un único** ``Engine`` de SQLAlchemy por proceso, con un ``QueuePool`` que
reutiliza un número acotado de conexiones (``pool_size`` + ``max_overflow``), las valida antes de usarlas
(``pool_pre_ping``) y las recicla antes de que MySQL las cierre por inactividad (``pool_recycle``).

* Única instancia y punto de acceso global: ``PoolConexiones.instancia()`` (``SingletonMeta``).
* Se inicializa una sola vez: intentar apuntarlo a otra base de datos sin cerrarlo antes es un error,
  para que nadie cree por accidente un segundo pool.
* Cada petición HTTP obtiene una sesión con ``nueva_sesion()`` y la devuelve al pool al terminar.
"""
from __future__ import annotations

import threading
from typing import Any

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from ..config.singleton import SingletonMeta, SinDuplicados
from ..dominio.excepciones import OperacionNoValidaError


class PoolConexiones(SinDuplicados, metaclass=SingletonMeta):

    def __init__(self) -> None:
        self._candado = threading.Lock()
        self._motor: Engine | None = None
        self._fabrica: sessionmaker[Session] | None = None
        self._url: str | None = None

    # ---------------------------------------------------------------- ciclo de vida
    def inicializar(self, url: str, *, tamano: int = 5, desborde: int = 10,
                    reciclar_segundos: int = 1800, eco: bool = False) -> "PoolConexiones":
        """Crea el motor una sola vez. Llamarlo de nuevo con la misma URL no hace nada."""
        with self._candado:
            if self._motor is not None:
                if url != self._url:
                    raise OperacionNoValidaError(
                        "El pool de conexiones ya está inicializado; ciérrelo antes de cambiar de base de datos")
                return self
            self._motor = self._crear_motor(url, tamano, desborde, reciclar_segundos, eco)
            self._fabrica = sessionmaker(bind=self._motor, expire_on_commit=False, autoflush=False)
            self._url = url
            return self

    @staticmethod
    def _crear_motor(url: str, tamano: int, desborde: int, reciclar: int, eco: bool) -> Engine:
        if url.startswith("sqlite"):
            # Solo para pruebas automáticas: SQLite en memoria comparte una conexión entre hilos.
            motor = create_engine(url, echo=eco, future=True, poolclass=StaticPool,
                                  connect_args={"check_same_thread": False})

            @event.listens_for(motor, "connect")
            def _activar_claves_foraneas(conexion, _):  # pragma: no cover - trivial
                conexion.execute("PRAGMA foreign_keys=ON")
            return motor
        return create_engine(url, echo=eco, future=True, pool_size=tamano, max_overflow=desborde,
                             pool_pre_ping=True, pool_recycle=reciclar)

    def cerrar(self) -> None:
        """Libera todas las conexiones (apagado ordenado de la aplicación o fin de pruebas)."""
        with self._candado:
            if self._motor is not None:
                self._motor.dispose()
            self._motor = self._fabrica = self._url = None

    # ---------------------------------------------------------------- uso
    @property
    def inicializado(self) -> bool:
        return self._motor is not None

    @property
    def motor(self) -> Engine:
        if self._motor is None:
            raise OperacionNoValidaError("El pool de conexiones no está inicializado")
        return self._motor

    def nueva_sesion(self) -> Session:
        """Sesión de trabajo que toma una conexión del pool y la devuelve al cerrarse."""
        if self._fabrica is None:
            raise OperacionNoValidaError("El pool de conexiones no está inicializado")
        return self._fabrica()

    def version_servidor(self) -> str:
        """Versión del motor de base de datos (comprueba que el pool puede conectarse)."""
        consulta = "SELECT sqlite_version()" if self.motor.dialect.name == "sqlite" else "SELECT VERSION()"
        with self.motor.connect() as conexion:
            return str(conexion.execute(text(consulta)).scalar())

    def estadisticas(self) -> dict[str, Any]:
        """Estado observable del pool (se muestra en la pantalla de Configuración)."""
        motor = self.motor
        pool = motor.pool
        datos: dict[str, Any] = {
            "motor": motor.dialect.name,
            "baseDatos": motor.url.database,
            "servidor": motor.url.host or "local",
            "tipoPool": type(pool).__name__,
            "identidadInstancia": id(self),
        }
        for nombre, metodo in (("tamano", "size"), ("enUso", "checkedout"), ("disponibles", "checkedin"),
                               ("desborde", "overflow")):
            if hasattr(pool, metodo):
                datos[nombre] = getattr(pool, metodo)()
        return datos
