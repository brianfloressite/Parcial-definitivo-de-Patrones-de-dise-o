"""Patrón Prototype – plantillas base de reportes (requisito complementario 2).

Crear una plantilla desde cero es costoso (estilo corporativo, estructura de secciones, metadatos). El
sistema mantiene prototipos preconfigurados y genera cada reporte **clonando** uno de ellos.

* ``Prototipo`` define el contrato ``clonar()``.
* La clonación es **profunda** (``copy.deepcopy``): el estilo, la lista de secciones y los metadatos del
  clon son objetos nuevos, así adaptar el clon a un país nunca altera el prototipo original.
* ``RegistroPlantillas`` (*Prototype Registry*) entrega siempre clones; el cliente pide un ``TipoReporte``
  y nunca instancia clases concretas, lo que evita el acoplamiento a ellas durante la creación.
"""
from __future__ import annotations

import copy
import re
from abc import ABC
from types import MappingProxyType
from typing import Iterable, Mapping, TypeVar

from ...config.configuracion_global import ConfiguracionGlobal
from ..tipo_reporte import TipoReporte

T = TypeVar("T", bound="Prototipo")
_COLOR_HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


class Prototipo(ABC):
    """Contrato de clonación profunda, explícito y tipado."""

    def clonar(self: T) -> T:
        return copy.deepcopy(self)


def _requerido(valor: str | None, campo: str) -> str:
    if valor is None or not str(valor).strip():
        raise ValueError(f"El campo {campo} de la plantilla es obligatorio")
    return str(valor).strip()


class EstiloReporte(Prototipo):
    """Configuración visual mutable (para adaptar colores por país); por eso también es clonable."""

    def __init__(self, color_primario: str, color_acento: str, tipografia: str) -> None:
        self.color_primario = color_primario
        self.color_acento = color_acento
        self.tipografia = tipografia

    @staticmethod
    def _validar_color(color: str) -> str:
        if not isinstance(color, str) or not _COLOR_HEX.match(color):
            raise ValueError("El color debe tener formato hexadecimal #RRGGBB")
        return color.upper()

    @property
    def color_primario(self) -> str:
        return self._color_primario

    @color_primario.setter
    def color_primario(self, color: str) -> None:
        self._color_primario = self._validar_color(color)

    @property
    def color_acento(self) -> str:
        return self._color_acento

    @color_acento.setter
    def color_acento(self, color: str) -> None:
        self._color_acento = self._validar_color(color)

    @property
    def tipografia(self) -> str:
        return self._tipografia

    @tipografia.setter
    def tipografia(self, valor: str) -> None:
        if not valor or not str(valor).strip():
            raise ValueError("La tipografía es obligatoria")
        self._tipografia = str(valor).strip()


class PlantillaReporte(Prototipo, ABC):
    """Prototipo abstracto: título, descripción, estilo, secciones obligatorias, nota legal y metadatos."""

    def __init__(self, tipo: TipoReporte, titulo_base: str, descripcion: str, estilo: EstiloReporte,
                 secciones_obligatorias: Iterable[str]) -> None:
        if not isinstance(tipo, TipoReporte):
            raise ValueError("El tipo de reporte es obligatorio")
        if not isinstance(estilo, EstiloReporte):
            raise ValueError("El estilo es obligatorio")
        self._tipo = tipo
        self._titulo_base = _requerido(titulo_base, "título base")
        self._descripcion = _requerido(descripcion, "descripción")
        self._estilo = estilo
        self._secciones = [_requerido(s, "sección") for s in secciones_obligatorias]
        self._codigo_pais: str | None = None
        self._nota_legal = ""
        self._metadatos: dict[str, str] = {"version": "1.0"}

    def adaptar_a_pais(self, codigo_pais: str | None, nota_legal: str | None) -> "PlantillaReporte":
        """Adapta el clon a un país (o al consolidado corporativo si es None). El prototipo queda intacto."""
        self._codigo_pais = codigo_pais.strip().upper() if codigo_pais else None
        self._nota_legal = (nota_legal or "").strip()
        self._metadatos["pais"] = self._codigo_pais or "CORPORATIVO"
        return self

    def registrar_metadato(self, clave: str, valor: str) -> None:
        if not clave or not clave.strip():
            raise ValueError("La clave del metadato es obligatoria")
        self._metadatos[clave] = valor

    def agregar_seccion_obligatoria(self, titulo: str) -> None:
        self._secciones.append(_requerido(titulo, "sección"))

    tipo = property(lambda self: self._tipo)
    estilo = property(lambda self: self._estilo)
    codigo_pais = property(lambda self: self._codigo_pais)
    nota_legal = property(lambda self: self._nota_legal)

    @property
    def titulo_base(self) -> str:
        return self._titulo_base

    @titulo_base.setter
    def titulo_base(self, valor: str) -> None:
        self._titulo_base = _requerido(valor, "título base")

    @property
    def descripcion(self) -> str:
        return self._descripcion

    @property
    def secciones_obligatorias(self) -> tuple[str, ...]:
        return tuple(self._secciones)

    @property
    def metadatos(self) -> Mapping[str, str]:
        return MappingProxyType(self._metadatos)


class PlantillaReporteMensual(PlantillaReporte):
    SECCION_RESUMEN = "Resumen ejecutivo"
    SECCION_PAIS = "Ingresos por país"
    SECCION_CATEGORIA = "Ingresos por categoría de producto"
    SECCION_CONCLUSIONES = "Conclusiones"

    def __init__(self) -> None:
        super().__init__(TipoReporte.MENSUAL_INGRESOS, "Reporte Mensual de Ingresos",
                         "Ingresos del mes por filial y categoría, expresados en moneda corporativa.",
                         EstiloReporte("#0B3D91", "#E4002B", "Inter"),
                         [self.SECCION_RESUMEN, self.SECCION_PAIS, self.SECCION_CATEGORIA, self.SECCION_CONCLUSIONES])


class PlantillaReporteTrimestral(PlantillaReporte):
    SECCION_RESUMEN = "Resumen ejecutivo"
    SECCION_INGRESOS = "Ingresos del trimestre"
    SECCION_GASTOS = "Gastos de importación"
    SECCION_RESULTADO = "Resultado bruto por país"
    SECCION_CONCLUSIONES = "Conclusiones"

    def __init__(self) -> None:
        super().__init__(TipoReporte.TRIMESTRAL_GASTOS_INGRESOS, "Reporte Trimestral de Gastos e Ingresos",
                         "Comparativo de ingresos por ventas frente a gastos de importación (costo CNY convertido).",
                         EstiloReporte("#0F5257", "#F2A900", "Inter"),
                         [self.SECCION_RESUMEN, self.SECCION_INGRESOS, self.SECCION_GASTOS,
                          self.SECCION_RESULTADO, self.SECCION_CONCLUSIONES])


class PlantillaReporteAnual(PlantillaReporte):
    SECCION_RESUMEN = "Resumen ejecutivo"
    SECCION_EVOLUCION = "Evolución mensual de ingresos"
    SECCION_PAIS = "Resultados por país"
    SECCION_CATEGORIA = "Resultados por categoría de producto"
    SECCION_INVENTARIO = "Inventario y gastos de importación"
    SECCION_CONCLUSIONES = "Conclusiones"

    def __init__(self) -> None:
        super().__init__(TipoReporte.ANUAL_CONSOLIDADO, "Reporte Anual Consolidado",
                         "Estado consolidado anual de ventas, costos de importación, márgenes e inventario de todas las filiales.",
                         EstiloReporte("#1F2A44", "#E4002B", "Inter"),
                         [self.SECCION_RESUMEN, self.SECCION_EVOLUCION, self.SECCION_PAIS,
                          self.SECCION_CATEGORIA, self.SECCION_INVENTARIO, self.SECCION_CONCLUSIONES])


class RegistroPlantillas:
    """Prototype Registry: un prototipo por tipo de reporte; siempre entrega clones."""

    def __init__(self, configuracion: ConfiguracionGlobal) -> None:
        self._config = configuracion
        self._prototipos: dict[TipoReporte, PlantillaReporte] = {}
        for prototipo in (PlantillaReporteMensual(), PlantillaReporteTrimestral(), PlantillaReporteAnual()):
            self.registrar(prototipo)

    def registrar(self, prototipo: PlantillaReporte) -> None:
        """Registra o reemplaza el prototipo de un tipo (extensible sin modificar esta clase, OCP)."""
        if not isinstance(prototipo, PlantillaReporte):
            raise ValueError("El prototipo es obligatorio")
        self._prototipos[prototipo.tipo] = prototipo

    def obtener(self, tipo: TipoReporte) -> PlantillaReporte:
        """Clon independiente del prototipo solicitado."""
        prototipo = self._prototipos.get(tipo)
        if prototipo is None:
            raise LookupError(f"No existe una plantilla registrada para {tipo}")
        return prototipo.clonar()

    def obtener_para_pais(self, tipo: TipoReporte, codigo_pais: str | None) -> PlantillaReporte:
        """Clona la plantilla base y la adapta a un país (o al consolidado corporativo)."""
        return self.obtener(tipo).adaptar_a_pais(codigo_pais, self._config.nota_legal(codigo_pais))

    def prototipos(self) -> tuple[PlantillaReporte, ...]:
        """Vista de solo lectura de los prototipos (para mostrarlos en la interfaz)."""
        return tuple(self._prototipos.values())
