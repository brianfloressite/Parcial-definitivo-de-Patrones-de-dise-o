"""Objetos que entrega la fachada: la solicitud del usuario, el reporte generado y la verificación de firma."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SolicitudReporte:
    """Parámetros que el usuario indica en la interfaz simple de reportes (requisito complementario 4).

    tipo: MENSUAL_INGRESOS | TRIMESTRAL_GASTOS_INGRESOS | ANUAL_CONSOLIDADO · mes solo para mensual ·
    trimestre solo para trimestral · codigo_filial vacío = consolidado de todas · formato HTML o TEXTO.
    """
    tipo: str | None
    anio: int | None
    mes: int | None = None
    trimestre: int | None = None
    codigo_filial: str | None = None
    autor: str | None = None
    formato: str | None = "HTML"
    marca_agua: bool = True
    confidencial: bool = True
    firma_digital: bool = True

    @classmethod
    def mensual_consolidado(cls, anio: int, mes: int, autor: str) -> "SolicitudReporte":
        """Escenario del caso: reporte mensual consolidado con todas las protecciones."""
        return cls("MENSUAL_INGRESOS", anio, mes, None, None, autor, "HTML", True, True, True)


@dataclass(frozen=True)
class ReporteGenerado:
    """Documento final listo para visualizar, imprimir o enviar; se guarda en el historial (MySQL)."""
    id: str
    titulo: str
    tipo: str
    periodo: str
    alcance: str
    autor: str
    fecha_generacion: str
    tipo_contenido: str
    contenido: str
    metadatos: dict[str, str] = field(default_factory=dict)
    capas: tuple[str, ...] = ()

    @property
    def esta_firmado(self) -> bool:
        return "firma.valor" in self.metadatos


@dataclass(frozen=True)
class ResultadoVerificacion:
    id_reporte: str
    valido: bool
    mensaje: str
    hash_registrado: str | None
    hash_calculado: str | None
