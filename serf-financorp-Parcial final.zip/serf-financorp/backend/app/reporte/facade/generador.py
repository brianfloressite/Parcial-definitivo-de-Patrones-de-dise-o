"""Patrón Facade – GeneradorReportesFacade: una sola llamada para generar el reporte completo.

``generar_reporte(solicitud)`` coordina todo el subsistema sin que el usuario (ni la API) conozca sus clases:

1. **Singleton** – consulta moneda, formato y parámetros en ``ConfiguracionGlobal``.
2. Consolidación de ventas e inventarios de las filiales (MySQL).
3. **Prototype** – clona la plantilla del tipo solicitado y la adapta al país.
4. **Builder** – el Director ensambla el reporte paso a paso.
5. **Composite** – secciones y subsecciones jerárquicas (dentro del Builder).
6. **Decorator** – apila confidencialidad, marca de agua y firma digital.
7. Guarda el resultado en el historial y lo devuelve.
"""
from __future__ import annotations

import re
import uuid
from datetime import datetime

from ...config.configuracion_global import ConfiguracionGlobal
from ...dominio import RecursoNoEncontradoError
from ...servicio.consolidacion import ConsolidacionService
from ...servicio.periodo import Periodo
from ...servicio.puertos import UnidadDeTrabajo, transaccion
from ..builder.director import DirectorReportes
from ..builder.reporte import RenderizadorHtml, RenderizadorReporte, RenderizadorTexto, ReporteFinancieroBuilder
from ..decorator.documentos import (ConfidencialidadDecorator, DocumentoReporte, DocumentoReporteBase,
                                    FirmaDigitalDecorator, MarcaDeAguaDecorator)
from ..firma.firmador import Firmador, sha256_hex
from ..prototype.plantillas import RegistroPlantillas
from ..tipo_reporte import TipoReporte
from .resultados import ReporteGenerado, ResultadoVerificacion, SolicitudReporte


class GeneradorReportesFacade:

    def __init__(self, configuracion: ConfiguracionGlobal, consolidacion: ConsolidacionService,
                 plantillas: RegistroPlantillas, director: DirectorReportes, firmador: Firmador,
                 uow: UnidadDeTrabajo) -> None:
        self._config = configuracion
        self._consolidacion = consolidacion
        self._plantillas = plantillas
        self._director = director
        self._firmador = firmador
        self._uow = uow

    # ------------------------------------------------------------------ operación única
    def generar_reporte(self, solicitud: SolicitudReporte) -> ReporteGenerado:
        if solicitud is None:
            raise ValueError("La solicitud de reporte es obligatoria")
        tipo = TipoReporte.desde_texto(solicitud.tipo)
        periodo = self._periodo_de(tipo, solicitud)
        autor = (solicitud.autor or "").strip() or "Área de Contabilidad"
        codigo_filial = (solicitud.codigo_filial or "").strip().upper() or None

        datos = self._consolidacion.consolidar(periodo, codigo_filial)                    # 1-2
        plantilla = self._plantillas.obtener_para_pais(tipo, codigo_filial)                # 3 Prototype
        reporte = self._director.construir(tipo, ReporteFinancieroBuilder(plantilla, self._config),
                                           datos, autor)                                   # 4-5 Builder+Composite
        documento: DocumentoReporte = DocumentoReporteBase(reporte, self._renderizador(solicitud.formato))
        if solicitud.confidencial:                                                         # 6 Decorator
            documento = ConfidencialidadDecorator(documento, "CONFIDENCIAL")
        if solicitud.marca_agua:
            documento = MarcaDeAguaDecorator(documento, self._config.texto_marca_agua)
        if solicitud.firma_digital:                                # la firma va al final y protege todo
            documento = FirmaDigitalDecorator(documento, self._firmador, self._config.firmante_autorizado)

        generado = ReporteGenerado(
            id=uuid.uuid4().hex[:8].upper(), titulo=documento.titulo, tipo=tipo.name, periodo=periodo.etiqueta,
            alcance=datos.alcance, autor=autor, fecha_generacion=self._config.formatear_fecha_hora(datetime.now()),
            tipo_contenido=documento.tipo_contenido, contenido=documento.contenido,
            metadatos=documento.metadatos, capas=documento.capas)
        with transaccion(self._uow):                                                       # 7 historial
            self._uow.reportes.guardar(generado)
        return generado

    def generar_reporte_mensual_consolidado(self, anio: int, mes: int, autor: str) -> ReporteGenerado:
        """Atajo del flujo descrito en el caso práctico."""
        return self.generar_reporte(SolicitudReporte.mensual_consolidado(anio, mes, autor))

    # ------------------------------------------------------------------ consulta y verificación
    def obtener(self, identificador: str) -> ReporteGenerado:
        reporte = self._uow.reportes.buscar_por_id(identificador)
        if reporte is None:
            raise RecursoNoEncontradoError("Reporte", str(identificador))
        return reporte

    def historial(self) -> list[ReporteGenerado]:
        return self._uow.reportes.listar_todos()

    def verificar_integridad(self, identificador: str) -> ResultadoVerificacion:
        original = self.obtener(identificador)
        return self._verificar(original.id, original.contenido, original)

    def verificar_contenido(self, identificador: str, contenido_presentado: str) -> ResultadoVerificacion:
        """Verifica una copia presentada del reporte (detecta alteraciones)."""
        return self._verificar(identificador, contenido_presentado, self.obtener(identificador))

    def verificar_copia_alterada(self, identificador: str) -> ResultadoVerificacion:
        """Demostración: adultera la primera cifra en euros (antepone un 9) y verifica esa copia."""
        original = self.obtener(identificador)
        alterado = re.sub(r"(€ )(\d)", r"\g<1>9\2", original.contenido, count=1)
        return self._verificar(identificador, alterado, original)

    def _verificar(self, identificador: str, contenido: str, original: ReporteGenerado) -> ResultadoVerificacion:
        if not original.esta_firmado:
            return ResultadoVerificacion(identificador, False, "El reporte no fue firmado digitalmente", None, None)
        hash_registrado = original.metadatos.get("firma.hashSha256")
        firmado = FirmaDigitalDecorator.extraer_contenido_firmado(contenido)
        if firmado is None:
            return ResultadoVerificacion(identificador, False, "No se encontró el bloque firmado en el documento",
                                         hash_registrado, None)
        valido = self._firmador.verificar(firmado, original.metadatos.get("firma.valor", ""))
        mensaje = ("Firma válida: el contenido no ha sido modificado desde su emisión" if valido
                   else "Firma inválida: el contenido fue alterado o la firma no corresponde")
        return ResultadoVerificacion(identificador, valido, mensaje, hash_registrado, sha256_hex(firmado))

    # ------------------------------------------------------------------ auxiliares
    @staticmethod
    def _periodo_de(tipo: TipoReporte, s: SolicitudReporte) -> Periodo:
        if s.anio is None:
            raise ValueError("El año es obligatorio")
        if tipo is TipoReporte.MENSUAL_INGRESOS:
            if s.mes is None:
                raise ValueError("El mes es obligatorio para el reporte mensual")
            return Periodo.mensual(s.anio, s.mes)
        if tipo is TipoReporte.TRIMESTRAL_GASTOS_INGRESOS:
            if s.trimestre is None:
                raise ValueError("El trimestre es obligatorio para el reporte trimestral")
            return Periodo.trimestral(s.anio, s.trimestre)
        return Periodo.anual(s.anio)

    @staticmethod
    def _renderizador(formato: str | None) -> RenderizadorReporte:
        return RenderizadorTexto() if (formato or "").strip().upper() == "TEXTO" else RenderizadorHtml()
