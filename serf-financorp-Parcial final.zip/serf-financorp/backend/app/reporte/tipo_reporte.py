"""Tipos de reporte corporativo definidos en el caso FinanCorp."""
from enum import Enum


class TipoReporte(Enum):
    MENSUAL_INGRESOS = "Reporte mensual de ingresos"
    TRIMESTRAL_GASTOS_INGRESOS = "Reporte trimestral de gastos e ingresos"
    ANUAL_CONSOLIDADO = "Reporte anual consolidado"

    @property
    def nombre(self) -> str:
        return self.value

    @classmethod
    def desde_texto(cls, texto: str | None) -> "TipoReporte":
        if texto is None or not str(texto).strip():
            raise ValueError("El tipo de reporte es obligatorio")
        try:
            return cls[str(texto).strip().upper()]
        except KeyError:
            raise ValueError(f"Tipo de reporte no válido: {texto}") from None
