"""Patrón Builder – Director: conoce las "recetas" de cada tipo de reporte.

Decide qué pasos invocar y en qué orden, y arma la jerarquía Composite (secciones → subsecciones →
tablas/gráficos) a partir de los datos consolidados, pero delega la creación del producto en el
``ConstructorReporte`` que recibe.
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

from ...config.configuracion_global import ConfiguracionGlobal
from ...dominio import Dinero
from ...servicio.consolidacion import DatosConsolidados
from ..composite.componentes import (GraficoBarrasReporte, IndicadoresReporte, ParrafoReporte,
                                     SeccionReporte, TablaReporte)
from ..prototype.plantillas import (PlantillaReporteAnual as Anual, PlantillaReporteMensual as Mensual,
                                    PlantillaReporteTrimestral as Trimestral)
from ..tipo_reporte import TipoReporte
from .reporte import ConstructorReporte, ReporteFinanciero


def _pct(valor: float) -> str:
    return f"{Decimal(str(valor)).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)}%"


def _participacion(parte: Dinero, total: Dinero) -> str:
    if not total.es_positivo():
        return "0.0%"
    return _pct(float(parte.monto / total.monto * 100))


def _montos(mapa: dict[str, Dinero]) -> dict[str, Decimal]:
    return {k: max(v.monto, Decimal(0)) for k, v in mapa.items()}


class DirectorReportes:

    def __init__(self, configuracion: ConfiguracionGlobal) -> None:
        self._config = configuracion
        self._recetas = {
            TipoReporte.MENSUAL_INGRESOS: self._receta_mensual,
            TipoReporte.TRIMESTRAL_GASTOS_INGRESOS: self._receta_trimestral,
            TipoReporte.ANUAL_CONSOLIDADO: self._receta_anual,
        }

    def construir(self, tipo: TipoReporte, builder: ConstructorReporte, datos: DatosConsolidados,
                  autor: str) -> ReporteFinanciero:
        if not isinstance(tipo, TipoReporte):
            raise ValueError("El tipo de reporte es obligatorio")
        if builder is None:
            raise ValueError("El builder es obligatorio")
        if datos is None:
            raise ValueError("Los datos consolidados son obligatorios")
        (builder.periodo(datos.periodo.etiqueta)
                .alcance(datos.alcance)
                .autor(autor)
                .subtitulo(f"{datos.alcance} · {datos.periodo.etiqueta}"))
        return self._recetas[tipo](builder, datos)

    # ------------------------------------------------------------------ recetas
    def _receta_mensual(self, b: ConstructorReporte, d: DatosConsolidados) -> ReporteFinanciero:
        return (b.seccion(self._resumen_ejecutivo(Mensual.SECCION_RESUMEN, d))
                 .seccion(self._ingresos_por_pais(Mensual.SECCION_PAIS, d))
                 .seccion(self._ingresos_por_categoria(Mensual.SECCION_CATEGORIA, d))
                 .seccion(self._conclusiones(Mensual.SECCION_CONCLUSIONES, d))
                 .construir())

    def _receta_trimestral(self, b: ConstructorReporte, d: DatosConsolidados) -> ReporteFinanciero:
        ingresos = (SeccionReporte.de(Trimestral.SECCION_INGRESOS)
                    .agregar(GraficoBarrasReporte("Ingresos por mes", self._moneda, _montos(d.ingresos_por_mes)))
                    .agregar(self._ingresos_por_pais("Detalle por país", d))
                    .agregar(self._ingresos_por_categoria("Detalle por categoría", d)))
        return (b.seccion(self._resumen_ejecutivo(Trimestral.SECCION_RESUMEN, d))
                 .seccion(ingresos)
                 .seccion(self._gastos_importacion(Trimestral.SECCION_GASTOS, d))
                 .seccion(self._resultado_por_pais(Trimestral.SECCION_RESULTADO, d))
                 .seccion(self._conclusiones(Trimestral.SECCION_CONCLUSIONES, d))
                 .construir())

    def _receta_anual(self, b: ConstructorReporte, d: DatosConsolidados) -> ReporteFinanciero:
        meses = TablaReporte("Ingresos mensuales", ["Mes", f"Ingresos {self._moneda}"])
        for mes, monto in d.ingresos_por_mes.items():
            meses.fila(mes, self._fmt(monto))
        meses.total("Total", self._fmt(d.ingresos))
        evolucion = (SeccionReporte.de(Anual.SECCION_EVOLUCION)
                     .agregar(GraficoBarrasReporte("Ingresos por mes", self._moneda, _montos(d.ingresos_por_mes)))
                     .agregar(meses))
        inventario = (SeccionReporte.de(Anual.SECCION_INVENTARIO)
                      .agregar(self._gastos_importacion("Gastos de importación del año", d))
                      .agregar(SeccionReporte.de("Inventario valorizado al cierre").agregar(ParrafoReporte(
                          f"El inventario disponible, valorizado a costo de importación, asciende a "
                          f"{self._fmt(d.inventario_valorizado)}. {d.productos_con_stock_bajo} producto(s) se "
                          f"encuentran en el umbral de stock bajo y requieren reposición."))))
        return (b.seccion(self._resumen_ejecutivo(Anual.SECCION_RESUMEN, d))
                 .seccion(evolucion)
                 .seccion(self._resultado_por_pais(Anual.SECCION_PAIS, d))
                 .seccion(self._ingresos_por_categoria(Anual.SECCION_CATEGORIA, d))
                 .seccion(inventario)
                 .seccion(self._conclusiones(Anual.SECCION_CONCLUSIONES, d))
                 .construir())

    # ------------------------------------------------------------ piezas Composite
    def _resumen_ejecutivo(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        kpis = (IndicadoresReporte("Indicadores clave")
                .agregar("Ingresos", self._fmt(d.ingresos), f"{d.numero_ventas} ventas")
                .agregar("Costo de importación", self._fmt(d.costo_importacion), "Costo CNY convertido")
                .agregar("Margen bruto", self._fmt(d.margen_bruto), f"{_pct(d.margen_porcentual)} de los ingresos")
                .agregar("Unidades vendidas", str(d.unidades_vendidas), f"{len(d.ingresos_por_pais)} país(es)"))
        if d.sin_movimientos:
            texto = f"No se registraron ventas en {d.periodo.etiqueta} para el alcance seleccionado."
        else:
            texto = (f"Durante {d.periodo.etiqueta} se registraron {d.numero_ventas} ventas ({d.unidades_vendidas} "
                     f"unidades) con ingresos de {self._fmt(d.ingresos)} y un margen bruto de "
                     f"{self._fmt(d.margen_bruto)} ({_pct(d.margen_porcentual)}).")
        return SeccionReporte.de(titulo).agregar(kpis).agregar(ParrafoReporte(texto, destacado=True))

    def _ingresos_por_pais(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        """Una subsección por país y, dentro de cada una, su desglose por categoría."""
        seccion = SeccionReporte.de(titulo)
        if d.sin_movimientos:
            return seccion
        tabla = TablaReporte("Ingresos por país", ["País", f"Ingresos {self._moneda}", "Participación"])
        for pais, monto in d.ingresos_por_pais.items():
            tabla.fila(pais, self._fmt(monto), _participacion(monto, d.ingresos))
        tabla.total("Total", self._fmt(d.ingresos), "100.0%")
        seccion.agregar(GraficoBarrasReporte("Comparativo de ingresos por país", self._moneda,
                                             _montos(d.ingresos_por_pais))).agregar(tabla)
        for pais, categorias in d.ingresos_por_pais_y_categoria.items():
            t = TablaReporte(f"Categorías vendidas en {pais}", ["Categoría", f"Ingresos {self._moneda}"])
            for cat, monto in categorias.items():
                t.fila(cat, self._fmt(monto))
            seccion.agregar(SeccionReporte.de(pais).agregar(t))       # subsección por país
        return seccion

    def _ingresos_por_categoria(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        seccion = SeccionReporte.de(titulo)
        if d.sin_movimientos:
            return seccion
        tabla = TablaReporte("Ingresos por categoría", ["Categoría", f"Ingresos {self._moneda}", "Participación"])
        for cat, monto in d.ingresos_por_categoria.items():
            tabla.fila(cat, self._fmt(monto), _participacion(monto, d.ingresos))
        top = TablaReporte("Productos más vendidos", ["Producto", "Unidades", f"Ingresos {self._moneda}"])
        for f in d.productos_mas_vendidos:
            top.fila(f.nombre, str(f.unidades), self._fmt(f.ingresos))
        return (seccion.agregar(GraficoBarrasReporte("Comparativo por categoría", self._moneda,
                                                     _montos(d.ingresos_por_categoria)))
                       .agregar(tabla)
                       .agregar(SeccionReporte.de("Productos más vendidos").agregar(top)))

    def _gastos_importacion(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        seccion = SeccionReporte.de(titulo)
        if d.sin_movimientos:
            return seccion
        tabla = TablaReporte("Costo de importación de lo vendido", ["País", f"Costo {self._moneda}", "Sobre ingresos"])
        for pais, costo in d.costo_por_pais.items():
            tabla.fila(pais, self._fmt(costo), _participacion(costo, d.ingresos_por_pais.get(pais, costo)))
        tabla.total("Total", self._fmt(d.costo_importacion), _participacion(d.costo_importacion, d.ingresos))
        return (seccion.agregar(ParrafoReporte(
                    f"Los costos se registran en CNY (proveedores de Shenzhen) y se convierten a {self._moneda} "
                    f"con la tasa corporativa vigente."))
                       .agregar(tabla))

    def _resultado_por_pais(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        seccion = SeccionReporte.de(titulo)
        if d.sin_movimientos:
            return seccion
        tabla = TablaReporte("Ingresos, costos y margen por país",
                             ["País", "Ingresos", "Costo importación", "Margen bruto", "Margen %"])
        margenes: dict[str, Decimal] = {}
        for pais, ingreso in d.ingresos_por_pais.items():
            costo = d.costo_por_pais.get(pais, Dinero.cero(ingreso.moneda))
            margen = ingreso - costo
            margenes[pais] = max(margen.monto, Decimal(0))
            tabla.fila(pais, self._fmt(ingreso), self._fmt(costo), self._fmt(margen), _participacion(margen, ingreso))
        tabla.total("Total", self._fmt(d.ingresos), self._fmt(d.costo_importacion), self._fmt(d.margen_bruto),
                    _pct(d.margen_porcentual))
        return seccion.agregar(tabla).agregar(GraficoBarrasReporte("Margen bruto por país", self._moneda, margenes))

    def _conclusiones(self, titulo: str, d: DatosConsolidados) -> SeccionReporte:
        seccion = SeccionReporte.de(titulo)
        if d.sin_movimientos:
            return seccion.agregar(ParrafoReporte("Sin movimientos en el período: no se emiten conclusiones comerciales."))
        pais, monto_pais = next(iter(d.ingresos_por_pais.items()))
        categoria, monto_cat = next(iter(d.ingresos_por_categoria.items()))
        seccion.agregar(ParrafoReporte(f"{pais} lidera los ingresos del período con {self._fmt(monto_pais)} "
                                       f"({_participacion(monto_pais, d.ingresos)} del total)."))
        seccion.agregar(ParrafoReporte(f"La categoría con mayor aporte es {categoria} con {self._fmt(monto_cat)}."))
        if d.margen_porcentual >= 25:
            texto = f"El margen bruto de {_pct(d.margen_porcentual)} se mantiene saludable frente al costo de importación."
        else:
            texto = (f"El margen bruto de {_pct(d.margen_porcentual)} es ajustado; se recomienda revisar precios o "
                     f"costos de importación.")
        seccion.agregar(ParrafoReporte(texto))
        if d.productos_con_stock_bajo > 0:
            seccion.agregar(ParrafoReporte(f"Se recomienda reponer {d.productos_con_stock_bajo} producto(s) con "
                                           f"stock bajo para no perder ventas.", destacado=True))
        return seccion

    # ------------------------------------------------------------------ formato
    @property
    def _moneda(self) -> str:
        return self._config.moneda_corporativa.name

    def _fmt(self, dinero: Dinero) -> str:
        return self._config.formatear(dinero)
