"""Patrón Builder – producto, constructor y renderizadores (requisito complementario 3).

* ``ReporteFinanciero`` es el **producto** inmutable.
* ``ConstructorReporte`` es la interfaz del builder (API fluida); ``ReporteFinancieroBuilder`` la implementa
  partiendo de una plantilla clonada (Prototype) y de la configuración corporativa (Singleton).
* La **representación** está separada de la construcción: el mismo reporte se muestra en HTML o en texto
  con un ``RenderizadorReporte`` distinto.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from ...config.configuracion_global import ConfiguracionGlobal
from ...dominio.excepciones import OperacionNoValidaError
from ..composite.componentes import ComponenteReporte, escapar
from ..prototype.plantillas import EstiloReporte, PlantillaReporte
from ..tipo_reporte import TipoReporte


class ReporteFinanciero:
    """Producto: reporte ya ensamblado. Solo se crea mediante el builder y no cambia después."""

    __slots__ = ("_titulo", "_subtitulo", "_tipo", "_periodo", "_alcance", "_autor", "_moneda",
                 "_empresa", "_nota_legal", "_fecha", "_estilo", "_secciones")

    def __init__(self, *, titulo: str, subtitulo: str, tipo: TipoReporte, periodo: str, alcance: str,
                 autor: str, moneda_corporativa: str, nombre_empresa: str, nota_legal: str,
                 fecha_generacion: datetime, estilo: EstiloReporte,
                 secciones: list[ComponenteReporte]) -> None:
        self._titulo, self._subtitulo, self._tipo = titulo, subtitulo, tipo
        self._periodo, self._alcance, self._autor = periodo, alcance, autor
        self._moneda, self._empresa, self._nota_legal = moneda_corporativa, nombre_empresa, nota_legal
        self._fecha = fecha_generacion
        self._estilo = estilo.clonar()                 # copia defensiva
        self._secciones = tuple(secciones)             # colección inmutable

    def renderizar(self, renderizador: "RenderizadorReporte") -> str:
        return renderizador.renderizar(self)

    def total_componentes(self) -> int:
        return sum(s.contar_elementos() for s in self._secciones)

    titulo = property(lambda self: self._titulo)
    subtitulo = property(lambda self: self._subtitulo)
    tipo = property(lambda self: self._tipo)
    periodo = property(lambda self: self._periodo)
    alcance = property(lambda self: self._alcance)
    autor = property(lambda self: self._autor)
    moneda_corporativa = property(lambda self: self._moneda)
    nombre_empresa = property(lambda self: self._empresa)
    nota_legal = property(lambda self: self._nota_legal)
    fecha_generacion = property(lambda self: self._fecha)
    secciones = property(lambda self: self._secciones)

    @property
    def estilo(self) -> EstiloReporte:
        return self._estilo.clonar()


class ConstructorReporte(ABC):
    """Interfaz Builder. El Director depende de ella, no del builder concreto (DIP)."""

    @abstractmethod
    def titulo(self, titulo: str) -> "ConstructorReporte": ...

    @abstractmethod
    def subtitulo(self, subtitulo: str) -> "ConstructorReporte": ...

    @abstractmethod
    def periodo(self, periodo: str) -> "ConstructorReporte": ...

    @abstractmethod
    def alcance(self, alcance: str) -> "ConstructorReporte": ...

    @abstractmethod
    def autor(self, autor: str) -> "ConstructorReporte": ...

    @abstractmethod
    def seccion(self, seccion: ComponenteReporte) -> "ConstructorReporte":
        """Agrega una sección de primer nivel (normalmente un compuesto con subsecciones)."""

    @abstractmethod
    def construir(self) -> ReporteFinanciero:
        """Valida los pasos obligatorios y devuelve el producto final."""


def _requerido(valor: str | None, campo: str) -> str:
    if valor is None or not str(valor).strip():
        raise ValueError(f"El {campo} del reporte es obligatorio")
    return str(valor).strip()


class ReporteFinancieroBuilder(ConstructorReporte):
    """Builder concreto. Uso::

        reporte = (ReporteFinancieroBuilder(plantilla, config)
                   .periodo("Octubre 2026").autor("Contabilidad")
                   .seccion(resumen).seccion(ingresos_por_pais)
                   .construir())

    ``construir()`` exige todas las secciones obligatorias de la plantilla. Un builder construye una sola
    vez, para no arrastrar estado de un reporte a otro.
    """

    def __init__(self, plantilla: PlantillaReporte, configuracion: ConfiguracionGlobal) -> None:
        if not isinstance(plantilla, PlantillaReporte):
            raise ValueError("La plantilla es obligatoria")
        if configuracion is None:
            raise ValueError("La configuración es obligatoria")
        self._plantilla = plantilla
        self._config = configuracion
        self._titulo = plantilla.titulo_base
        self._subtitulo = ""
        self._periodo: str | None = None
        self._alcance = "Consolidado corporativo"
        self._autor: str | None = None
        self._secciones: list[ComponenteReporte] = []
        self._construido = False

    def _abierto(self) -> None:
        if self._construido:
            raise OperacionNoValidaError("Este builder ya construyó un reporte; cree uno nuevo")

    def titulo(self, titulo: str) -> "ReporteFinancieroBuilder":
        self._abierto()
        self._titulo = _requerido(titulo, "título")
        return self

    def subtitulo(self, subtitulo: str) -> "ReporteFinancieroBuilder":
        self._abierto()
        self._subtitulo = (subtitulo or "").strip()
        return self

    def periodo(self, periodo: str) -> "ReporteFinancieroBuilder":
        self._abierto()
        self._periodo = _requerido(periodo, "período")
        return self

    def alcance(self, alcance: str) -> "ReporteFinancieroBuilder":
        self._abierto()
        self._alcance = _requerido(alcance, "alcance")
        return self

    def autor(self, autor: str) -> "ReporteFinancieroBuilder":
        self._abierto()
        self._autor = _requerido(autor, "autor")
        return self

    def seccion(self, seccion: ComponenteReporte) -> "ReporteFinancieroBuilder":
        self._abierto()
        if not isinstance(seccion, ComponenteReporte):
            raise ValueError("La sección no puede ser nula")
        self._secciones.append(seccion)
        return self

    def construir(self) -> ReporteFinanciero:
        self._abierto()
        if self._periodo is None:
            raise OperacionNoValidaError("Falta indicar el período del reporte")
        if self._autor is None:
            raise OperacionNoValidaError("Falta indicar el autor del reporte")
        if not self._secciones:
            raise OperacionNoValidaError("El reporte debe tener al menos una sección")
        presentes = {s.titulo for s in self._secciones}
        faltantes = [s for s in self._plantilla.secciones_obligatorias if s not in presentes]
        if faltantes:
            raise OperacionNoValidaError(f"Faltan secciones obligatorias de la plantilla: {faltantes}")
        self._construido = True
        return ReporteFinanciero(
            titulo=self._titulo, subtitulo=self._subtitulo, tipo=self._plantilla.tipo, periodo=self._periodo,
            alcance=self._alcance, autor=self._autor, moneda_corporativa=self._config.moneda_corporativa.name,
            nombre_empresa=self._config.nombre_empresa, nota_legal=self._plantilla.nota_legal,
            fecha_generacion=datetime.now(), estilo=self._plantilla.estilo, secciones=self._secciones)


# ------------------------------------------------------------------ representaciones
class RenderizadorReporte(ABC):
    """Estrategia de representación: separa la representación de la construcción."""

    @abstractmethod
    def renderizar(self, reporte: ReporteFinanciero) -> str: ...

    @property
    @abstractmethod
    def tipo_contenido(self) -> str: ...


class RenderizadorHtml(RenderizadorReporte):
    """HTML con los colores de la plantilla clonada (se ve en la web y se imprime a PDF)."""

    tipo_contenido = "text/html"

    def renderizar(self, r: ReporteFinanciero) -> str:
        e = r.estilo

        def dato(k: str, v: str) -> str:
            return f"<div><dt>{escapar(k)}</dt><dd>{escapar(v)}</dd></div>"

        subtitulo = f'<p class="rep-subtitulo">{escapar(r.subtitulo)}</p>' if r.subtitulo else ""
        ficha = "".join([dato("Período", r.periodo), dato("Alcance", r.alcance),
                         dato("Moneda", r.moneda_corporativa), dato("Elaborado por", r.autor),
                         dato("Generado", r.fecha_generacion.strftime("%d/%m/%Y %H:%M"))])
        cuerpo = "".join(s.renderizar_html(0) for s in r.secciones)
        return (f'<article class="reporte-serf" style="--rep-primario:{e.color_primario};--rep-acento:{e.color_acento}">'
                f'<header class="rep-cabecera"><div class="rep-empresa">{escapar(r.nombre_empresa)} · Sistema SERF</div>'
                f"<h1>{escapar(r.titulo)}</h1>{subtitulo}<dl class=\"rep-ficha\">{ficha}</dl></header>"
                f'<div class="rep-cuerpo">{cuerpo}</div><footer class="rep-pie"><p>{escapar(r.nota_legal)}</p>'
                f"<p>Importes expresados en {escapar(r.moneda_corporativa)} según las tasas de la configuración "
                f"corporativa vigente.</p></footer></article>")


class RenderizadorTexto(RenderizadorReporte):
    """Texto plano (consola, correo o auditoría)."""

    tipo_contenido = "text/plain"

    def renderizar(self, r: ReporteFinanciero) -> str:
        linea = "=" * 72
        cabecera = (f"{linea}\n{r.nombre_empresa} — {r.titulo.upper()}\n"
                    f"Período: {r.periodo} | Alcance: {r.alcance} | Moneda: {r.moneda_corporativa}\n"
                    f"Elaborado por: {r.autor} | Generado: {r.fecha_generacion.strftime('%d/%m/%Y %H:%M')}\n{linea}\n")
        cuerpo = "".join(s.renderizar_texto(0) + "\n" for s in r.secciones)
        return f"{cabecera}{cuerpo}{linea}\n{r.nota_legal}\n"
