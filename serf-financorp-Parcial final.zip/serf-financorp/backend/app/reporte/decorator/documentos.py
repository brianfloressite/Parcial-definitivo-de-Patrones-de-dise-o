"""Patrón Decorator – características extra sin modificar el reporte original (requisito complementario 6).

``DocumentoReporte`` es la interfaz del entregable. ``DocumentoReporteBase`` es el componente concreto
(el reporte del Builder representado en HTML o texto). Cada decorador envuelve otro documento, le delega
por defecto y agrega una capa: franja de confidencialidad, marca de agua o firma digital. Las capas se
apilan en cualquier orden y el cliente trata igual a un documento "desnudo" que a uno decorado (LSP).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Mapping

from ..builder.reporte import RenderizadorReporte, ReporteFinanciero
from ..composite.componentes import escapar
from ..firma.firmador import FirmaDigital, Firmador


class DocumentoReporte(ABC):
    """Interfaz mínima del documento entregable (ISP)."""

    @property
    @abstractmethod
    def titulo(self) -> str: ...

    @property
    @abstractmethod
    def contenido(self) -> str:
        """Contenido final con todas las capas aplicadas."""

    @property
    @abstractmethod
    def tipo_contenido(self) -> str: ...

    @property
    @abstractmethod
    def metadatos(self) -> dict[str, str]:
        """Metadatos acumulados por las capas (firma, hash, marca de agua…)."""

    @property
    @abstractmethod
    def capas(self) -> tuple[str, ...]:
        """Capas aplicadas, de la más interna a la más externa."""


class DocumentoReporteBase(DocumentoReporte):
    """Componente concreto: el reporte original sin características adicionales."""

    def __init__(self, reporte: ReporteFinanciero, renderizador: RenderizadorReporte) -> None:
        if reporte is None:
            raise ValueError("El reporte es obligatorio")
        if renderizador is None:
            raise ValueError("El renderizador es obligatorio")
        self._reporte = reporte
        self._renderizador = renderizador
        self._contenido: str | None = None           # se calcula una sola vez

    @property
    def titulo(self) -> str:
        return self._reporte.titulo

    @property
    def contenido(self) -> str:
        if self._contenido is None:
            self._contenido = self._reporte.renderizar(self._renderizador)
        return self._contenido

    @property
    def tipo_contenido(self) -> str:
        return self._renderizador.tipo_contenido

    @property
    def metadatos(self) -> dict[str, str]:
        r = self._reporte
        return {"tipo": r.tipo.name, "periodo": r.periodo, "alcance": r.alcance,
                "moneda": r.moneda_corporativa, "componentes": str(r.total_componentes())}

    @property
    def capas(self) -> tuple[str, ...]:
        return ("Documento base",)


class DocumentoReporteDecorator(DocumentoReporte, ABC):
    """Decorador abstracto: envuelve otro documento y le delega todo por defecto (OCP)."""

    def __init__(self, envuelto: DocumentoReporte) -> None:
        if not isinstance(envuelto, DocumentoReporte):
            raise ValueError("El documento a decorar es obligatorio")
        self._envuelto = envuelto

    @property
    @abstractmethod
    def nombre_capa(self) -> str: ...

    def metadatos_propios(self) -> Mapping[str, str]:
        return {}

    @property
    def titulo(self) -> str:
        return self._envuelto.titulo

    @property
    def contenido(self) -> str:
        return self._envuelto.contenido

    @property
    def tipo_contenido(self) -> str:
        return self._envuelto.tipo_contenido

    @property
    def metadatos(self) -> dict[str, str]:
        return {**self._envuelto.metadatos, **self.metadatos_propios()}

    @property
    def capas(self) -> tuple[str, ...]:
        return (*self._envuelto.capas, self.nombre_capa)

    @property
    def es_html(self) -> bool:
        return self.tipo_contenido == "text/html"


class ConfidencialidadDecorator(DocumentoReporteDecorator):
    """Agrega una franja con la clasificación de la información."""

    def __init__(self, envuelto: DocumentoReporte, clasificacion: str = "CONFIDENCIAL") -> None:
        super().__init__(envuelto)
        self._clasificacion = (clasificacion or "CONFIDENCIAL").strip().upper()

    @property
    def nombre_capa(self) -> str:
        return f"Clasificación {self._clasificacion.lower()}"

    def metadatos_propios(self) -> Mapping[str, str]:
        return {"clasificacion": self._clasificacion}

    @property
    def contenido(self) -> str:
        aviso = f"{self._clasificacion} — Distribución restringida a la Gerencia Corporativa de FinanCorp S.A."
        if not self.es_html:
            return f"[{aviso}]\n{self._envuelto.contenido}"
        return f'<div class="dec-confidencial" role="note">{escapar(aviso)}</div>{self._envuelto.contenido}'


class MarcaDeAguaDecorator(DocumentoReporteDecorator):
    """Superpone una marca de agua corporativa."""

    def __init__(self, envuelto: DocumentoReporte, texto: str) -> None:
        super().__init__(envuelto)
        if not texto or not texto.strip():
            raise ValueError("El texto de la marca de agua es obligatorio")
        self._texto = texto.strip()

    @property
    def nombre_capa(self) -> str:
        return "Marca de agua"

    def metadatos_propios(self) -> Mapping[str, str]:
        return {"marcaAgua": self._texto}

    @property
    def contenido(self) -> str:
        interno = self._envuelto.contenido
        if not self.es_html:
            return f"*** {self._texto} ***\n{interno}*** {self._texto} ***\n"
        t = escapar(self._texto)
        capa = '<div class="dec-marca-agua" aria-hidden="true">' + f"<span>{t}</span>" * 12 + "</div>"
        return f'<div class="dec-con-marca" data-marca-agua="{t}">{capa}{interno}</div>'


class FirmaDigitalDecorator(DocumentoReporteDecorator):
    """Firma el contenido de las capas internas y agrega un bloque de verificación (RF10, RNF10).
    El contenido firmado queda entre marcadores para poder verificar su integridad más tarde."""

    INICIO_FIRMADO = "<!--SERF-FIRMADO-INICIO-->"
    FIN_FIRMADO = "<!--SERF-FIRMADO-FIN-->"

    def __init__(self, envuelto: DocumentoReporte, firmador: Firmador, firmante: str) -> None:
        super().__init__(envuelto)
        if firmador is None:
            raise ValueError("El firmador es obligatorio")
        if not firmante or not firmante.strip():
            raise ValueError("El firmante es obligatorio")
        self._firmador = firmador
        self._firmante = firmante.strip()
        self._firma: FirmaDigital | None = None

    def _obtener_firma(self) -> FirmaDigital:
        if self._firma is None:                       # se firma una sola vez, sobre el contenido interno
            self._firma = self._firmador.firmar(self._envuelto.contenido)
        return self._firma

    @property
    def nombre_capa(self) -> str:
        return "Firma digital"

    def metadatos_propios(self) -> Mapping[str, str]:
        f = self._obtener_firma()
        return {"firma.firmante": self._firmante, "firma.algoritmo": f.algoritmo,
                "firma.hashSha256": f.hash_sha256, "firma.valor": f.firma_base64,
                "firma.huellaClave": f.huella_clave_publica, "firma.fecha": f.fecha.isoformat(timespec="seconds")}

    @property
    def contenido(self) -> str:
        interno = self._envuelto.contenido
        f = self._obtener_firma()
        fecha = f.fecha.strftime("%d/%m/%Y %H:%M:%S")
        firmado = f"{self.INICIO_FIRMADO}{interno}{self.FIN_FIRMADO}"
        if not self.es_html:
            return (f"{firmado}\n--- FIRMA DIGITAL ---\nFirmante: {self._firmante}\nAlgoritmo: {f.algoritmo}\n"
                    f"SHA-256: {f.hash_sha256}\nFecha: {fecha}\n")
        return (f'{firmado}<aside class="dec-firma" aria-label="Firma digital"><div class="dec-firma-sello">✔</div><div>'
                f"<strong>Documento firmado digitalmente</strong><span>Firmante: {escapar(self._firmante)}</span>"
                f"<span>Algoritmo: {escapar(f.algoritmo)} · Clave {escapar(f.huella_clave_publica)}</span>"
                f"<span>Fecha: {fecha}</span><code>SHA-256: {f.hash_sha256}</code></div></aside>")

    @classmethod
    def extraer_contenido_firmado(cls, contenido_final: str | None) -> str | None:
        """Porción firmada de un contenido final (``None`` si no hay marcadores)."""
        if not contenido_final:
            return None
        i = contenido_final.find(cls.INICIO_FIRMADO)
        j = contenido_final.rfind(cls.FIN_FIRMADO)
        if i < 0 or j < i:
            return None
        return contenido_final[i + len(cls.INICIO_FIRMADO):j]
