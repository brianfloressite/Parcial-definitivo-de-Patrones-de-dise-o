"""Firma digital real: RSA-2048 + SHA-256 (PKCS#1 v1.5, equivalente a SHA256withRSA de Java).

Garantiza integridad (cualquier cambio invalida la firma) y no repudio (solo quien posee la clave privada
puede firmar). La clave privada se guarda en un archivo PEM (``SERF_CLAVE_FIRMA``) para que los reportes
guardados en MySQL sigan verificándose después de reiniciar el servidor.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


@dataclass(frozen=True)
class FirmaDigital:
    hash_sha256: str
    firma_base64: str
    algoritmo: str
    huella_clave_publica: str
    fecha: datetime


class Firmador(ABC):
    """Contrato de firma (DIP). En producción podría implementarse con un certificado X.509 o un HSM."""

    @abstractmethod
    def firmar(self, contenido: str) -> FirmaDigital: ...

    @abstractmethod
    def verificar(self, contenido: str, firma_base64: str) -> bool: ...

    @property
    @abstractmethod
    def algoritmo(self) -> str: ...


def sha256_hex(texto: str | bytes) -> str:
    datos = texto.encode("utf-8") if isinstance(texto, str) else texto
    return hashlib.sha256(datos).hexdigest()


class FirmadorRsa(Firmador):
    ALGORITMO = "SHA256withRSA"

    def __init__(self, clave_privada: rsa.RSAPrivateKey | None = None) -> None:
        self._privada = clave_privada or rsa.generate_private_key(public_exponent=65537, key_size=2048)
        publica_der = self._privada.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        self._huella = sha256_hex(publica_der)[:16].upper()

    @classmethod
    def desde_archivo(cls, ruta: Path) -> "FirmadorRsa":
        """Carga la clave PEM; si no existe, la genera y la guarda con permisos restringidos."""
        ruta = Path(ruta)
        if ruta.exists():
            clave = serialization.load_pem_private_key(ruta.read_bytes(), password=None)
            if not isinstance(clave, rsa.RSAPrivateKey):
                raise ValueError("La clave de firma debe ser RSA")
            return cls(clave)
        firmador = cls()
        ruta.parent.mkdir(parents=True, exist_ok=True)
        ruta.write_bytes(firmador._privada.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        try:
            ruta.chmod(0o600)
        except OSError:  # pragma: no cover - Windows
            pass
        return firmador

    @property
    def algoritmo(self) -> str:
        return self.ALGORITMO

    @property
    def huella_clave_publica(self) -> str:
        return self._huella

    def firmar(self, contenido: str) -> FirmaDigital:
        if contenido is None:
            raise ValueError("No se puede firmar un contenido nulo")
        firma = self._privada.sign(contenido.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
        return FirmaDigital(sha256_hex(contenido), base64.b64encode(firma).decode("ascii"),
                            self.ALGORITMO, self._huella, datetime.now())

    def verificar(self, contenido: str, firma_base64: str) -> bool:
        if contenido is None or not firma_base64:
            return False
        try:
            firma = base64.b64decode(firma_base64, validate=True)
            self._privada.public_key().verify(firma, contenido.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
            return True
        except (InvalidSignature, binascii.Error, ValueError):
            return False
