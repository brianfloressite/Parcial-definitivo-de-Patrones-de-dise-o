"""Patrón Composite – estructura jerárquica del reporte (requisito complementario 5).

``ComponenteReporte`` es la interfaz común. Las hojas (párrafo, tabla, gráfico, indicadores) y el
compuesto (``SeccionReporte``) se tratan igual: el cliente llama a ``renderizar_html(nivel)`` sin saber si
el objeto contiene otros. Las secciones admiten anidamiento ilimitado (secciones → subsecciones → …).
Agregar un nuevo tipo de componente no exige modificar los existentes (OCP).
"""
from __future__ import annotations

import html
from abc import ABC, abstractmethod
from decimal import ROUND_HALF_UP, Decimal
from typing import Iterable, Mapping


def escapar(texto: object) -> str:
    """Escape HTML: evita inyección de marcado con datos ingresados por usuarios (OWASP A03)."""
    return html.escape("" if texto is None else str(texto), quote=True).replace("&#x27;", "&#39;")


def sangria(nivel: int) -> str:
    return "  " * max(0, nivel)


_NUM = ' class="num"'


def _num(valor: Decimal) -> str:
    return f"{valor:,.2f}"


class ComponenteReporte(ABC):
    """Componente: interfaz uniforme para hojas y compuestos."""

    @property
    @abstractmethod
    def titulo(self) -> str: ...

    @abstractmethod
    def renderizar_html(self, nivel: int = 0) -> str: ...

    @abstractmethod
    def renderizar_texto(self, nivel: int = 0) -> str: ...

    def contar_elementos(self) -> int:
        """Número total de componentes del subárbol (incluido este)."""
        return 1

    def profundidad(self) -> int:
        """Profundidad máxima del subárbol (una hoja tiene profundidad 1)."""
        return 1


# --------------------------------------------------------------------------- hojas
class ParrafoReporte(ComponenteReporte):
    def __init__(self, texto: str, destacado: bool = False) -> None:
        if not texto or not str(texto).strip():
            raise ValueError("El párrafo no puede estar vacío")
        self._texto = str(texto).strip()
        self._destacado = destacado

    @property
    def titulo(self) -> str:
        return self._texto if len(self._texto) <= 40 else self._texto[:40] + "…"

    def renderizar_html(self, nivel: int = 0) -> str:
        clase = "rep-parrafo rep-destacado" if self._destacado else "rep-parrafo"
        return f'<p class="{clase}">{escapar(self._texto)}</p>'

    def renderizar_texto(self, nivel: int = 0) -> str:
        return f"{sangria(nivel)}{self._texto}\n"


class TablaReporte(ComponenteReporte):
    """Tabla con encabezados, filas y fila de totales opcional."""

    def __init__(self, titulo: str, encabezados: Iterable[str]) -> None:
        if not titulo or not str(titulo).strip():
            raise ValueError("La tabla debe tener un título")
        encabezados = tuple(encabezados or ())
        if not encabezados:
            raise ValueError("La tabla debe tener al menos un encabezado")
        self._titulo = str(titulo).strip()
        self._encabezados = encabezados
        self._filas: list[tuple[str, ...]] = []
        self._total: tuple[str, ...] | None = None

    def fila(self, *celdas: str) -> "TablaReporte":
        self._validar_ancho(len(celdas))
        self._filas.append(tuple(str(c) for c in celdas))
        return self

    def total(self, *celdas: str) -> "TablaReporte":
        self._validar_ancho(len(celdas))
        self._total = tuple(str(c) for c in celdas)
        return self

    def _validar_ancho(self, n: int) -> None:
        if n != len(self._encabezados):
            raise ValueError(f"La fila tiene {n} celdas y la tabla {len(self._encabezados)} columnas")

    @property
    def titulo(self) -> str:
        return self._titulo

    @property
    def encabezados(self) -> tuple[str, ...]:
        return self._encabezados

    @property
    def filas(self) -> tuple[tuple[str, ...], ...]:
        return tuple(self._filas)

    @staticmethod
    def _fila_html(celdas: Iterable[str], tag: str) -> str:
        partes = [f"<{tag}{_NUM if i else ''}>{escapar(c)}</{tag}>" for i, c in enumerate(celdas)]
        return "<tr>" + "".join(partes) + "</tr>"

    def renderizar_html(self, nivel: int = 0) -> str:
        cab = "".join(f"<th{_NUM if i else ''}>{escapar(e)}</th>" for i, e in enumerate(self._encabezados))
        cuerpo = "".join(self._fila_html(f, "td") for f in self._filas) or (
            f'<tr><td colspan="{len(self._encabezados)}" class="rep-vacio">Sin registros</td></tr>')
        pie = f"<tfoot>{self._fila_html(self._total, 'th')}</tfoot>" if self._total else ""
        return (f'<figure class="rep-tabla"><figcaption>{escapar(self._titulo)}</figcaption><table>'
                f"<thead><tr>{cab}</tr></thead><tbody>{cuerpo}</tbody>{pie}</table></figure>")

    def renderizar_texto(self, nivel: int = 0) -> str:
        todas = [self._encabezados, *self._filas] + ([self._total] if self._total else [])
        anchos = [max(len(f[i]) for f in todas) for i in range(len(self._encabezados))]
        pad = sangria(nivel)
        lineas = [f"{pad}[Tabla] {self._titulo}"]
        for f in todas:
            celdas = [c.ljust(anchos[i]) if i == 0 else c.rjust(anchos[i]) for i, c in enumerate(f)]
            lineas.append(pad + " | ".join(celdas) + " |")
        return "\n".join(lineas) + "\n"


class GraficoBarrasReporte(ComponenteReporte):
    """Gráfico comparativo de barras horizontales en SVG (sin librerías: se imprime y exporta a PDF)."""

    ANCHO, ALTO_BARRA, MARGEN_ETIQUETA = 640, 26, 170

    def __init__(self, titulo: str, unidad: str, datos: Mapping[str, Decimal]) -> None:
        if not titulo or not str(titulo).strip():
            raise ValueError("El gráfico debe tener un título")
        self._titulo = str(titulo).strip()
        self._unidad = unidad or ""
        self._datos = {str(k): Decimal(v) for k, v in (datos or {}).items()}
        if any(v < 0 for v in self._datos.values()):
            raise ValueError("Los valores del gráfico deben ser cero o positivos")

    @property
    def titulo(self) -> str:
        return self._titulo

    @property
    def datos(self) -> dict[str, Decimal]:
        return dict(self._datos)

    def _formato(self, v: Decimal) -> str:
        return f"{self._unidad} {_num(v)}" if self._unidad else _num(v)

    def _maximo(self) -> Decimal:
        maximo = max(self._datos.values(), default=Decimal(1))
        return maximo if maximo > 0 else Decimal(1)

    def renderizar_html(self, nivel: int = 0) -> str:
        t = escapar(self._titulo)
        if not self._datos:
            return f'<figure class="rep-grafico"><figcaption>{t}</figcaption><p class="rep-vacio">Sin datos para graficar.</p></figure>'
        maximo = self._maximo()
        alto = len(self._datos) * (self.ALTO_BARRA + 10) + 10
        ancho_barras = self.ANCHO - self.MARGEN_ETIQUETA - 110
        partes = [f'<figure class="rep-grafico"><figcaption>{t}</figcaption>'
                  f'<svg viewBox="0 0 {self.ANCHO} {alto}" role="img" aria-label="{t}">']
        y = 10
        for i, (etiqueta, valor) in enumerate(self._datos.items()):
            w = max(int((valor * ancho_barras / maximo).quantize(Decimal(1), rounding=ROUND_HALF_UP)), 2)
            m = self.MARGEN_ETIQUETA
            partes.append(
                f'<text x="{m - 8}" y="{y + 17}" text-anchor="end" class="rep-eje">{escapar(etiqueta)}</text>'
                f'<rect x="{m}" y="{y}" width="{w}" height="{self.ALTO_BARRA}" rx="4" class="rep-barra rep-barra-{i % 4}"/>'
                f'<text x="{m + w + 6}" y="{y + 17}" class="rep-valor">{escapar(self._formato(valor))}</text>')
            y += self.ALTO_BARRA + 10
        return "".join(partes) + "</svg></figure>"

    def renderizar_texto(self, nivel: int = 0) -> str:
        maximo = self._maximo()
        lineas = [f"{sangria(nivel)}[Gráfico] {self._titulo}"]
        for etiqueta, valor in self._datos.items():
            n = max(int((valor * 30 / maximo).quantize(Decimal(1), rounding=ROUND_HALF_UP)), 1)
            lineas.append(f"{sangria(nivel)}{etiqueta:<22} {'█' * n} {self._formato(valor)}")
        return "\n".join(lineas) + "\n"


class IndicadoresReporte(ComponenteReporte):
    """Tarjetas de indicadores clave (KPI) del resumen ejecutivo."""

    def __init__(self, titulo: str = "Indicadores clave") -> None:
        self._titulo = (titulo or "Indicadores clave").strip()
        self._indicadores: list[tuple[str, str, str]] = []

    def agregar(self, nombre: str, valor: str, detalle: str = "") -> "IndicadoresReporte":
        if not nombre or not nombre.strip() or valor is None:
            raise ValueError("Todo indicador requiere nombre y valor")
        self._indicadores.append((nombre, str(valor), detalle or ""))
        return self

    @property
    def titulo(self) -> str:
        return self._titulo

    @property
    def indicadores(self) -> tuple[tuple[str, str, str], ...]:
        return tuple(self._indicadores)

    def renderizar_html(self, nivel: int = 0) -> str:
        tarjetas = "".join(
            f'<div class="rep-kpi"><span class="rep-kpi-nombre">{escapar(n)}</span>'
            f'<strong class="rep-kpi-valor">{escapar(v)}</strong><span class="rep-kpi-detalle">{escapar(d)}</span></div>'
            for n, v, d in self._indicadores)
        return f'<div class="rep-kpis" aria-label="{escapar(self._titulo)}">{tarjetas}</div>'

    def renderizar_texto(self, nivel: int = 0) -> str:
        return "".join(f"{sangria(nivel)}• {n}: {v}{f' ({d})' if d else ''}\n" for n, v, d in self._indicadores)


# --------------------------------------------------------------------------- compuesto
class SeccionReporte(ComponenteReporte):
    """Compuesto: contiene cualquier ComponenteReporte (incluidas otras secciones) y delega en sus hijos."""

    def __init__(self, titulo: str) -> None:
        if not titulo or not str(titulo).strip():
            raise ValueError("Toda sección debe tener un título")
        self._titulo = str(titulo).strip()
        self._hijos: list[ComponenteReporte] = []

    @classmethod
    def de(cls, titulo: str) -> "SeccionReporte":
        return cls(titulo)

    def agregar(self, componente: ComponenteReporte) -> "SeccionReporte":
        """Agrega una hoja o subsección. API fluida para encadenar llamadas."""
        if not isinstance(componente, ComponenteReporte):
            raise ValueError("El componente no puede ser nulo")
        if componente is self or (isinstance(componente, SeccionReporte) and componente.contiene(self)):
            raise ValueError("Una sección no puede contenerse a sí misma (ciclo)")
        self._hijos.append(componente)
        return self

    def remover(self, componente: ComponenteReporte) -> bool:
        for i, hijo in enumerate(self._hijos):
            if hijo is componente:
                del self._hijos[i]
                return True
        return False

    def contiene(self, buscado: ComponenteReporte) -> bool:
        return any(h is buscado or (isinstance(h, SeccionReporte) and h.contiene(buscado)) for h in self._hijos)

    @property
    def hijos(self) -> tuple[ComponenteReporte, ...]:
        """Vista de solo lectura: el estado interno no se modifica desde fuera."""
        return tuple(self._hijos)

    @property
    def esta_vacia(self) -> bool:
        return not self._hijos

    @property
    def titulo(self) -> str:
        return self._titulo

    def renderizar_html(self, nivel: int = 0) -> str:
        h = min(2 + nivel, 6)
        vacio = '<p class="rep-vacio">Sin información para el período seleccionado.</p>' if not self._hijos else ""
        hijos = "".join(hijo.renderizar_html(nivel + 1) for hijo in self._hijos)
        return (f'<section class="rep-seccion rep-nivel-{nivel}"><h{h} class="rep-titulo">{escapar(self._titulo)}</h{h}>'
                f"{vacio}{hijos}</section>")

    def renderizar_texto(self, nivel: int = 0) -> str:
        marca = "■ " if nivel == 0 else "▸ "
        texto = f"{sangria(nivel)}{marca}{self._titulo.upper()}\n"
        if not self._hijos:
            texto += f"{sangria(nivel + 1)}(sin información)\n"
        return texto + "".join(h.renderizar_texto(nivel + 1) for h in self._hijos)

    def contar_elementos(self) -> int:
        return 1 + sum(h.contar_elementos() for h in self._hijos)

    def profundidad(self) -> int:
        return 1 + max((h.profundidad() for h in self._hijos), default=0)
