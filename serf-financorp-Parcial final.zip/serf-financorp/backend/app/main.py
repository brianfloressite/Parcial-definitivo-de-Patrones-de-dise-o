"""Punto de entrada de la API REST de SERF (FastAPI).

Ejecutar en desarrollo::

    cd backend
    uvicorn app.main:app --reload --port 8000

Documentación interactiva: http://localhost:8000/docs
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.contenedor import crear_esquema, inicializar_infraestructura, preparar_datos
from .api.errores import registrar_manejadores
from .api.rutas.catalogo import filiales, productos, ventas
from .api.rutas.reportes import reportes
from .api.rutas.sistema import configuracion, dashboard, sistema
from .config.ajustes import Ajustes, obtener_ajustes
from .persistencia.pool_conexiones import PoolConexiones

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

VERSION = "2.0.0"


def crear_app(ajustes: Ajustes | None = None, *, inicializar: bool = True) -> FastAPI:
    ajustes = ajustes or obtener_ajustes()

    @asynccontextmanager
    async def ciclo_de_vida(_: FastAPI):
        if inicializar:
            inicializar_infraestructura(ajustes)
            crear_esquema()
            preparar_datos(ajustes.cargar_datos_demo)
        yield
        if inicializar:
            PoolConexiones.instancia().cerrar()

    app = FastAPI(title="SERF · FinanCorp S.A.", version=VERSION, lifespan=ciclo_de_vida,
                  description="API del Sistema Empresarial de Gestión de Reportes Financieros (Python + MySQL).")
    app.add_middleware(CORSMiddleware, allow_origins=list(ajustes.cors_origenes) or ["*"],
                       allow_methods=["GET", "POST", "PUT"], allow_headers=["Content-Type", "Accept"])
    registrar_manejadores(app)
    for router in (filiales, productos, ventas, reportes, configuracion, dashboard, sistema):
        app.include_router(router)

    @app.get("/", include_in_schema=False)
    def raiz():
        return {"aplicacion": "SERF · FinanCorp S.A.", "version": VERSION, "documentacion": "/docs"}

    return app


app = crear_app()
