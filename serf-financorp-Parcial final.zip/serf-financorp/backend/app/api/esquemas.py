"""Contrato JSON de la API (Pydantic). Separa el dominio del formato de transporte.

Los atributos son snake_case en Python y se publican en camelCase para el frontend (alias). Los importes
viajan como números JSON; internamente se manejan con ``Decimal``.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, ConfigDict, PlainSerializer
from pydantic.alias_generators import to_camel

from ..dominio import Filial, Producto, Venta
from ..reporte.facade.resultados import ReporteGenerado, ResultadoVerificacion
from ..reporte.prototype.plantillas import PlantillaReporte

Monto = Annotated[Decimal, PlainSerializer(float, return_type=float, when_used="json")]


class Esquema(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True, str_strip_whitespace=True)


# ------------------------------------------------------------------ entradas
class SolicitudFilialIn(Esquema):
    codigo: str | None = None
    nombre: str | None = None
    pais: str | None = None
    ciudad: str | None = None
    moneda: str | None = None


class SolicitudProductoIn(Esquema):
    codigo: str | None = None
    nombre: str | None = None
    descripcion_tecnica: str | None = None
    categoria: str | None = None
    costo_importacion_cny: Decimal | None = None
    precio_venta_sugerido: Decimal | None = None
    proveedor: str | None = None
    fecha_importacion: str | None = None
    codigo_filial: str | None = None
    stock_inicial: int | None = None


class SolicitudVentaIn(Esquema):
    numero_factura: str | None = None
    fecha: str | None = None
    codigo_producto: str | None = None
    cantidad: int | None = None
    precio_unitario: Decimal | None = None
    cliente: str | None = None
    vendedor: str | None = None
    metodo_pago: str | None = None


class SolicitudReporteIn(Esquema):
    tipo: str | None = None
    anio: int | None = None
    mes: int | None = None
    trimestre: int | None = None
    codigo_filial: str | None = None
    autor: str | None = None
    formato: str | None = "HTML"
    marca_agua: bool = True
    confidencial: bool = True
    firma_digital: bool = True


class ActualizacionTasaIn(Esquema):
    tasa: Decimal | None = None


class ActualizacionTextoIn(Esquema):
    texto: str | None = None


# ------------------------------------------------------------------ salidas
class FilialOut(Esquema):
    codigo: str
    nombre: str
    pais: str
    ciudad: str
    moneda: str
    sede_central: bool

    @classmethod
    def de(cls, f: Filial) -> "FilialOut":
        return cls(codigo=f.codigo, nombre=f.nombre, pais=f.pais, ciudad=f.ciudad,
                   moneda=f.moneda_local.name, sede_central=f.sede_central)


class ProductoOut(Esquema):
    codigo: str
    nombre: str
    descripcion_tecnica: str
    categoria: str
    categoria_etiqueta: str
    costo_importacion: Monto
    moneda_costo: str
    costo_corporativo: Monto
    precio_venta_sugerido: Monto
    moneda_local: str
    proveedor: str
    fecha_importacion: str
    codigo_filial: str
    stock_inicial: int
    stock: int
    stock_bajo: bool

    @classmethod
    def de(cls, p: Producto, costo_corporativo: Decimal) -> "ProductoOut":
        return cls(codigo=p.codigo, nombre=p.nombre, descripcion_tecnica=p.descripcion_tecnica,
                   categoria=p.categoria.name, categoria_etiqueta=p.categoria.etiqueta,
                   costo_importacion=p.costo_importacion.monto, moneda_costo=p.costo_importacion.moneda.name,
                   costo_corporativo=costo_corporativo, precio_venta_sugerido=p.precio_venta_sugerido.monto,
                   moneda_local=p.precio_venta_sugerido.moneda.name, proveedor=p.proveedor,
                   fecha_importacion=p.fecha_importacion.isoformat(), codigo_filial=p.codigo_filial,
                   stock_inicial=p.stock_inicial, stock=p.stock, stock_bajo=p.stock_bajo)


class VentaOut(Esquema):
    numero_factura: str
    fecha: str
    codigo_producto: str
    nombre_producto: str
    categoria: str
    codigo_filial: str
    cantidad: int
    precio_unitario: Monto
    moneda_local: str
    total_local: Monto
    total_corporativo: Monto
    moneda_corporativa: str
    tasa_aplicada: Monto
    margen_corporativo: Monto
    cliente: str
    vendedor: str
    metodo_pago: str

    @classmethod
    def de(cls, v: Venta) -> "VentaOut":
        return cls(numero_factura=v.numero_factura, fecha=v.fecha.isoformat(), codigo_producto=v.codigo_producto,
                   nombre_producto=v.nombre_producto, categoria=v.categoria.etiqueta, codigo_filial=v.codigo_filial,
                   cantidad=v.cantidad, precio_unitario=v.precio_unitario.monto,
                   moneda_local=v.precio_unitario.moneda.name, total_local=v.total_local.monto,
                   total_corporativo=v.total_corporativo.monto, moneda_corporativa=v.total_corporativo.moneda.name,
                   tasa_aplicada=v.tasa_aplicada, margen_corporativo=v.margen_corporativo.monto,
                   cliente=v.cliente, vendedor=v.vendedor, metodo_pago=v.metodo_pago.etiqueta)


class ConfiguracionOut(Esquema):
    empresa: str
    moneda_corporativa: str
    tasas: dict[str, Monto]
    texto_marca_agua: str
    firmante: str
    ultima_actualizacion: str
    identidad_instancia: int


class ConversionOut(Esquema):
    monto_original: Monto
    moneda_original: str
    monto_convertido: Monto
    moneda_destino: str
    tasa: Monto


class PlantillaOut(Esquema):
    tipo: str
    nombre: str
    descripcion: str
    secciones_obligatorias: list[str]
    color_primario: str
    color_acento: str

    @classmethod
    def de(cls, p: PlantillaReporte) -> "PlantillaOut":
        return cls(tipo=p.tipo.name, nombre=p.titulo_base, descripcion=p.descripcion,
                   secciones_obligatorias=list(p.secciones_obligatorias), color_primario=p.estilo.color_primario,
                   color_acento=p.estilo.color_acento)


class ReporteOut(Esquema):
    id: str
    titulo: str
    tipo: str
    periodo: str
    alcance: str
    autor: str
    fecha_generacion: str
    tipo_contenido: str
    contenido: str
    metadatos: dict[str, str]
    capas: list[str]
    firmado: bool

    @classmethod
    def de(cls, r: ReporteGenerado) -> "ReporteOut":
        return cls(id=r.id, titulo=r.titulo, tipo=r.tipo, periodo=r.periodo, alcance=r.alcance, autor=r.autor,
                   fecha_generacion=r.fecha_generacion, tipo_contenido=r.tipo_contenido, contenido=r.contenido,
                   metadatos=dict(r.metadatos), capas=list(r.capas), firmado=r.esta_firmado)


class ReporteResumenOut(Esquema):
    id: str
    titulo: str
    tipo: str
    periodo: str
    alcance: str
    autor: str
    fecha_generacion: str
    capas: list[str]
    firmado: bool

    @classmethod
    def de(cls, r: ReporteGenerado) -> "ReporteResumenOut":
        return cls(id=r.id, titulo=r.titulo, tipo=r.tipo, periodo=r.periodo, alcance=r.alcance, autor=r.autor,
                   fecha_generacion=r.fecha_generacion, capas=list(r.capas), firmado=r.esta_firmado)


class VerificacionOut(Esquema):
    id_reporte: str
    valido: bool
    mensaje: str
    hash_registrado: str | None
    hash_calculado: str | None

    @classmethod
    def de(cls, v: ResultadoVerificacion) -> "VerificacionOut":
        return cls(id_reporte=v.id_reporte, valido=v.valido, mensaje=v.mensaje,
                   hash_registrado=v.hash_registrado, hash_calculado=v.hash_calculado)


class ItemValor(Esquema):
    etiqueta: str
    valor: Monto


class DashboardOut(Esquema):
    moneda_corporativa: str
    filiales: int
    productos: int
    unidades_en_stock: int
    productos_stock_bajo: int
    ventas_anio: int
    ingresos_anio: Monto
    margen_anio: Monto
    ingresos_ultimo_mes: Monto
    etiqueta_ultimo_mes: str
    inventario_valorizado: Monto
    ingresos_por_pais: list[ItemValor]
    ingresos_por_mes: list[ItemValor]
    alertas_stock: list[ProductoOut]
    ultimas_ventas: list[VentaOut]


class ErrorOut(Esquema):
    estado: int
    error: str
    mensaje: str
    fecha: str
