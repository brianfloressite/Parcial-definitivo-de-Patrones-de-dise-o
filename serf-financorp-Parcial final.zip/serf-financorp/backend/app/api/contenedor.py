"""Raíz de composición (Composition Root): el único lugar que conoce las clases concretas y las conecta.

* Objetos de aplicación (uno por proceso): ``ConfiguracionGlobal`` y ``PoolConexiones`` (Singletons),
  ``RegistroPlantillas``, ``DirectorReportes`` y el ``Firmador``.
* Objetos por petición: una ``UnidadDeTrabajo`` (sesión tomada del pool) y los servicios que la usan.

Los servicios reciben sus dependencias por constructor (DIP); ninguno crea sus colaboradores.
"""
from __future__ import annotations

import threading
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator

from ..config.ajustes import Ajustes, obtener_ajustes
from ..config.configuracion_global import ConfiguracionGlobal
from ..persistencia.modelos import Base
from ..persistencia.pool_conexiones import PoolConexiones
from ..persistencia.unidad_trabajo import UnidadDeTrabajoSql
from ..reporte.builder.director import DirectorReportes
from ..reporte.facade.generador import GeneradorReportesFacade
from ..reporte.firma.firmador import Firmador, FirmadorRsa
from ..reporte.prototype.plantillas import RegistroPlantillas
from ..servicio.catalogo import FilialService, ProductoService
from ..servicio.configuracion import ConfiguracionService
from ..servicio.consolidacion import ConsolidacionService
from ..servicio.conversor import ConversorMoneda, ConversorMonedaCorporativo
from ..servicio.ventas import VentaService


class _ComponentesAplicacion:
    """Objetos sin estado por petición que se crean una vez (perezosamente) y se comparten."""

    def __init__(self) -> None:
        self._candado = threading.Lock()
        self._plantillas: RegistroPlantillas | None = None
        self._director: DirectorReportes | None = None
        self._firmador: Firmador | None = None

    def configurar_firmador(self, firmador: Firmador) -> None:
        self._firmador = firmador

    def _inicializar(self) -> None:
        with self._candado:
            config = ConfiguracionGlobal.instancia()
            if self._plantillas is None:
                self._plantillas = RegistroPlantillas(config)
            if self._director is None:
                self._director = DirectorReportes(config)
            if self._firmador is None:
                self._firmador = FirmadorRsa.desde_archivo(obtener_ajustes().ruta_clave_firma)

    @property
    def plantillas(self) -> RegistroPlantillas:
        if self._plantillas is None:
            self._inicializar()
        return self._plantillas

    @property
    def director(self) -> DirectorReportes:
        if self._director is None:
            self._inicializar()
        return self._director

    @property
    def firmador(self) -> Firmador:
        if self._firmador is None:
            self._inicializar()
        return self._firmador


componentes = _ComponentesAplicacion()


@dataclass
class Servicios:
    """Grafo de objetos de una petición (todos comparten la misma unidad de trabajo / transacción)."""
    uow: UnidadDeTrabajoSql
    configuracion: ConfiguracionGlobal
    conversor: ConversorMoneda
    filiales: FilialService
    productos: ProductoService
    ventas: VentaService
    consolidacion: ConsolidacionService
    config_service: ConfiguracionService
    reportes: GeneradorReportesFacade
    plantillas: RegistroPlantillas


def construir_servicios(uow: UnidadDeTrabajoSql) -> Servicios:
    config = ConfiguracionGlobal.instancia()
    conversor = ConversorMonedaCorporativo(config)
    filiales = FilialService(uow)
    productos = ProductoService(uow, filiales, conversor)
    ventas = VentaService(uow, productos, filiales, conversor)
    consolidacion = ConsolidacionService(ventas, productos, filiales, config)
    fachada = GeneradorReportesFacade(config, consolidacion, componentes.plantillas, componentes.director,
                                      componentes.firmador, uow)
    return Servicios(uow, config, conversor, filiales, productos, ventas, consolidacion,
                     ConfiguracionService(uow, config), fachada, componentes.plantillas)


@contextmanager
def servicios_para() -> Iterator[Servicios]:
    """Abre una sesión del pool, arma los servicios y devuelve la conexión al pool al terminar."""
    uow = UnidadDeTrabajoSql(PoolConexiones.instancia().nueva_sesion())
    with uow:
        yield construir_servicios(uow)


def obtener_servicios() -> Iterator[Servicios]:
    """Dependencia de FastAPI: un grafo de servicios por petición HTTP."""
    with servicios_para() as servicios:
        yield servicios


# ---------------------------------------------------------------------- arranque
def inicializar_infraestructura(ajustes: Ajustes | None = None) -> PoolConexiones:
    ajustes = ajustes or obtener_ajustes()
    return PoolConexiones.instancia().inicializar(
        ajustes.database_url, tamano=ajustes.pool_tamano, desborde=ajustes.pool_desborde,
        reciclar_segundos=ajustes.pool_reciclar_segundos, eco=ajustes.eco_sql)


def crear_esquema() -> None:
    """Crea las tablas que falten (equivale a ejecutar database/schema.sql)."""
    Base.metadata.create_all(PoolConexiones.instancia().motor)


def preparar_datos(cargar_demo: bool) -> None:
    """Sincroniza el Singleton con la configuración guardada y, si se pide, carga los datos demo."""
    from ..datos.cargador_demo import CargadorDatosDemo
    with servicios_para() as s:
        s.config_service.cargar_desde_bd()
        if cargar_demo:
            CargadorDatosDemo(s.filiales, s.productos, s.ventas).cargar()
