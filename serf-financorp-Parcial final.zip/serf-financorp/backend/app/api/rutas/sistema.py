"""API de configuración corporativa (Singleton), panel gerencial y estado del sistema (pool de conexiones)."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, Query

from ...config.configuracion_global import ConfiguracionGlobal
from ...dominio import Dinero, Moneda
from ...persistencia.pool_conexiones import PoolConexiones
from ...servicio.periodo import Periodo
from ..contenedor import Servicios, obtener_servicios
from ..esquemas import (ActualizacionTasaIn, ActualizacionTextoIn, ConfiguracionOut, ConversionOut,
                        DashboardOut, ItemValor, VentaOut)
from .catalogo import producto_out

configuracion = APIRouter(prefix="/api/configuracion", tags=["Configuración"])
dashboard = APIRouter(prefix="/api/dashboard", tags=["Panel"])
sistema = APIRouter(prefix="/api/sistema", tags=["Sistema"])


def configuracion_out(c: ConfiguracionGlobal) -> ConfiguracionOut:
    return ConfiguracionOut(
        empresa=c.nombre_empresa, moneda_corporativa=c.moneda_corporativa.name,
        tasas={m.name: t for m, t in c.tasas.items()}, texto_marca_agua=c.texto_marca_agua,
        firmante=c.firmante_autorizado, ultima_actualizacion=c.formatear_fecha_hora(c.ultima_actualizacion_tasas),
        identidad_instancia=id(c))


@configuracion.get("", response_model=ConfiguracionOut)
def obtener_configuracion(s: Servicios = Depends(obtener_servicios)):
    return configuracion_out(s.configuracion)


@configuracion.put("/tasas/{moneda}", response_model=ConfiguracionOut)
def actualizar_tasa(moneda: str, cuerpo: ActualizacionTasaIn, s: Servicios = Depends(obtener_servicios)):
    if cuerpo.tasa is None:
        raise ValueError("La tasa es obligatoria")
    s.config_service.actualizar_tasa(moneda, cuerpo.tasa)
    return configuracion_out(s.configuracion)


@configuracion.put("/marca-agua", response_model=ConfiguracionOut)
def actualizar_marca_agua(cuerpo: ActualizacionTextoIn, s: Servicios = Depends(obtener_servicios)):
    s.config_service.actualizar_marca_agua(cuerpo.texto)
    return configuracion_out(s.configuracion)


@configuracion.get("/convertir", response_model=ConversionOut)
def convertir(monto: Decimal = Query(...), moneda: str = Query(...), s: Servicios = Depends(obtener_servicios)):
    """Vista previa de conversión usada por los formularios de productos y ventas."""
    r = s.conversor.a_corporativa(Dinero(monto, Moneda.desde_texto(moneda)))
    return ConversionOut(monto_original=r.original.monto, moneda_original=r.original.moneda.name,
                         monto_convertido=r.convertido.monto, moneda_destino=r.convertido.moneda.name, tasa=r.tasa)


@dashboard.get("", response_model=DashboardOut)
def panel(anio: int | None = None, s: Servicios = Depends(obtener_servicios)):
    a = anio or date.today().year
    anual = s.consolidacion.consolidar(Periodo.anual(a))
    ventas = s.ventas.listar()
    fechas = [v.fecha for v in ventas if v.fecha.year == a]
    ultima = max(fechas) if fechas else date(a, 1, 1)
    mes = s.consolidacion.consolidar(Periodo.mensual(a, ultima.month))
    todos = s.productos.listar()
    return DashboardOut(
        moneda_corporativa=s.configuracion.moneda_corporativa.name, filiales=len(s.filiales.listar()),
        productos=len(todos), unidades_en_stock=sum(p.stock for p in todos),
        productos_stock_bajo=anual.productos_con_stock_bajo, ventas_anio=anual.numero_ventas,
        ingresos_anio=anual.ingresos.monto, margen_anio=anual.margen_bruto.monto,
        ingresos_ultimo_mes=mes.ingresos.monto, etiqueta_ultimo_mes=mes.periodo.etiqueta,
        inventario_valorizado=anual.inventario_valorizado.monto,
        ingresos_por_pais=[ItemValor(etiqueta=k, valor=v.monto) for k, v in anual.ingresos_por_pais.items()],
        ingresos_por_mes=[ItemValor(etiqueta=k, valor=v.monto) for k, v in anual.ingresos_por_mes.items()],
        alertas_stock=[producto_out(s, p) for p in s.productos.con_stock_bajo()],
        ultimas_ventas=[VentaOut.de(v) for v in ventas[:6]])


@sistema.get("/salud")
def salud():
    """Comprueba la conexión a la base de datos y muestra el estado del pool (Singleton)."""
    pool = PoolConexiones.instancia()
    return {"estado": "ok", "versionBaseDatos": pool.version_servidor(), "pool": pool.estadisticas(),
            "configuracionIdentidad": id(ConfiguracionGlobal.instancia())}
