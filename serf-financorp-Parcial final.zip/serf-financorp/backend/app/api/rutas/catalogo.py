"""API de filiales (CU02), productos (CU01) y ventas (CU03)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, status

from ...servicio.solicitudes import SolicitudRegistroProducto, SolicitudRegistroVenta
from ..contenedor import Servicios, obtener_servicios
from ..esquemas import (FilialOut, ProductoOut, SolicitudFilialIn, SolicitudProductoIn, SolicitudVentaIn,
                        VentaOut)

filiales = APIRouter(prefix="/api/filiales", tags=["Filiales"])
productos = APIRouter(prefix="/api/productos", tags=["Productos"])
ventas = APIRouter(prefix="/api/ventas", tags=["Ventas"])


def producto_out(s: Servicios, p) -> ProductoOut:
    return ProductoOut.de(p, s.productos.costo_unitario_corporativo(p).monto)


@filiales.get("", response_model=list[FilialOut])
def listar_filiales(s: Servicios = Depends(obtener_servicios)):
    return [FilialOut.de(f) for f in s.filiales.listar()]


@filiales.post("", response_model=FilialOut, status_code=status.HTTP_201_CREATED)
def registrar_filial(cuerpo: SolicitudFilialIn, s: Servicios = Depends(obtener_servicios)):
    return FilialOut.de(s.filiales.registrar(cuerpo.codigo, cuerpo.nombre, cuerpo.pais, cuerpo.ciudad, cuerpo.moneda))


@productos.get("", response_model=list[ProductoOut])
def listar_productos(filial: str | None = None, s: Servicios = Depends(obtener_servicios)):
    return [producto_out(s, p) for p in s.productos.listar(filial)]


@productos.get("/{codigo}", response_model=ProductoOut)
def obtener_producto(codigo: str, s: Servicios = Depends(obtener_servicios)):
    return producto_out(s, s.productos.obtener(codigo))


@productos.post("", response_model=ProductoOut, status_code=status.HTTP_201_CREATED)
def registrar_producto(c: SolicitudProductoIn, s: Servicios = Depends(obtener_servicios)):
    producto = s.productos.registrar(SolicitudRegistroProducto(
        c.codigo, c.nombre, c.descripcion_tecnica, c.categoria, c.costo_importacion_cny, c.precio_venta_sugerido,
        c.proveedor, c.fecha_importacion, c.codigo_filial, c.stock_inicial))
    return producto_out(s, producto)


@ventas.get("", response_model=list[VentaOut])
def listar_ventas(filial: str | None = None, s: Servicios = Depends(obtener_servicios)):
    return [VentaOut.de(v) for v in s.ventas.listar(filial)]


@ventas.post("", response_model=VentaOut, status_code=status.HTTP_201_CREATED)
def registrar_venta(c: SolicitudVentaIn, s: Servicios = Depends(obtener_servicios)):
    venta = s.ventas.registrar(SolicitudRegistroVenta(
        c.numero_factura, c.fecha, c.codigo_producto, c.cantidad, c.precio_unitario, c.cliente, c.vendedor,
        c.metodo_pago))
    return VentaOut.de(venta)
