"""API del Módulo de Reportes. Solo conoce la fachada: una llamada genera el reporte completo."""
from __future__ import annotations

from fastapi import APIRouter, Depends, status

from ...reporte.facade.resultados import SolicitudReporte
from ..contenedor import Servicios, obtener_servicios
from ..esquemas import PlantillaOut, ReporteOut, ReporteResumenOut, SolicitudReporteIn, VerificacionOut

reportes = APIRouter(prefix="/api/reportes", tags=["Reportes"])


@reportes.post("", response_model=ReporteOut, status_code=status.HTTP_201_CREATED)
def generar(c: SolicitudReporteIn, s: Servicios = Depends(obtener_servicios)):
    solicitud = SolicitudReporte(c.tipo, c.anio, c.mes, c.trimestre, c.codigo_filial, c.autor, c.formato,
                                 c.marca_agua, c.confidencial, c.firma_digital)
    return ReporteOut.de(s.reportes.generar_reporte(solicitud))


@reportes.get("", response_model=list[ReporteResumenOut])
def historial(s: Servicios = Depends(obtener_servicios)):
    return [ReporteResumenOut.de(r) for r in s.reportes.historial()]


@reportes.get("/plantillas", response_model=list[PlantillaOut])
def plantillas(s: Servicios = Depends(obtener_servicios)):
    return [PlantillaOut.de(p) for p in s.plantillas.prototipos()]


@reportes.get("/{identificador}", response_model=ReporteOut)
def obtener(identificador: str, s: Servicios = Depends(obtener_servicios)):
    return ReporteOut.de(s.reportes.obtener(identificador))


@reportes.get("/{identificador}/verificar", response_model=VerificacionOut)
def verificar(identificador: str, s: Servicios = Depends(obtener_servicios)):
    return VerificacionOut.de(s.reportes.verificar_integridad(identificador))


@reportes.post("/{identificador}/verificar-alterado", response_model=VerificacionOut)
def verificar_alterado(identificador: str, s: Servicios = Depends(obtener_servicios)):
    """Demostración de integridad: verifica una copia con una cifra adulterada (la firma debe fallar)."""
    return VerificacionOut.de(s.reportes.verificar_copia_alterada(identificador))
