"""Traduce las excepciones del dominio a respuestas HTTP con mensajes claros (RN13, RNF04).
Nunca expone trazas internas al usuario."""
from __future__ import annotations

import logging
from datetime import datetime

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError, OperationalError

from ..dominio import OperacionNoValidaError, RecursoNoEncontradoError, ReglaNegocioError

LOG = logging.getLogger("serf.api")


def _respuesta(estado: int, error: str, mensaje: str) -> JSONResponse:
    return JSONResponse(status_code=estado, content={
        "estado": estado, "error": error, "mensaje": mensaje, "fecha": datetime.now().isoformat(timespec="seconds")})


def registrar_manejadores(app: FastAPI) -> None:

    @app.exception_handler(RequestValidationError)
    async def _formato(_: Request, e: RequestValidationError):
        detalle = e.errors()[0] if e.errors() else {}
        campo = ".".join(str(p) for p in detalle.get("loc", ())[1:]) or "cuerpo"
        return _respuesta(400, "Datos inválidos", f"El formato de los datos enviados no es válido ({campo})")

    @app.exception_handler(ValueError)
    async def _invalidos(_: Request, e: ValueError):
        return _respuesta(400, "Datos inválidos", str(e))

    @app.exception_handler(RecursoNoEncontradoError)
    async def _no_encontrado(_: Request, e: RecursoNoEncontradoError):
        return _respuesta(404, "No encontrado", str(e))

    @app.exception_handler(ReglaNegocioError)
    async def _regla(_: Request, e: ReglaNegocioError):
        return _respuesta(409, "Regla de negocio", str(e))

    @app.exception_handler(IntegrityError)
    async def _integridad(_: Request, e: IntegrityError):
        LOG.warning("Violación de integridad en la base de datos: %s", e.orig)
        return _respuesta(409, "Regla de negocio", "La operación viola una restricción de integridad de los datos")

    @app.exception_handler(OperacionNoValidaError)
    async def _estado(_: Request, e: OperacionNoValidaError):
        return _respuesta(422, "Operación no válida", str(e))

    @app.exception_handler(OperationalError)
    async def _bd(_: Request, e: OperationalError):
        LOG.error("Base de datos no disponible: %s", e.orig)
        return _respuesta(503, "Servicio no disponible", "No se pudo conectar con la base de datos. Intente más tarde.")

    @app.exception_handler(Exception)
    async def _inesperado(_: Request, e: Exception):
        LOG.exception("Error no controlado", exc_info=e)
        return _respuesta(500, "Error interno", "Ocurrió un error inesperado. Intente nuevamente o contacte a soporte.")
