"""Datos de demostración de FinanCorp S.A.: 4 filiales, 16 productos importados desde Shenzhen y ~150 ventas
de enero a octubre de 2026. Usa una semilla fija para que los reportes sean reproducibles.

Se ejecuta automáticamente al arrancar la API si la base está vacía (``SERF_CARGAR_DEMO=true``) o a mano::

    python -m app.datos.cargador_demo
"""
from __future__ import annotations

import random
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

from ..dominio import Categoria, MetodoPago
from ..servicio.catalogo import FilialService, ProductoService
from ..servicio.solicitudes import SolicitudRegistroProducto, SolicitudRegistroVenta
from ..servicio.ventas import VentaService

CLIENTES = ("Corporación Andina SAC", "TecnoRetail SL", "Distribuidora Azteca", "Grupo Cafetero SAS",
            "Inversiones Pacífico", "Colegio San Marcos", "Clínica Santa Lucía", "Startup Hub Madrid",
            "Retail Norte SA de CV", "Universidad del Valle", "Minera Los Andes", "Banco Comercial")
VENDEDORES = ("Ana Torres", "Luis Pérez", "Marta Gómez", "Jorge Ruiz", "Lucía Díaz")

FILIALES = (
    ("PE", "FinanCorp Perú", "Perú", "Lima", "PEN", True),
    ("ES", "FinanCorp España", "España", "Madrid", "EUR", False),
    ("MX", "FinanCorp México", "México", "Ciudad de México", "MXN", False),
    ("CO", "FinanCorp Colombia", "Colombia", "Bogotá", "COP", False),
)

# código, nombre, descripción, categoría, costo CNY, precio local, proveedor, filial, stock
PRODUCTOS = (
    ("PE-LAP-001", "Laptop Huawei MateBook D16", 'Intel i7-13700H, 16 GB RAM, 1 TB SSD, 16"', "LAPTOP", "4350", "3899", "Huawei Technologies", "PE", 220),
    ("PE-SMP-002", "Smartphone Xiaomi Redmi Note 13", '6.67" AMOLED, 8 GB RAM, 256 GB', "SMARTPHONE", "980", "999", "Xiaomi Corp.", "PE", 600),
    ("PE-ACC-003", "Audífonos Anker Soundcore Q30", "Bluetooth 5.0, ANC híbrida", "ACCESORIO", "210", "249", "Anker Innovations", "PE", 450),
    ("PE-RED-004", "Router TP-Link Archer AX55", "Wi-Fi 6 AX3000, doble banda", "REDES", "390", "429", "TP-Link Technologies", "PE", 180),
    ("ES-LAP-001", "Laptop Lenovo IdeaPad Slim 5", "Ryzen 7 7730U, 16 GB, 512 GB SSD", "LAPTOP", "3900", "829", "Lenovo Group", "ES", 200),
    ("ES-SMP-002", "Smartphone OPPO Reno 11", '6.7" AMOLED, 12 GB RAM, 256 GB', "SMARTPHONE", "1650", "399", "OPPO Electronics", "ES", 380),
    ("ES-ACC-003", "Smartwatch Amazfit GTR 4", 'AMOLED 1.43", GPS dual', "ACCESORIO", "720", "169", "Zepp Health", "ES", 300),
    ("ES-RED-004", "Switch Huawei S310-24T", "24 puertos Gigabit, gestionable", "REDES", "1480", "319", "Huawei Technologies", "ES", 90),
    ("MX-LAP-001", "Laptop Honor MagicBook 14", "Intel i5-12450H, 16 GB, 512 GB", "LAPTOP", "3300", "14999", "Honor Device Co.", "MX", 160),
    ("MX-SMP-002", "Smartphone Realme 12 Pro", '6.7" OLED, 8 GB RAM, 256 GB', "SMARTPHONE", "1250", "7499", "Realme Mobile", "MX", 420),
    ("MX-ACC-003", "Power bank Baseus 20000 mAh", "Carga rápida 65 W, USB-C PD", "ACCESORIO", "160", "899", "Baseus Technology", "MX", 520),
    ("MX-RED-004", "Access point Ruijie RG-RAP2260", "Wi-Fi 6 AX1800 para techo", "REDES", "620", "3299", "Ruijie Networks", "MX", 130),
    ("CO-LAP-001", "Laptop Huawei MateBook 14", "Intel i5-1340P, 16 GB, 1 TB SSD", "LAPTOP", "4100", "3899000", "Huawei Technologies", "CO", 150),
    ("CO-SMP-002", "Smartphone Xiaomi 14T", '6.67" AMOLED 144 Hz, 12 GB, 256 GB', "SMARTPHONE", "2300", "2199000", "Xiaomi Corp.", "CO", 340),
    ("CO-ACC-003", "Teclado mecánico Redragon K552", "Switches red, retroiluminado RGB", "ACCESORIO", "180", "179000", "Redragon", "CO", 25),
    ("CO-RED-004", "Router Mercusys MR90X", "Wi-Fi 6 AX6000, 8 antenas", "REDES", "540", "599000", "Mercusys", "CO", 8),
)


class CargadorDatosDemo:

    def __init__(self, filiales: FilialService, productos: ProductoService, ventas: VentaService) -> None:
        self._filiales = filiales
        self._productos = productos
        self._ventas = ventas

    def cargar(self) -> bool:
        """Idempotente: si ya hay filiales no hace nada. Devuelve True si cargó datos."""
        if self._filiales.listar():
            return False
        for codigo, nombre, pais, ciudad, moneda, sede in FILIALES:
            self._filiales.registrar(codigo, nombre, pais, ciudad, moneda, sede_central=sede)
        for (codigo, nombre, descripcion, categoria, costo, precio, proveedor, filial, stock) in PRODUCTOS:
            self._productos.registrar(SolicitudRegistroProducto(
                codigo, nombre, descripcion, categoria, Decimal(costo), Decimal(precio), proveedor,
                "2025-12-15", filial, stock))
        self._generar_ventas()
        return True

    def _generar_ventas(self) -> None:
        rnd = random.Random(2026)
        catalogo = self._productos.listar()
        stock = {p.codigo: p.stock for p in catalogo}
        hoy = date.today()
        correlativo = 1
        metodos = list(MetodoPago)
        for mes in range(1, 11):
            for _ in range(13 + rnd.randrange(6)):
                fecha = date(2026, mes, 1 + rnd.randrange(28))
                if fecha > hoy:
                    continue
                p = catalogo[rnd.randrange(len(catalogo))]
                cantidad = 1 + rnd.randrange(6 if p.categoria is Categoria.LAPTOP else 12)
                if stock[p.codigo] - cantidad < 3:                     # conserva un remanente
                    continue
                decimales = Decimal(1).scaleb(-p.precio_venta_sugerido.moneda.decimales)
                variacion = Decimal(str(round(0.95 + rnd.random() * 0.10, 4)))
                precio = (p.precio_venta_sugerido.monto * variacion).quantize(decimales, rounding=ROUND_HALF_UP)
                self._ventas.registrar(SolicitudRegistroVenta(
                    f"F{p.codigo_filial}-{correlativo:06d}", fecha.isoformat(), p.codigo, cantidad, precio,
                    rnd.choice(CLIENTES), rnd.choice(VENDEDORES), rnd.choice(metodos).name))
                stock[p.codigo] -= cantidad
                correlativo += 1


def main() -> None:  # pragma: no cover - utilidad de línea de comandos
    from ..api.contenedor import crear_esquema, inicializar_infraestructura, servicios_para
    inicializar_infraestructura()
    crear_esquema()
    with servicios_para() as s:
        cargado = CargadorDatosDemo(s.filiales, s.productos, s.ventas).cargar()
    print("Datos de demostración cargados." if cargado else "La base ya tenía datos; no se cargó nada.")


if __name__ == "__main__":  # pragma: no cover
    main()
