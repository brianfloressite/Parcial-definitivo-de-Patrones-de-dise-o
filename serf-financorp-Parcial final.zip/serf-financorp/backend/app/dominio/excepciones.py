"""Excepciones del dominio de FinanCorp. La capa API las traduce a códigos HTTP (ver api/manejador_errores.py).

Jerarquía:
    ValueError (estándar) ............ datos inválidos              -> 400
    RecursoNoEncontradoError ......... entidad inexistente          -> 404
    ReglaNegocioError ................ regla RN01–RN15 incumplida   -> 409
        StockInsuficienteError ....... RN05: stock insuficiente     -> 409
    OperacionNoValidaError ........... estado inválido (p. ej. builder ya usado) -> 422
"""


class RecursoNoEncontradoError(LookupError):
    """Se consulta un producto, filial, venta o reporte que no existe."""

    def __init__(self, tipo: str, identificador: str) -> None:
        super().__init__(f"{tipo} no encontrado: {identificador}")
        self.tipo = tipo
        self.identificador = identificador


class ReglaNegocioError(Exception):
    """Una operación viola una regla de negocio de FinanCorp (RN01–RN15)."""


class StockInsuficienteError(ReglaNegocioError):
    """RN05: la cantidad vendida no puede superar el stock disponible."""

    def __init__(self, codigo_producto: str, disponible: int, solicitado: int) -> None:
        super().__init__(
            f"Stock insuficiente para {codigo_producto}: disponible {disponible}, solicitado {solicitado}"
        )
        self.codigo_producto = codigo_producto
        self.disponible = disponible
        self.solicitado = solicitado


class OperacionNoValidaError(RuntimeError):
    """La operación no puede realizarse en el estado actual del objeto."""
