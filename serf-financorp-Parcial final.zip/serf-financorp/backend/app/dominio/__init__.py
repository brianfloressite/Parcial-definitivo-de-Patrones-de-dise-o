"""Modelo de dominio de FinanCorp: entidades, objetos de valor y reglas de negocio (sin dependencias de BD ni web)."""
from .dinero import Dinero, a_decimal
from .enumeraciones import Categoria, MetodoPago, Moneda
from .excepciones import (OperacionNoValidaError, RecursoNoEncontradoError, ReglaNegocioError,
                          StockInsuficienteError)
from .filial import Filial
from .producto import Producto
from .venta import Venta

__all__ = ["Dinero", "a_decimal", "Categoria", "MetodoPago", "Moneda", "Filial", "Producto", "Venta",
           "OperacionNoValidaError", "RecursoNoEncontradoError", "ReglaNegocioError", "StockInsuficienteError"]
