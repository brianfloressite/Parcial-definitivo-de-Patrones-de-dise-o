"""Catálogos cerrados del dominio: monedas, categorías de producto y métodos de pago."""
from __future__ import annotations

from enum import Enum
from typing import TypeVar

E = TypeVar("E", bound=Enum)


def _desde_texto(enum: type[E], texto: str | None, vacio: str, invalido: str) -> E:
    """Convierte un texto del usuario ("pen", " Laptop ") en un miembro del enum con mensajes claros (RN13)."""
    if texto is None or not str(texto).strip():
        raise ValueError(vacio)
    try:
        return enum[str(texto).strip().upper()]
    except KeyError:
        raise ValueError(f"{invalido}: {texto}") from None


class Moneda(Enum):
    """Monedas soportadas. La moneda corporativa la define ConfiguracionGlobal (EUR)."""

    EUR = ("Euro", "€", 2)
    PEN = ("Sol peruano", "S/", 2)
    USD = ("Dólar estadounidense", "US$", 2)
    CNY = ("Yuan renminbi", "¥", 2)
    MXN = ("Peso mexicano", "MX$", 2)
    COP = ("Peso colombiano", "COL$", 0)

    def __init__(self, nombre: str, simbolo: str, decimales: int) -> None:
        self.nombre = nombre
        self.simbolo = simbolo
        self.decimales = decimales

    @classmethod
    def desde_texto(cls, texto: str | None) -> "Moneda":
        return _desde_texto(cls, texto, "La moneda es obligatoria", "Moneda no soportada")


class Categoria(Enum):
    """Categorías de productos tecnológicos importados desde China."""

    LAPTOP = "Laptops"
    SMARTPHONE = "Smartphones"
    ACCESORIO = "Accesorios electrónicos"
    REDES = "Equipos de redes"

    @property
    def etiqueta(self) -> str:
        return self.value

    @classmethod
    def desde_texto(cls, texto: str | None) -> "Categoria":
        return _desde_texto(cls, texto, "La categoría es obligatoria", "Categoría no válida")


class MetodoPago(Enum):
    """Métodos de pago admitidos en las filiales."""

    EFECTIVO = "Efectivo"
    TARJETA = "Tarjeta"
    TRANSFERENCIA = "Transferencia"

    @property
    def etiqueta(self) -> str:
        return self.value

    @classmethod
    def desde_texto(cls, texto: str | None) -> "MetodoPago":
        return _desde_texto(cls, texto, "El método de pago es obligatorio", "Método de pago no válido")
