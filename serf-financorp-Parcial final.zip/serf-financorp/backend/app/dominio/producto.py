"""Producto tecnológico importado desde China y asignado al inventario de una filial."""
from __future__ import annotations

import threading
from datetime import date

from .dinero import Dinero
from .enumeraciones import Categoria
from .excepciones import StockInsuficienteError


def _requerido(valor: str | None, campo: str) -> str:
    if valor is None or not str(valor).strip():
        raise ValueError(f"El campo {campo} del producto es obligatorio")
    return str(valor).strip()


class Producto:
    """Entidad con encapsulamiento defensivo.

    El stock no tiene setter: solo cambia con ``descontar_stock`` y ``reponer_stock``, que validan las
    reglas RN05 y RN06. Un candado por instancia evita carreras dentro del proceso; entre procesos la
    base de datos bloquea la fila (SELECT ... FOR UPDATE) antes de descontar.
    """

    UMBRAL_STOCK_BAJO = 10

    def __init__(self, *, codigo: str, nombre: str, descripcion_tecnica: str | None, categoria: Categoria,
                 costo_importacion: Dinero, precio_venta_sugerido: Dinero, proveedor: str,
                 fecha_importacion: date, codigo_filial: str, stock_inicial: int) -> None:
        if not isinstance(categoria, Categoria):
            raise ValueError("La categoría es obligatoria")
        if not isinstance(costo_importacion, Dinero):
            raise ValueError("El costo de importación es obligatorio")
        if not isinstance(precio_venta_sugerido, Dinero):
            raise ValueError("El precio de venta sugerido es obligatorio")
        if not isinstance(fecha_importacion, date):
            raise ValueError("La fecha de importación es obligatoria")
        if not costo_importacion.es_positivo():
            raise ValueError("El costo de importación debe ser mayor que cero")
        if not precio_venta_sugerido.es_positivo():
            raise ValueError("El precio de venta sugerido debe ser mayor que cero")
        if stock_inicial is None or int(stock_inicial) < 0:
            raise ValueError("El stock inicial no puede ser negativo")
        if fecha_importacion > date.today():
            raise ValueError("La fecha de importación no puede ser futura")

        self._codigo = _requerido(codigo, "código").upper()
        self._nombre = _requerido(nombre, "nombre")
        self._descripcion_tecnica = (descripcion_tecnica or "").strip()
        self._categoria = categoria
        self._costo_importacion = costo_importacion          # moneda de origen (CNY)
        self._precio_venta_sugerido = precio_venta_sugerido  # moneda local de la filial
        self._proveedor = _requerido(proveedor, "proveedor")
        self._fecha_importacion = fecha_importacion
        self._codigo_filial = _requerido(codigo_filial, "filial").upper()
        self._stock_inicial = int(stock_inicial)
        self._stock = int(stock_inicial)
        self._candado = threading.Lock()

    @classmethod
    def reconstituir(cls, *, stock: int, **datos) -> "Producto":
        """Recrea un producto leído de la base de datos con su stock actual."""
        producto = cls(**datos)
        if stock < 0:
            raise ValueError("El stock almacenado no puede ser negativo")
        producto._stock = int(stock)
        return producto

    # -------------------------------------------------------------- inventario
    def descontar_stock(self, cantidad: int) -> None:
        """RN05 + RN06: descuenta unidades solo si hay stock suficiente."""
        if cantidad is None or cantidad <= 0:
            raise ValueError("La cantidad a descontar debe ser mayor que cero")
        with self._candado:
            if cantidad > self._stock:
                raise StockInsuficienteError(self._codigo, self._stock, cantidad)
            self._stock -= cantidad

    def reponer_stock(self, cantidad: int) -> None:
        if cantidad is None or cantidad <= 0:
            raise ValueError("La cantidad a reponer debe ser mayor que cero")
        with self._candado:
            self._stock += cantidad

    def tiene_stock(self, cantidad: int) -> bool:
        return 0 < cantidad <= self._stock

    @property
    def stock_bajo(self) -> bool:
        return self._stock <= self.UMBRAL_STOCK_BAJO

    # ----------------------------------------------------- solo lectura (getters)
    stock = property(lambda self: self._stock)
    codigo = property(lambda self: self._codigo)
    nombre = property(lambda self: self._nombre)
    descripcion_tecnica = property(lambda self: self._descripcion_tecnica)
    categoria = property(lambda self: self._categoria)
    costo_importacion = property(lambda self: self._costo_importacion)
    precio_venta_sugerido = property(lambda self: self._precio_venta_sugerido)
    proveedor = property(lambda self: self._proveedor)
    fecha_importacion = property(lambda self: self._fecha_importacion)
    codigo_filial = property(lambda self: self._codigo_filial)
    stock_inicial = property(lambda self: self._stock_inicial)

    def __eq__(self, otro: object) -> bool:
        return isinstance(otro, Producto) and otro._codigo == self._codigo

    def __hash__(self) -> int:
        return hash(self._codigo)

    def __repr__(self) -> str:
        return f"{self._codigo} - {self._nombre}"
