"""Objeto de valor Dinero: importe exacto (Decimal) en una moneda concreta."""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from functools import total_ordering

from .enumeraciones import Moneda


def a_decimal(valor: object, campo: str = "monto") -> Decimal:
    """Convierte números o textos a Decimal sin pasar por float (evita errores de redondeo)."""
    if valor is None:
        raise ValueError(f"El {campo} es obligatorio")
    if isinstance(valor, Decimal):
        return valor
    try:
        return Decimal(str(valor).strip())
    except (InvalidOperation, ValueError):
        raise ValueError(f"El {campo} debe ser un número válido") from None


@total_ordering
class Dinero:
    """Inmutable. Nunca se mezclan monedas sin convertir ni se opera con float."""

    __slots__ = ("_monto", "_moneda")

    def __init__(self, monto: object, moneda: Moneda) -> None:
        if not isinstance(moneda, Moneda):
            raise ValueError("La moneda es obligatoria")
        escala = Decimal(1).scaleb(-max(2, moneda.decimales))
        object.__setattr__(self, "_moneda", moneda)
        object.__setattr__(self, "_monto", a_decimal(monto).quantize(escala, rounding=ROUND_HALF_UP))

    def __setattr__(self, *_):  # inmutabilidad
        raise AttributeError("Dinero es inmutable")

    @classmethod
    def cero(cls, moneda: Moneda) -> "Dinero":
        return cls(0, moneda)

    @property
    def monto(self) -> Decimal:
        return self._monto

    @property
    def moneda(self) -> Moneda:
        return self._moneda

    def es_positivo(self) -> bool:
        return self._monto > 0

    def es_negativo(self) -> bool:
        return self._monto < 0

    def sumar(self, otro: "Dinero") -> "Dinero":
        self._validar_misma_moneda(otro)
        return Dinero(self._monto + otro._monto, self._moneda)

    def restar(self, otro: "Dinero") -> "Dinero":
        self._validar_misma_moneda(otro)
        return Dinero(self._monto - otro._monto, self._moneda)

    def multiplicar(self, factor: int) -> "Dinero":
        return Dinero(self._monto * Decimal(factor), self._moneda)

    __add__ = sumar
    __sub__ = restar

    def _validar_misma_moneda(self, otro: "Dinero") -> None:
        if not isinstance(otro, Dinero):
            raise ValueError("El importe a operar es obligatorio")
        if otro._moneda is not self._moneda:
            raise ValueError(
                f"No se pueden operar importes en {self._moneda.name} y {otro._moneda.name} sin convertirlos"
            )

    def __eq__(self, otro: object) -> bool:
        return isinstance(otro, Dinero) and otro._moneda is self._moneda and otro._monto == self._monto

    def __lt__(self, otro: "Dinero") -> bool:
        self._validar_misma_moneda(otro)
        return self._monto < otro._monto

    def __hash__(self) -> int:
        return hash((self._monto.normalize(), self._moneda))

    def __repr__(self) -> str:
        return f"{self._moneda.simbolo} {self._monto}"
