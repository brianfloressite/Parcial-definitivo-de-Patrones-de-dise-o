"""Transacción de venta confirmada en una filial."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from .dinero import Dinero
from .enumeraciones import Categoria, MetodoPago


def _requerido(valor: str | None, campo: str) -> str:
    if valor is None or not str(valor).strip():
        raise ValueError(f"El campo {campo} de la venta es obligatorio")
    return str(valor).strip()


@dataclass(frozen=True, slots=True)
class Venta:
    """Inmutable (frozen). Conserva el importe original, la moneda, la tasa aplicada y el equivalente
    en moneda corporativa (regla RN08: trazabilidad de la conversión)."""

    numero_factura: str
    fecha: date
    codigo_producto: str
    nombre_producto: str
    categoria: Categoria
    codigo_filial: str
    cantidad: int
    precio_unitario: Dinero
    cliente: str
    vendedor: str
    metodo_pago: MetodoPago
    total_corporativo: Dinero
    tasa_aplicada: Decimal
    costo_importacion_corporativo: Dinero

    def __post_init__(self) -> None:
        set_ = object.__setattr__
        set_(self, "numero_factura", _requerido(self.numero_factura, "número de factura").upper())
        set_(self, "codigo_producto", _requerido(self.codigo_producto, "producto"))
        set_(self, "nombre_producto", _requerido(self.nombre_producto, "nombre del producto"))
        set_(self, "codigo_filial", _requerido(self.codigo_filial, "filial"))
        set_(self, "cliente", _requerido(self.cliente, "cliente"))
        set_(self, "vendedor", _requerido(self.vendedor, "vendedor"))
        if not isinstance(self.fecha, date):
            raise ValueError("La fecha de venta es obligatoria")
        if not isinstance(self.categoria, Categoria):
            raise ValueError("La categoría es obligatoria")
        if not isinstance(self.metodo_pago, MetodoPago):
            raise ValueError("El método de pago es obligatorio")
        for campo in ("precio_unitario", "total_corporativo", "costo_importacion_corporativo"):
            if not isinstance(getattr(self, campo), Dinero):
                raise ValueError(f"El campo {campo.replace('_', ' ')} de la venta es obligatorio")
        if self.tasa_aplicada is None:
            raise ValueError("La tasa aplicada es obligatoria")
        if self.cantidad is None or self.cantidad <= 0:
            raise ValueError("La cantidad vendida debe ser mayor que cero")
        if not self.precio_unitario.es_positivo():
            raise ValueError("El precio unitario debe ser mayor que cero")
        if self.fecha > date.today():
            raise ValueError("La fecha de venta no puede ser futura")

    @property
    def total_local(self) -> Dinero:
        """Total en moneda local = precio unitario × cantidad."""
        return self.precio_unitario.multiplicar(self.cantidad)

    @property
    def margen_corporativo(self) -> Dinero:
        """Margen bruto en moneda corporativa = ingreso − costo de importación de lo vendido."""
        return self.total_corporativo.restar(self.costo_importacion_corporativo)
