"""Filial de FinanCorp S.A. Cada filial opera en su moneda local y administra su propio inventario."""
from __future__ import annotations

import re

from .enumeraciones import Moneda

_CODIGO_VALIDO = re.compile(r"^[A-Z]{2,3}$")


def _requerido(valor: str | None, campo: str) -> str:
    if valor is None or not str(valor).strip():
        raise ValueError(f"El campo {campo} de la filial es obligatorio")
    return str(valor).strip()


class Filial:
    """Inmutable: una vez registrada, sus datos solo se leen (propiedades sin setter)."""

    __slots__ = ("_codigo", "_nombre", "_pais", "_ciudad", "_moneda_local", "_sede_central")

    def __init__(self, codigo: str, nombre: str, pais: str, ciudad: str,
                 moneda_local: Moneda, sede_central: bool = False) -> None:
        codigo = _requerido(codigo, "código").upper()
        if not _CODIGO_VALIDO.match(codigo):
            raise ValueError("El código de filial debe tener 2 o 3 letras (ej. PE, ES)")
        if not isinstance(moneda_local, Moneda):
            raise ValueError("La moneda local es obligatoria")
        self._codigo = codigo
        self._nombre = _requerido(nombre, "nombre")
        self._pais = _requerido(pais, "país")
        self._ciudad = _requerido(ciudad, "ciudad")
        self._moneda_local = moneda_local
        self._sede_central = bool(sede_central)

    codigo = property(lambda self: self._codigo)
    nombre = property(lambda self: self._nombre)
    pais = property(lambda self: self._pais)
    ciudad = property(lambda self: self._ciudad)
    moneda_local = property(lambda self: self._moneda_local)
    sede_central = property(lambda self: self._sede_central)

    def __eq__(self, otro: object) -> bool:
        return isinstance(otro, Filial) and otro._codigo == self._codigo

    def __hash__(self) -> int:
        return hash(self._codigo)

    def __repr__(self) -> str:
        return f"{self._nombre} ({self._codigo})"
