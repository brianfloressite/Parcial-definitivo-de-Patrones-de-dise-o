"""Patrón Singleton – Configuración centralizada de SERF (requisito complementario 1, regla RN15).

Única fuente de verdad para la moneda corporativa, los tipos de cambio, el formato numérico y los
parámetros de seguridad documental. Todos los módulos (ventas, consolidación, reportes) consultan esta
instancia, así ninguna filial valoriza con tasas distintas.

* Instancia única por proceso (``SingletonMeta``), perezosa y segura para hilos.
* Estado protegido: los atributos son privados, las tasas se exponen como copia de solo lectura y toda
  modificación pasa por métodos que validan.
* Persistencia desacoplada: esta clase no conoce MySQL. ``ConfiguracionService`` carga los valores
  guardados al arrancar y guarda cada cambio (DIP: el Singleton no depende de la infraestructura).
"""
from __future__ import annotations

import threading
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from types import MappingProxyType
from typing import Mapping

from ..dominio.dinero import Dinero, a_decimal
from ..dominio.enumeraciones import Moneda
from .singleton import SingletonMeta, SinDuplicados

TASAS_POR_DEFECTO: dict[Moneda, Decimal] = {
    Moneda.EUR: Decimal("1.000000"),
    Moneda.PEN: Decimal("4.050000"),
    Moneda.USD: Decimal("1.080000"),
    Moneda.CNY: Decimal("7.820000"),
    Moneda.MXN: Decimal("19.850000"),
    Moneda.COP: Decimal("4480.000000"),
}

NOTAS_LEGALES_POR_DEFECTO = {
    "PE": "Información preparada conforme a las NIIF adoptadas en Perú (SMV).",
    "ES": "Información preparada conforme al Plan General de Contabilidad de España.",
    "MX": "Información preparada conforme a las NIF emitidas por el CINIF (México).",
    "CO": "Información preparada conforme a las NIIF adoptadas en Colombia.",
}


class ConfiguracionGlobal(SinDuplicados, metaclass=SingletonMeta):
    FORMATO_FECHA = "%d/%m/%Y"
    FORMATO_FECHA_HORA = "%d/%m/%Y %H:%M"

    def __init__(self) -> None:
        self._candado = threading.RLock()
        self._moneda_corporativa = Moneda.EUR
        self.restablecer_valores_por_defecto()

    def restablecer_valores_por_defecto(self) -> None:
        """Carga los parámetros corporativos por defecto (tasas referenciales: unidades por 1 EUR)."""
        with self._candado:
            self._tasas: dict[Moneda, Decimal] = dict(TASAS_POR_DEFECTO)
            self._notas_legales: dict[str, str] = dict(NOTAS_LEGALES_POR_DEFECTO)
            self._nombre_empresa = "FinanCorp S.A."
            self._texto_marca_agua = "FINANCORP · USO INTERNO"
            self._firmante_autorizado = "Gerencia Corporativa de Finanzas"
            self._ultima_actualizacion_tasas = datetime.now()

    # ------------------------------------------------------------ moneda y tasas
    @property
    def moneda_corporativa(self) -> Moneda:
        return self._moneda_corporativa

    def tasa(self, moneda: Moneda) -> Decimal:
        """Unidades de ``moneda`` equivalentes a 1 unidad de moneda corporativa (EUR)."""
        if not isinstance(moneda, Moneda):
            raise ValueError("La moneda es obligatoria")
        try:
            return self._tasas[moneda]
        except KeyError:
            raise LookupError(f"No existe una tasa de cambio configurada para {moneda.name}") from None

    @property
    def tasas(self) -> Mapping[Moneda, Decimal]:
        """Copia de solo lectura: nunca se expone el diccionario interno."""
        return MappingProxyType(dict(self._tasas))

    def actualizar_tasa(self, moneda: Moneda, unidades_por_euro: object,
                        fecha: datetime | None = None) -> Decimal:
        """Actualiza una tasa con validación; la moneda corporativa siempre vale 1."""
        if not isinstance(moneda, Moneda):
            raise ValueError("La moneda es obligatoria")
        if moneda is self._moneda_corporativa:
            raise ValueError("La tasa de la moneda corporativa es fija (1.00)")
        valor = a_decimal(unidades_por_euro, "valor de la tasa")
        if valor <= 0:
            raise ValueError("La tasa de cambio debe ser mayor que cero")
        valor = valor.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
        with self._candado:
            self._tasas[moneda] = valor
            self._ultima_actualizacion_tasas = fecha or datetime.now()
        return valor

    @property
    def ultima_actualizacion_tasas(self) -> datetime:
        return self._ultima_actualizacion_tasas

    # ------------------------------------------------------------ notas legales
    def nota_legal(self, codigo_pais: str | None) -> str:
        if not codigo_pais:
            return f"Información consolidada de todas las filiales de {self._nombre_empresa}."
        return self._notas_legales.get(codigo_pais.upper(),
                                       "Información preparada conforme a la normativa contable local.")

    def registrar_nota_legal(self, codigo_pais: str, nota: str) -> None:
        if not codigo_pais or not codigo_pais.strip() or not nota or not nota.strip():
            raise ValueError("País y nota legal son obligatorios")
        with self._candado:
            self._notas_legales[codigo_pais.strip().upper()] = nota.strip()

    # ------------------------------------------------------------ formato único
    def formatear(self, dinero: Dinero) -> str:
        """Formato numérico corporativo único: símbolo + 1,234,567.89 (COP sin decimales)."""
        decimales = dinero.moneda.decimales
        return f"{dinero.moneda.simbolo} {dinero.monto:,.{decimales}f}"

    @staticmethod
    def formatear_numero(valor: Decimal) -> str:
        return f"{valor:,.2f}"

    def formatear_fecha_hora(self, momento: datetime) -> str:
        return momento.strftime(self.FORMATO_FECHA_HORA)

    # ------------------------------------------------------------ documento
    @property
    def nombre_empresa(self) -> str:
        return self._nombre_empresa

    @property
    def texto_marca_agua(self) -> str:
        return self._texto_marca_agua

    @texto_marca_agua.setter
    def texto_marca_agua(self, texto: str) -> None:
        if texto is None or not str(texto).strip() or len(str(texto).strip()) > 60:
            raise ValueError("La marca de agua debe tener entre 1 y 60 caracteres")
        self._texto_marca_agua = str(texto).strip()

    @property
    def firmante_autorizado(self) -> str:
        return self._firmante_autorizado
