"""Parámetros de entorno (12-factor): se leen de variables de entorno o del archivo backend/.env.

No contiene reglas de negocio; solo dice *dónde* está la base de datos, qué orígenes puede atender la API,
dónde se guarda la clave de firma, etc. Ver ``.env.example``.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

try:  # python-dotenv es opcional: en Docker las variables llegan por el entorno
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

RAIZ_BACKEND = Path(__file__).resolve().parents[2]


def _bool(valor: str | None, defecto: bool) -> bool:
    if valor is None:
        return defecto
    return valor.strip().lower() in {"1", "true", "si", "sí", "yes", "on"}


@dataclass(frozen=True)
class Ajustes:
    database_url: str
    pool_tamano: int = 5
    pool_desborde: int = 10
    pool_reciclar_segundos: int = 1800
    cors_origenes: tuple[str, ...] = field(default_factory=tuple)
    ruta_clave_firma: Path = RAIZ_BACKEND / "claves" / "serf_firma_privada.pem"
    cargar_datos_demo: bool = True
    eco_sql: bool = False

    @staticmethod
    def desde_entorno() -> "Ajustes":
        if load_dotenv is not None:
            load_dotenv(RAIZ_BACKEND / ".env")
        usuario = os.getenv("MYSQL_USER", "serf")
        clave = os.getenv("MYSQL_PASSWORD", "serf")
        servidor = os.getenv("MYSQL_HOST", "localhost")
        puerto = os.getenv("MYSQL_PORT", "3306")
        base = os.getenv("MYSQL_DATABASE", "serf")
        url = os.getenv("SERF_DATABASE_URL") or (
            f"mysql+pymysql://{usuario}:{clave}@{servidor}:{puerto}/{base}?charset=utf8mb4")
        origenes = os.getenv("SERF_CORS_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8080")
        return Ajustes(
            database_url=url,
            pool_tamano=int(os.getenv("SERF_POOL_SIZE", "5")),
            pool_desborde=int(os.getenv("SERF_POOL_MAX_OVERFLOW", "10")),
            pool_reciclar_segundos=int(os.getenv("SERF_POOL_RECYCLE", "1800")),
            cors_origenes=tuple(o.strip() for o in origenes.split(",") if o.strip()),
            ruta_clave_firma=Path(os.getenv("SERF_CLAVE_FIRMA", str(RAIZ_BACKEND / "claves" / "serf_firma_privada.pem"))),
            cargar_datos_demo=_bool(os.getenv("SERF_CARGAR_DEMO"), True),
            eco_sql=_bool(os.getenv("SERF_ECHO_SQL"), False),
        )


@lru_cache(maxsize=1)
def obtener_ajustes() -> Ajustes:
    return Ajustes.desde_entorno()
