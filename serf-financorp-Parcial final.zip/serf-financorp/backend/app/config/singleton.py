"""Patrón Singleton – metaclase reutilizable y segura para hilos.

Cualquier clase que use ``metaclass=SingletonMeta`` tiene una única instancia por proceso:

* **Punto de acceso global y controlado**: ``Clase.instancia()`` (o ``Clase()``, que devuelve la misma).
* **Inicialización perezosa con doble verificación** (*double-checked locking*): el candado solo se
  toma la primera vez, así que las llamadas posteriores no se bloquean.
* **No se puede duplicar**: copiar (``copy``/``deepcopy``) devuelve la misma instancia y serializar con
  ``pickle`` está prohibido, de modo que no aparecen "gemelos" por la puerta de atrás.

La usan ``ConfiguracionGlobal`` (configuración corporativa) y ``PoolConexiones`` (pool de conexiones a
MySQL), los dos recursos que la rúbrica exige únicos en toda la aplicación.
"""
from __future__ import annotations

import threading
from typing import Any, ClassVar


class SingletonMeta(type):
    _instancias: ClassVar[dict[type, Any]] = {}
    _candado: ClassVar[threading.Lock] = threading.Lock()

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        instancia = SingletonMeta._instancias.get(cls)
        if instancia is None:                                   # 1.ª verificación (sin candado)
            with SingletonMeta._candado:
                instancia = SingletonMeta._instancias.get(cls)  # 2.ª verificación (con candado)
                if instancia is None:
                    instancia = super().__call__(*args, **kwargs)
                    SingletonMeta._instancias[cls] = instancia
        return instancia

    def instancia(cls) -> Any:
        """Punto de acceso global a la única instancia."""
        return cls()

    def existe_instancia(cls) -> bool:
        return cls in SingletonMeta._instancias


class SinDuplicados:
    """Mixin que impide clonar o serializar un Singleton."""

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self

    def __reduce__(self):
        raise TypeError(f"{type(self).__name__} es un Singleton y no puede serializarse")
