"""Patrón Builder: construcción paso a paso separada de la representación."""
from datetime import date

import pytest

from app.config.configuracion_global import ConfiguracionGlobal
from app.dominio import Dinero, Moneda, OperacionNoValidaError
from app.reporte.builder.director import DirectorReportes
from app.reporte.builder.reporte import RenderizadorHtml, RenderizadorTexto, ReporteFinancieroBuilder
from app.reporte.composite.componentes import ParrafoReporte, SeccionReporte
from app.reporte.prototype.plantillas import RegistroPlantillas
from app.reporte.tipo_reporte import TipoReporte
from app.servicio.consolidacion import DatosConsolidados
from app.servicio.periodo import Periodo

CONFIG = ConfiguracionGlobal.instancia()


def plantilla(tipo=TipoReporte.MENSUAL_INGRESOS):
    return RegistroPlantillas(CONFIG).obtener_para_pais(tipo, None)


def secciones_mensuales():
    return [SeccionReporte(t).agregar(ParrafoReporte("contenido")) for t in plantilla().secciones_obligatorias]


def test_api_fluida_y_producto_completo():
    b = ReporteFinancieroBuilder(plantilla(), CONFIG)
    assert b.periodo("Octubre 2026") is b                       # cada paso devuelve el builder
    for s in secciones_mensuales():
        b.seccion(s)
    reporte = b.autor("Contabilidad").construir()
    assert reporte.titulo == "Reporte Mensual de Ingresos"
    assert reporte.moneda_corporativa == "EUR" and reporte.periodo == "Octubre 2026"
    assert len(reporte.secciones) == 4


@pytest.mark.parametrize("paso_faltante,mensaje", [("periodo", "período"), ("autor", "autor")])
def test_valida_pasos_obligatorios(paso_faltante, mensaje):
    b = ReporteFinancieroBuilder(plantilla(), CONFIG)
    if paso_faltante != "periodo":
        b.periodo("Octubre 2026")
    if paso_faltante != "autor":
        b.autor("Contabilidad")
    for s in secciones_mensuales():
        b.seccion(s)
    with pytest.raises(OperacionNoValidaError, match=mensaje):
        b.construir()


def test_exige_las_secciones_de_la_plantilla():
    b = ReporteFinancieroBuilder(plantilla(), CONFIG).periodo("Octubre 2026").autor("Contabilidad")
    b.seccion(SeccionReporte("Resumen ejecutivo"))
    with pytest.raises(OperacionNoValidaError, match="Faltan secciones obligatorias"):
        b.construir()


def test_un_builder_construye_una_sola_vez():
    b = ReporteFinancieroBuilder(plantilla(), CONFIG).periodo("Octubre 2026").autor("Contabilidad")
    for s in secciones_mensuales():
        b.seccion(s)
    b.construir()
    with pytest.raises(OperacionNoValidaError):
        b.seccion(SeccionReporte("Otra"))


def test_misma_construccion_distintas_representaciones():
    b = ReporteFinancieroBuilder(plantilla(), CONFIG).periodo("Octubre 2026").autor("Contabilidad")
    for s in secciones_mensuales():
        b.seccion(s)
    reporte = b.construir()
    html, texto = reporte.renderizar(RenderizadorHtml()), reporte.renderizar(RenderizadorTexto())
    assert html.startswith("<article") and "--rep-primario:#0B3D91" in html
    assert "REPORTE MENSUAL DE INGRESOS" in texto and "<" not in texto


def test_el_producto_protege_su_estilo():
    b = ReporteFinancieroBuilder(plantilla(), CONFIG).periodo("Octubre 2026").autor("Contabilidad")
    for s in secciones_mensuales():
        b.seccion(s)
    reporte = b.construir()
    reporte.estilo.color_primario = "#FFFFFF"
    assert reporte.estilo.color_primario == "#0B3D91"


@pytest.mark.parametrize("tipo", list(TipoReporte))
def test_el_director_tiene_una_receta_por_tipo(tipo):
    eur = Dinero("1000", Moneda.EUR)
    datos = DatosConsolidados(periodo=Periodo.anual(2026), alcance="Consolidado corporativo", codigo_filial=None,
                              numero_ventas=1, unidades_vendidas=2, ingresos=eur, costo_importacion=Dinero(400, Moneda.EUR),
                              margen_bruto=Dinero(600, Moneda.EUR), ingresos_por_pais={"Perú": eur},
                              costo_por_pais={"Perú": Dinero(400, Moneda.EUR)},
                              ingresos_por_pais_y_categoria={"Perú": {"Laptops": eur}},
                              ingresos_por_categoria={"Laptops": eur}, ingresos_por_mes={"Ene 2026": eur},
                              inventario_valorizado=Dinero(5000, Moneda.EUR))
    reporte = DirectorReportes(CONFIG).construir(tipo, ReporteFinancieroBuilder(plantilla(tipo), CONFIG), datos, "QA")
    titulos = [s.titulo for s in reporte.secciones]
    assert titulos == list(plantilla(tipo).secciones_obligatorias)
    assert reporte.total_componentes() > len(titulos)          # contiene subsecciones/hojas
    assert date.today().year >= 2026
