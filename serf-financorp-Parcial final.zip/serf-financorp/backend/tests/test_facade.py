"""Patrón Facade: una sola llamada integra los seis patrones y guarda el reporte en la base de datos."""
import pytest

from app.api.contenedor import construir_servicios
from app.dominio import RecursoNoEncontradoError
from app.persistencia.unidad_trabajo import UnidadDeTrabajoSql
from app.reporte.facade.resultados import SolicitudReporte


def test_flujo_del_caso_reporte_mensual_consolidado(demo):
    r = demo.reportes.generar_reporte_mensual_consolidado(2026, 10, "Área Contable")
    assert r.titulo == "Reporte Mensual de Ingresos" and r.periodo == "Octubre 2026"
    assert r.alcance == "Consolidado corporativo"
    assert r.capas == ("Documento base", "Clasificación confidencial", "Marca de agua", "Firma digital")
    for seccion in ("Resumen ejecutivo", "Ingresos por país", "Ingresos por categoría de producto", "Conclusiones"):
        assert seccion in r.contenido
    assert "€ " in r.contenido and r.esta_firmado


def test_el_reporte_queda_en_el_historial_de_la_base(demo, pool):
    r = demo.reportes.generar_reporte(SolicitudReporte("ANUAL_CONSOLIDADO", 2026))
    with UnidadDeTrabajoSql(pool.nueva_sesion()) as otra:          # otra conexión del pool
        leido = construir_servicios(otra).reportes.obtener(r.id)
    assert leido.contenido == r.contenido and leido.metadatos == r.metadatos


def test_verifica_integridad_y_detecta_copia_alterada(demo):
    r = demo.reportes.generar_reporte_mensual_consolidado(2026, 10, "QA")
    assert demo.reportes.verificar_integridad(r.id).valido
    alterado = demo.reportes.verificar_copia_alterada(r.id)
    assert not alterado.valido and alterado.hash_calculado != alterado.hash_registrado


def test_reporte_sin_firma_y_en_texto(demo):
    r = demo.reportes.generar_reporte(SolicitudReporte("TRIMESTRAL_GASTOS_INGRESOS", 2026, trimestre=3,
                                                       formato="TEXTO", marca_agua=False, firma_digital=False))
    assert r.tipo_contenido == "text/plain" and r.capas == ("Documento base", "Clasificación confidencial")
    assert not demo.reportes.verificar_integridad(r.id).valido


def test_reporte_por_filial(demo):
    r = demo.reportes.generar_reporte(SolicitudReporte("MENSUAL_INGRESOS", 2026, mes=5, codigo_filial="pe"))
    assert r.alcance == "Filial FinanCorp Perú" and "Perú (SMV)" in r.contenido


@pytest.mark.parametrize("solicitud,mensaje", [
    (SolicitudReporte("MENSUAL_INGRESOS", 2026), "mes"),
    (SolicitudReporte("TRIMESTRAL_GASTOS_INGRESOS", 2026), "trimestre"),
    (SolicitudReporte("SEMANAL", 2026), "no válido"),
    (SolicitudReporte("ANUAL_CONSOLIDADO", 1990), "año"),
])
def test_valida_la_solicitud(demo, solicitud, mensaje):
    with pytest.raises(ValueError, match=mensaje):
        demo.reportes.generar_reporte(solicitud)


def test_reporte_inexistente(servicios):
    with pytest.raises(RecursoNoEncontradoError):
        servicios.reportes.obtener("NOEXISTE")


def test_periodo_sin_ventas_genera_reporte_vacio(demo):
    r = demo.reportes.generar_reporte(SolicitudReporte("MENSUAL_INGRESOS", 2025, mes=1))
    assert "No se registraron ventas" in r.contenido
