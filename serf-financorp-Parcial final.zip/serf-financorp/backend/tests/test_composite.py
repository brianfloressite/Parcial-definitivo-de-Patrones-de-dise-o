"""Patrón Composite: secciones y subsecciones con anidamiento ilimitado, tratadas de forma uniforme."""
from decimal import Decimal

import pytest

from app.reporte.composite.componentes import (ComponenteReporte, GraficoBarrasReporte, IndicadoresReporte,
                                               ParrafoReporte, SeccionReporte, TablaReporte)


def test_hojas_y_compuestos_se_tratan_igual():
    componentes: list[ComponenteReporte] = [
        ParrafoReporte("Texto"), TablaReporte("T", ["A"]).fila("1"),
        GraficoBarrasReporte("G", "EUR", {"Perú": Decimal(10)}), IndicadoresReporte().agregar("KPI", "1"),
        SeccionReporte("S").agregar(ParrafoReporte("hijo")),
    ]
    for c in componentes:
        assert c.renderizar_html(0) and c.renderizar_texto(0) and c.contar_elementos() >= 1


def test_anidamiento_ilimitado():
    raiz = actual = SeccionReporte("Nivel 0")
    for i in range(1, 12):
        hija = SeccionReporte(f"Nivel {i}")
        actual.agregar(hija)
        actual = hija
    actual.agregar(ParrafoReporte("hoja profunda"))
    assert raiz.profundidad() == 13 and raiz.contar_elementos() == 13
    assert "<h6" in raiz.renderizar_html(0)                       # los niveles profundos usan h6


def test_conteo_recursivo():
    pais = SeccionReporte("Perú").agregar(TablaReporte("Categorías", ["Cat", "EUR"]).fila("Laptops", "10"))
    seccion = SeccionReporte("Ingresos por país").agregar(ParrafoReporte("intro")).agregar(pais)
    assert seccion.contar_elementos() == 4


def test_impide_ciclos():
    a, b = SeccionReporte("A"), SeccionReporte("B")
    a.agregar(b)
    with pytest.raises(ValueError, match="ciclo"):
        b.agregar(a)
    with pytest.raises(ValueError, match="ciclo"):
        a.agregar(a)


def test_hijos_de_solo_lectura_y_remover():
    p = ParrafoReporte("x")
    s = SeccionReporte("S").agregar(p)
    assert isinstance(s.hijos, tuple)
    assert s.remover(p) and s.esta_vacia
    assert "Sin información" in s.renderizar_html(0)


def test_escapa_html_de_datos_de_usuario():
    html = ParrafoReporte('<script>alert("x")</script>').renderizar_html()
    assert "<script>" not in html and "&lt;script&gt;" in html


def test_tabla_valida_columnas_y_muestra_totales():
    tabla = TablaReporte("Ventas", ["País", "EUR"]).fila("Perú", "10").total("Total", "10")
    assert "<tfoot>" in tabla.renderizar_html()
    with pytest.raises(ValueError, match="columnas"):
        tabla.fila("solo una")


def test_grafico_rechaza_negativos_y_dibuja_barras():
    with pytest.raises(ValueError):
        GraficoBarrasReporte("G", "EUR", {"x": Decimal(-1)})
    svg = GraficoBarrasReporte("G", "EUR", {"a": Decimal(5), "b": Decimal(10)}).renderizar_html()
    assert svg.count("<rect") == 2
