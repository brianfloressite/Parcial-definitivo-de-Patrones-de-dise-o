"""Patrón Decorator: capas de confidencialidad, marca de agua y firma digital apilables."""
import pytest

from app.config.configuracion_global import ConfiguracionGlobal
from app.reporte.builder.reporte import RenderizadorHtml, RenderizadorTexto, ReporteFinancieroBuilder
from app.reporte.composite.componentes import ParrafoReporte, SeccionReporte
from app.reporte.decorator.documentos import (ConfidencialidadDecorator, DocumentoReporte, DocumentoReporteBase,
                                              FirmaDigitalDecorator, MarcaDeAguaDecorator)
from app.reporte.firma.firmador import FirmadorRsa
from app.reporte.prototype.plantillas import RegistroPlantillas
from app.reporte.tipo_reporte import TipoReporte

CONFIG = ConfiguracionGlobal.instancia()
FIRMADOR = FirmadorRsa()


def reporte():
    p = RegistroPlantillas(CONFIG).obtener_para_pais(TipoReporte.MENSUAL_INGRESOS, None)
    b = ReporteFinancieroBuilder(p, CONFIG).periodo("Octubre 2026").autor("QA")
    for t in p.secciones_obligatorias:
        b.seccion(SeccionReporte(t).agregar(ParrafoReporte("Ingresos € 1,000.00")))
    return b.construir()


def completo(renderizador=None):
    doc = DocumentoReporteBase(reporte(), renderizador or RenderizadorHtml())
    doc = ConfidencialidadDecorator(doc)
    doc = MarcaDeAguaDecorator(doc, "FINANCORP · USO INTERNO")
    return FirmaDigitalDecorator(doc, FIRMADOR, "Gerencia")


def test_las_capas_se_apilan_en_orden():
    assert completo().capas == ("Documento base", "Clasificación confidencial", "Marca de agua", "Firma digital")


def test_cada_capa_agrega_contenido_y_metadatos_sin_tocar_el_original():
    base = DocumentoReporteBase(reporte(), RenderizadorHtml())
    decorado = MarcaDeAguaDecorator(ConfidencialidadDecorator(base), "SOLO GERENCIA")
    assert "dec-marca-agua" not in base.contenido
    assert "dec-marca-agua" in decorado.contenido and "dec-confidencial" in decorado.contenido
    assert decorado.metadatos["marcaAgua"] == "SOLO GERENCIA" and decorado.metadatos["tipo"] == "MENSUAL_INGRESOS"


def test_sustitucion_de_liskov():
    def titulo_de(documento: DocumentoReporte) -> str:
        return documento.titulo
    assert titulo_de(DocumentoReporteBase(reporte(), RenderizadorHtml())) == titulo_de(completo())


def test_el_orden_de_las_capas_es_libre():
    base = DocumentoReporteBase(reporte(), RenderizadorHtml())
    otro_orden = ConfidencialidadDecorator(MarcaDeAguaDecorator(base, "X"))
    assert otro_orden.capas == ("Documento base", "Marca de agua", "Clasificación confidencial")


def test_firma_valida_y_detecta_alteraciones():
    doc = completo()
    firmado = FirmaDigitalDecorator.extraer_contenido_firmado(doc.contenido)
    assert FIRMADOR.verificar(firmado, doc.metadatos["firma.valor"])
    assert not FIRMADOR.verificar(firmado.replace("1,000.00", "9,000.00"), doc.metadatos["firma.valor"])
    assert doc.metadatos["firma.algoritmo"] == "SHA256withRSA"


def test_funciona_con_texto_plano():
    doc = completo(RenderizadorTexto())
    assert doc.tipo_contenido == "text/plain"
    assert "--- FIRMA DIGITAL ---" in doc.contenido and "*** FINANCORP · USO INTERNO ***" in doc.contenido


def test_sin_marcadores_no_hay_contenido_firmado():
    assert FirmaDigitalDecorator.extraer_contenido_firmado("<p>copia sin firma</p>") is None


def test_validaciones():
    with pytest.raises(ValueError):
        MarcaDeAguaDecorator(DocumentoReporteBase(reporte(), RenderizadorHtml()), " ")
    with pytest.raises(ValueError):
        FirmaDigitalDecorator(DocumentoReporteBase(reporte(), RenderizadorHtml()), FIRMADOR, "")


def test_la_clave_persiste_entre_reinicios(ruta_temporal):
    ruta = ruta_temporal / "clave.pem"
    primero = FirmadorRsa.desde_archivo(ruta)
    firma = primero.firmar("contenido")
    segundo = FirmadorRsa.desde_archivo(ruta)                    # "reinicio" del servidor
    assert segundo.huella_clave_publica == primero.huella_clave_publica
    assert segundo.verificar("contenido", firma.firma_base64)
