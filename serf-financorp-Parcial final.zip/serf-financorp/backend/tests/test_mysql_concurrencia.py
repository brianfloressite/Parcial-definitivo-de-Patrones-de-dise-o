"""Integración con MySQL: dos cajas venden las últimas unidades al mismo tiempo.

Gracias a ``SELECT … FOR UPDATE`` dentro de la transacción, MySQL serializa las ventas sobre la misma fila:
una se confirma y la otra recibe "stock insuficiente"; el stock nunca queda negativo.
Requiere ``SERF_TEST_MYSQL_URL`` (en SQLite no hay bloqueo de filas).
"""
import threading
from decimal import Decimal

import pytest

from app.api.contenedor import construir_servicios
from app.dominio import StockInsuficienteError
from app.persistencia.unidad_trabajo import UnidadDeTrabajoSql
from app.servicio.solicitudes import SolicitudRegistroProducto, SolicitudRegistroVenta
from conftest import ES_MYSQL

pytestmark = [pytest.mark.mysql, pytest.mark.skipif(not ES_MYSQL, reason="requiere SERF_TEST_MYSQL_URL (MySQL)")]


def test_ventas_simultaneas_no_dejan_stock_negativo(servicios, pool):
    servicios.filiales.registrar("PE", "FinanCorp Perú", "Perú", "Lima", "PEN", sede_central=True)
    servicios.productos.registrar(SolicitudRegistroProducto(
        "PE-RED-010", "Router", "", "REDES", Decimal(100), Decimal(200), "TP-Link", "2026-01-01", "PE", 5))
    resultados, barrera = [], threading.Barrier(2)

    def vender(factura):
        with UnidadDeTrabajoSql(pool.nueva_sesion()) as uow:
            s = construir_servicios(uow)
            barrera.wait()
            try:
                s.ventas.registrar(SolicitudRegistroVenta(factura, "2026-10-01", "PE-RED-010", 4, Decimal(200),
                                                          "Cliente", "Ana", "EFECTIVO"))
                resultados.append("ok")
            except StockInsuficienteError:
                resultados.append("sin stock")

    hilos = [threading.Thread(target=vender, args=(f"FPE-C{i}",)) for i in (1, 2)]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join()
    assert sorted(resultados) == ["ok", "sin stock"]
    with UnidadDeTrabajoSql(pool.nueva_sesion()) as uow:
        assert uow.productos.buscar_por_codigo("PE-RED-010").stock == 1
