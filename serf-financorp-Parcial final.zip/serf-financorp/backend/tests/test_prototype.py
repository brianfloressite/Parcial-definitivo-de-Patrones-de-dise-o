"""Patrón Prototype: plantillas clonadas en profundidad desde un registro."""
import pytest

from app.config.configuracion_global import ConfiguracionGlobal
from app.reporte.prototype.plantillas import (EstiloReporte, PlantillaReporte, PlantillaReporteMensual,
                                              RegistroPlantillas)
from app.reporte.tipo_reporte import TipoReporte


@pytest.fixture
def registro():
    return RegistroPlantillas(ConfiguracionGlobal.instancia())


def test_el_registro_entrega_clones_nunca_el_original(registro):
    a = registro.obtener(TipoReporte.MENSUAL_INGRESOS)
    b = registro.obtener(TipoReporte.MENSUAL_INGRESOS)
    original = next(p for p in registro.prototipos() if p.tipo is TipoReporte.MENSUAL_INGRESOS)
    assert a is not b and a is not original
    assert isinstance(a, PlantillaReporteMensual)            # conserva la clase concreta


def test_la_clonacion_es_profunda(registro):
    clon = registro.obtener(TipoReporte.ANUAL_CONSOLIDADO)
    original = next(p for p in registro.prototipos() if p.tipo is TipoReporte.ANUAL_CONSOLIDADO)
    clon.estilo.color_primario = "#000000"
    clon.agregar_seccion_obligatoria("Anexo regulatorio")
    clon.registrar_metadato("auditor", "KPMG")
    assert clon.estilo is not original.estilo
    assert original.estilo.color_primario == "#1F2A44"
    assert "Anexo regulatorio" not in original.secciones_obligatorias
    assert "auditor" not in original.metadatos


def test_adaptar_a_pais_no_altera_el_prototipo(registro):
    peru = registro.obtener_para_pais(TipoReporte.MENSUAL_INGRESOS, "pe")
    consolidado = registro.obtener_para_pais(TipoReporte.MENSUAL_INGRESOS, None)
    assert peru.codigo_pais == "PE" and "Perú" in peru.nota_legal
    assert consolidado.metadatos["pais"] == "CORPORATIVO"
    assert all(p.codigo_pais is None for p in registro.prototipos())


def test_se_pueden_registrar_nuevos_prototipos_sin_modificar_el_registro(registro):
    class PlantillaRegulatoria(PlantillaReporte):
        def __init__(self):
            super().__init__(TipoReporte.MENSUAL_INGRESOS, "Reporte SMV", "Formato regulatorio",
                             EstiloReporte("#111111", "#222222", "Arial"), ["Resumen ejecutivo"])

    registro.registrar(PlantillaRegulatoria())
    assert registro.obtener(TipoReporte.MENSUAL_INGRESOS).titulo_base == "Reporte SMV"


def test_las_colecciones_expuestas_son_de_solo_lectura(registro):
    plantilla = registro.obtener(TipoReporte.MENSUAL_INGRESOS)
    assert isinstance(plantilla.secciones_obligatorias, tuple)
    with pytest.raises(TypeError):
        plantilla.metadatos["x"] = "y"


def test_estilo_valida_colores():
    with pytest.raises(ValueError, match="hexadecimal"):
        EstiloReporte("azul", "#FFFFFF", "Inter")
