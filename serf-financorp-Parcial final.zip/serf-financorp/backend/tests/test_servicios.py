"""Servicios con MySQL/SQLite real: registro de productos y ventas, conversión, transacciones y consolidación."""
from decimal import Decimal

import pytest

from app.api.contenedor import construir_servicios
from app.config.configuracion_global import ConfiguracionGlobal
from app.dominio import Moneda, RecursoNoEncontradoError, ReglaNegocioError, StockInsuficienteError
from app.persistencia.unidad_trabajo import UnidadDeTrabajoSql
from app.servicio.periodo import Periodo
from app.servicio.solicitudes import SolicitudRegistroProducto, SolicitudRegistroVenta


@pytest.fixture
def base(servicios):
    servicios.filiales.registrar("PE", "FinanCorp Perú", "Perú", "Lima", "PEN", sede_central=True)
    servicios.filiales.registrar("ES", "FinanCorp España", "España", "Madrid", "EUR")
    servicios.productos.registrar(SolicitudRegistroProducto(
        "PE-SMP-002", "Smartphone modelo X", "Lote Shenzhen", "SMARTPHONE", Decimal("980"), Decimal("999"),
        "Xiaomi Corp.", "2025-12-15", "PE", 600))
    return servicios


def venta(factura="FPE-0001", cantidad=100, precio="999", producto="PE-SMP-002"):
    return SolicitudRegistroVenta(factura, "2026-10-15", producto, cantidad, Decimal(precio), "Cliente", "Ana", "TARJETA")


def stock_en_bd(pool, codigo="PE-SMP-002"):
    with UnidadDeTrabajoSql(pool.nueva_sesion()) as otra:
        return otra.productos.buscar_por_codigo(codigo).stock


def test_registro_de_producto_convierte_costo_cny_a_eur(base):
    p = base.productos.obtener("pe-smp-002")
    assert p.costo_importacion.moneda is Moneda.CNY and p.precio_venta_sugerido.moneda is Moneda.PEN
    assert base.productos.costo_unitario_corporativo(p).monto == Decimal("125.32")      # 980 / 7.82


def test_producto_duplicado_o_filial_inexistente(base):
    with pytest.raises(ReglaNegocioError, match="Ya existe"):
        base.productos.registrar(SolicitudRegistroProducto("PE-SMP-002", "x", "", "LAPTOP", 1, 1, "p", "2025-01-01", "PE", 1))
    with pytest.raises(RecursoNoEncontradoError, match="Filial"):
        base.productos.registrar(SolicitudRegistroProducto("XX-1", "x", "", "LAPTOP", 1, 1, "p", "2025-01-01", "BR", 1))


def test_venta_del_caso_100_unidades_en_peru(base, pool):
    v = base.ventas.registrar(venta())
    assert v.total_local.monto == Decimal("99900.00")
    assert v.total_corporativo.monto == Decimal("24666.67") and v.tasa_aplicada == Decimal("4.050000")
    assert stock_en_bd(pool) == 500                                # actualización automática de stock


def test_stock_insuficiente_no_registra_ni_descuenta(base, pool):
    with pytest.raises(StockInsuficienteError):
        base.ventas.registrar(venta(cantidad=601))
    assert stock_en_bd(pool) == 600 and base.ventas.listar() == []


def test_transaccion_atomica_si_falla_el_guardado(base, pool, monkeypatch):
    """RN14: si falla el INSERT de la venta, el descuento de stock se revierte (ROLLBACK)."""
    def falla(_venta):
        raise RuntimeError("caída de la base de datos")
    monkeypatch.setattr(base.uow.ventas, "guardar", falla)
    with pytest.raises(RuntimeError):
        base.ventas.registrar(venta())
    assert stock_en_bd(pool) == 600


def test_factura_duplicada(base):
    base.ventas.registrar(venta())
    with pytest.raises(ReglaNegocioError, match="ya fue registrada"):
        base.ventas.registrar(venta(cantidad=1))


@pytest.mark.parametrize("cambio,mensaje", [({"cantidad": 0}, "cantidad"), ({"precio": "0"}, "precio"),
                                            ({"producto": "NOEXISTE"}, "Producto")])
def test_validaciones_de_venta(base, cambio, mensaje):
    with pytest.raises((ValueError, RecursoNoEncontradoError), match=mensaje):
        base.ventas.registrar(venta(**cambio))


def test_nueva_filial_sin_cambiar_el_sistema(base):
    base.filiales.registrar("CL", "FinanCorp Chile", "Chile", "Santiago", "USD")
    assert [f.codigo for f in base.filiales.listar()][0] == "PE"     # la sede central va primero
    with pytest.raises(ReglaNegocioError):
        base.filiales.registrar("cl", "Otra", "Chile", "Santiago", "USD")


def test_consolidacion_suma_todas_las_filiales(demo):
    datos = demo.consolidacion.consolidar(Periodo.anual(2026))
    ventas = demo.ventas.listar_entre(Periodo.anual(2026).desde, Periodo.anual(2026).hasta)
    assert datos.numero_ventas == len(ventas) > 100
    assert datos.ingresos.monto == sum(v.total_corporativo.monto for v in ventas)
    assert sum(d.monto for d in datos.ingresos_por_pais.values()) == datos.ingresos.monto
    assert set(datos.ingresos_por_pais) == {"Perú", "España", "México", "Colombia"}


def test_la_configuracion_persiste_en_la_base(servicios, pool):
    servicios.config_service.actualizar_tasa("PEN", "4.12")
    servicios.config_service.actualizar_marca_agua("SOLO DIRECTORIO")
    config = ConfiguracionGlobal.instancia()
    config.restablecer_valores_por_defecto()                       # simula reinicio del servidor
    assert config.tasa(Moneda.PEN) == Decimal("4.05")
    with UnidadDeTrabajoSql(pool.nueva_sesion()) as otra:
        construir_servicios(otra).config_service.cargar_desde_bd()
    assert config.tasa(Moneda.PEN) == Decimal("4.12") and config.texto_marca_agua == "SOLO DIRECTORIO"


def test_tasa_invalida_no_modifica_nada(servicios):
    with pytest.raises(ValueError):
        servicios.config_service.actualizar_tasa("PEN", "-3")
    assert ConfiguracionGlobal.instancia().tasa(Moneda.PEN) == Decimal("4.05")
