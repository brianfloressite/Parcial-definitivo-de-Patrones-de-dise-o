"""Fixtures comunes.

Por defecto las pruebas usan SQLite en memoria (rápidas, sin instalar nada). Para ejecutar **toda la suite
contra MySQL** defina la variable ``SERF_TEST_MYSQL_URL`` con una base vacía de pruebas, por ejemplo::

    SERF_TEST_MYSQL_URL="mysql+pymysql://serf:serf@localhost:3306/serf_test?charset=utf8mb4" pytest
"""
from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="serf-pruebas-"))
os.environ.setdefault("SERF_CLAVE_FIRMA", str(_TMP / "clave_pruebas.pem"))
os.environ.setdefault("SERF_CARGAR_DEMO", "false")
URL_PRUEBAS = os.getenv("SERF_TEST_MYSQL_URL") or "sqlite+pysqlite:///:memory:"
os.environ["SERF_DATABASE_URL"] = URL_PRUEBAS
logging.getLogger("httpx").setLevel(logging.WARNING)

from app.api.contenedor import construir_servicios, preparar_datos  # noqa: E402
from app.config.configuracion_global import ConfiguracionGlobal  # noqa: E402
from app.datos.cargador_demo import CargadorDatosDemo  # noqa: E402
from app.persistencia.modelos import Base  # noqa: E402
from app.persistencia.pool_conexiones import PoolConexiones  # noqa: E402
from app.persistencia.unidad_trabajo import UnidadDeTrabajoSql  # noqa: E402

ES_MYSQL = URL_PRUEBAS.startswith("mysql")


@pytest.fixture(scope="session", autouse=True)
def pool():
    instancia = PoolConexiones.instancia().inicializar(URL_PRUEBAS)
    yield instancia
    instancia.cerrar()


@pytest.fixture(autouse=True)
def bd(pool):
    """Base de datos limpia y configuración por defecto en cada prueba."""
    Base.metadata.drop_all(pool.motor)
    Base.metadata.create_all(pool.motor)
    ConfiguracionGlobal.instancia().restablecer_valores_por_defecto()
    yield


@pytest.fixture
def uow(pool):
    unidad = UnidadDeTrabajoSql(pool.nueva_sesion())
    yield unidad
    unidad.cerrar()


@pytest.fixture
def servicios(uow):
    return construir_servicios(uow)


@pytest.fixture
def demo(servicios):
    """Servicios con los datos de demostración (4 filiales, 16 productos, ~140 ventas)."""
    CargadorDatosDemo(servicios.filiales, servicios.productos, servicios.ventas).cargar()
    return servicios


@pytest.fixture
def cliente(pool):
    from fastapi.testclient import TestClient

    from app.main import crear_app
    preparar_datos(cargar_demo=True)
    with TestClient(crear_app(inicializar=False)) as c:
        yield c


@pytest.fixture
def ruta_temporal() -> Path:
    return Path(tempfile.mkdtemp(prefix="serf-", dir=_TMP))
