"""Modelo de dominio: encapsulamiento, validaciones y reglas de negocio."""
from dataclasses import FrozenInstanceError
from datetime import date, timedelta
from decimal import Decimal

import pytest

from app.dominio import (Categoria, Dinero, Filial, MetodoPago, Moneda, Producto, StockInsuficienteError, Venta)


def producto(**cambios):
    datos = dict(codigo="pe-smp-002", nombre="Smartphone X", descripcion_tecnica="6.7\"", categoria=Categoria.SMARTPHONE,
                 costo_importacion=Dinero(980, Moneda.CNY), precio_venta_sugerido=Dinero(999, Moneda.PEN),
                 proveedor="Xiaomi", fecha_importacion=date(2025, 12, 15), codigo_filial="pe", stock_inicial=100)
    datos.update(cambios)
    return Producto(**datos)


class TestDinero:
    def test_redondeo_exacto_sin_float(self):
        assert Dinero("0.1", Moneda.EUR) + Dinero("0.2", Moneda.EUR) == Dinero("0.3", Moneda.EUR)
        assert Dinero("10.555", Moneda.EUR).monto == Decimal("10.56")

    def test_no_mezcla_monedas(self):
        with pytest.raises(ValueError, match="sin convertirlos"):
            Dinero(1, Moneda.EUR) + Dinero(1, Moneda.PEN)

    def test_es_inmutable(self):
        with pytest.raises(AttributeError):
            Dinero(1, Moneda.EUR).monto = Decimal(2)


class TestFilial:
    def test_normaliza_y_valida_codigo(self):
        assert Filial("pe", "FinanCorp Perú", "Perú", "Lima", Moneda.PEN).codigo == "PE"
        with pytest.raises(ValueError, match="2 o 3 letras"):
            Filial("PERU", "x", "x", "x", Moneda.PEN)

    def test_sin_setters(self):
        with pytest.raises(AttributeError):
            Filial("PE", "x", "x", "x", Moneda.PEN).codigo = "ES"


class TestProducto:
    def test_normaliza_codigos(self):
        p = producto()
        assert p.codigo == "PE-SMP-002" and p.codigo_filial == "PE" and p.stock == 100

    def test_stock_solo_cambia_con_reglas(self):
        p = producto()
        p.descontar_stock(30)
        assert p.stock == 70
        with pytest.raises(StockInsuficienteError) as error:
            p.descontar_stock(71)
        assert error.value.disponible == 70 and p.stock == 70
        p.reponer_stock(5)
        assert p.stock == 75
        with pytest.raises(AttributeError):
            p.stock = 1000

    @pytest.mark.parametrize("cambio,mensaje", [
        ({"costo_importacion": Dinero(0, Moneda.CNY)}, "costo"),
        ({"precio_venta_sugerido": Dinero(-1, Moneda.PEN)}, "precio"),
        ({"stock_inicial": -1}, "negativo"),
        ({"fecha_importacion": date.today() + timedelta(days=1)}, "futura"),
        ({"nombre": "  "}, "nombre"),
    ])
    def test_validaciones(self, cambio, mensaje):
        with pytest.raises(ValueError, match=mensaje):
            producto(**cambio)

    def test_stock_bajo(self):
        assert producto(stock_inicial=10).stock_bajo and not producto(stock_inicial=11).stock_bajo


class TestVenta:
    def venta(self, **cambios):
        datos = dict(numero_factura="fpe-1", fecha=date(2026, 10, 1), codigo_producto="PE-SMP-002",
                     nombre_producto="Smartphone X", categoria=Categoria.SMARTPHONE, codigo_filial="PE", cantidad=100,
                     precio_unitario=Dinero(999, Moneda.PEN), cliente="Cliente", vendedor="Ana",
                     metodo_pago=MetodoPago.TARJETA, total_corporativo=Dinero("24666.67", Moneda.EUR),
                     tasa_aplicada=Decimal("4.05"), costo_importacion_corporativo=Dinero("12531.97", Moneda.EUR))
        datos.update(cambios)
        return Venta(**datos)

    def test_calculos_e_inmutabilidad(self):
        v = self.venta()
        assert v.numero_factura == "FPE-1"
        assert v.total_local == Dinero(99900, Moneda.PEN)
        assert v.margen_corporativo == Dinero("12134.70", Moneda.EUR)
        with pytest.raises(FrozenInstanceError):
            v.cantidad = 1

    @pytest.mark.parametrize("cambio", [{"cantidad": 0}, {"fecha": date.today() + timedelta(days=1)},
                                        {"cliente": ""}, {"precio_unitario": Dinero(0, Moneda.PEN)}])
    def test_validaciones(self, cambio):
        with pytest.raises(ValueError):
            self.venta(**cambio)


@pytest.mark.parametrize("enum,texto,esperado", [(Moneda, " pen ", Moneda.PEN), (Categoria, "laptop", Categoria.LAPTOP),
                                                  (MetodoPago, "Transferencia", MetodoPago.TRANSFERENCIA)])
def test_enums_desde_texto(enum, texto, esperado):
    assert enum.desde_texto(texto) is esperado


def test_enums_con_mensaje_claro():
    with pytest.raises(ValueError, match="Moneda no soportada: GBP"):
        Moneda.desde_texto("GBP")
    with pytest.raises(ValueError, match="obligatori"):
        Categoria.desde_texto("")
