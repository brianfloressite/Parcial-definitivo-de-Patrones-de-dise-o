"""Patrón Singleton: ConfiguracionGlobal (configuración corporativa) y PoolConexiones (pool de MySQL)."""
import copy
import pickle
import threading
from decimal import Decimal

import pytest

from app.config.configuracion_global import ConfiguracionGlobal
from app.dominio import Dinero, Moneda, OperacionNoValidaError
from app.persistencia.pool_conexiones import PoolConexiones
from conftest import URL_PRUEBAS


class TestConfiguracionGlobal:

    def test_punto_de_acceso_unico(self):
        assert ConfiguracionGlobal.instancia() is ConfiguracionGlobal.instancia()
        assert ConfiguracionGlobal() is ConfiguracionGlobal.instancia()   # el constructor no crea otra

    def test_una_sola_instancia_con_50_hilos_simultaneos(self):
        ids, barrera = set(), threading.Barrier(50)

        def obtener():
            barrera.wait()
            ids.add(id(ConfiguracionGlobal.instancia()))

        hilos = [threading.Thread(target=obtener) for _ in range(50)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()
        assert len(ids) == 1

    def test_no_se_duplica_por_copia_ni_serializacion(self):
        config = ConfiguracionGlobal.instancia()
        assert copy.copy(config) is config
        assert copy.deepcopy(config) is config
        with pytest.raises(TypeError):
            pickle.dumps(config)

    def test_un_cambio_se_ve_desde_cualquier_referencia(self):
        a, b = ConfiguracionGlobal.instancia(), ConfiguracionGlobal()
        a.actualizar_tasa(Moneda.PEN, "4.20")
        assert b.tasa(Moneda.PEN) == Decimal("4.200000")

    def test_tasas_expuestas_son_de_solo_lectura(self):
        with pytest.raises(TypeError):
            ConfiguracionGlobal.instancia().tasas[Moneda.PEN] = Decimal(1)

    @pytest.mark.parametrize("moneda,valor,mensaje", [
        (Moneda.EUR, "2", "fija"), (Moneda.PEN, "0", "mayor que cero"),
        (Moneda.PEN, "-1", "mayor que cero"), (Moneda.PEN, "abc", "número"),
    ])
    def test_actualizar_tasa_valida(self, moneda, valor, mensaje):
        with pytest.raises(ValueError, match=mensaje):
            ConfiguracionGlobal.instancia().actualizar_tasa(moneda, valor)

    def test_formato_numerico_corporativo(self):
        config = ConfiguracionGlobal.instancia()
        assert config.formatear(Dinero("1234567.891", Moneda.EUR)) == "€ 1,234,567.89"
        assert config.formatear(Dinero("2199000", Moneda.COP)) == "COL$ 2,199,000"

    def test_marca_de_agua_valida_longitud(self):
        config = ConfiguracionGlobal.instancia()
        with pytest.raises(ValueError):
            config.texto_marca_agua = "x" * 61
        config.texto_marca_agua = "  SOLO GERENCIA  "
        assert config.texto_marca_agua == "SOLO GERENCIA"

    def test_nota_legal_por_pais_y_consolidada(self):
        config = ConfiguracionGlobal.instancia()
        assert "Perú" in config.nota_legal("pe")
        assert "todas las filiales" in config.nota_legal(None)


class TestPoolConexiones:

    def test_es_unico_y_comparte_un_solo_motor(self, pool):
        assert PoolConexiones.instancia() is pool is PoolConexiones()
        s1, s2 = pool.nueva_sesion(), pool.nueva_sesion()
        try:
            assert s1 is not s2                       # una sesión por petición…
            assert s1.get_bind() is s2.get_bind() is pool.motor   # …sobre el mismo pool
        finally:
            s1.close()
            s2.close()

    def test_no_se_puede_reapuntar_a_otra_base_sin_cerrarlo(self, pool):
        assert pool.inicializar(URL_PRUEBAS) is pool  # misma URL: no hace nada
        with pytest.raises(OperacionNoValidaError):
            pool.inicializar("sqlite+pysqlite:///otra.db")

    def test_estadisticas_y_conexion(self, pool):
        datos = pool.estadisticas()
        assert datos["identidadInstancia"] == id(pool)
        assert datos["motor"] in {"mysql", "sqlite"}
        assert pool.version_servidor()

    def test_tampoco_se_duplica_por_copia(self, pool):
        assert copy.deepcopy(pool) is pool
