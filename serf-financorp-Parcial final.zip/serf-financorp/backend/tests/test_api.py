"""API REST (FastAPI): contrato JSON, códigos HTTP y mensajes de error."""
import pytest


def test_listados_principales(cliente):
    assert len(cliente.get("/api/filiales").json()) == 4
    productos = cliente.get("/api/productos", params={"filial": "PE"}).json()
    assert len(productos) == 4 and {"costoCorporativo", "stockBajo", "monedaLocal"} <= set(productos[0])
    assert cliente.get("/api/ventas").json()[0]["monedaCorporativa"] == "EUR"


def test_panel(cliente):
    d = cliente.get("/api/dashboard", params={"anio": 2026}).json()
    assert d["filiales"] == 4 and d["ventasAnio"] > 100 and d["etiquetaUltimoMes"] == "Octubre 2026"


def test_registrar_producto_y_venta(cliente):
    r = cliente.post("/api/productos", json={
        "codigo": "PE-LAP-099", "nombre": "Laptop prueba", "descripcionTecnica": "i5", "categoria": "LAPTOP",
        "costoImportacionCny": 3910, "precioVentaSugerido": 3500, "proveedor": "Huawei",
        "fechaImportacion": "2026-01-10", "codigoFilial": "PE", "stockInicial": 5})
    assert r.status_code == 201 and r.json()["costoCorporativo"] == 500.0
    v = cliente.post("/api/ventas", json={
        "numeroFactura": "FPE-T1", "fecha": "2026-10-20", "codigoProducto": "PE-LAP-099", "cantidad": 2,
        "precioUnitario": 4050, "cliente": "Cliente", "vendedor": "Ana", "metodoPago": "EFECTIVO"})
    assert v.status_code == 201 and v.json()["totalCorporativo"] == 2000.0
    assert cliente.get("/api/productos/PE-LAP-099").json()["stock"] == 3


@pytest.mark.parametrize("metodo,ruta,cuerpo,estado,texto", [
    ("get", "/api/productos/NOEXISTE", None, 404, "Producto no encontrado"),
    ("post", "/api/filiales", {"codigo": "PE", "nombre": "x", "pais": "x", "ciudad": "x", "moneda": "PEN"}, 409, "ya se encuentra"),
    ("post", "/api/filiales", {"codigo": "BR", "nombre": "x", "pais": "x", "ciudad": "x", "moneda": "BRL"}, 400, "Moneda no soportada"),
    ("post", "/api/ventas", {"numeroFactura": "F1", "cantidad": "muchas"}, 400, "formato"),
    ("put", "/api/configuracion/tasas/EUR", {"tasa": 2}, 400, "fija"),
    ("post", "/api/reportes", {"tipo": "MENSUAL_INGRESOS", "anio": 2026}, 400, "mes"),
])
def test_errores_claros(cliente, metodo, ruta, cuerpo, estado, texto):
    r = getattr(cliente, metodo)(ruta, json=cuerpo) if cuerpo is not None else getattr(cliente, metodo)(ruta)
    assert r.status_code == estado
    assert texto in r.json()["mensaje"] and r.json()["estado"] == estado


def test_reportes_de_extremo_a_extremo(cliente):
    r = cliente.post("/api/reportes", json={"tipo": "MENSUAL_INGRESOS", "anio": 2026, "mes": 10})
    assert r.status_code == 201
    reporte = r.json()
    assert reporte["firmado"] and reporte["capas"][-1] == "Firma digital"
    assert cliente.get("/api/reportes").json()[0]["id"] == reporte["id"]
    assert cliente.get(f"/api/reportes/{reporte['id']}/verificar").json()["valido"] is True
    assert cliente.post(f"/api/reportes/{reporte['id']}/verificar-alterado").json()["valido"] is False
    assert len(cliente.get("/api/reportes/plantillas").json()) == 3


def test_configuracion_y_conversion(cliente):
    c = cliente.put("/api/configuracion/tasas/PEN", json={"tasa": 4.0}).json()
    assert c["tasas"]["PEN"] == 4.0 and c["identidadInstancia"] == cliente.get("/api/configuracion").json()["identidadInstancia"]
    conv = cliente.get("/api/configuracion/convertir", params={"monto": 400, "moneda": "PEN"}).json()
    assert conv["montoConvertido"] == 100.0


def test_salud_y_cors(cliente):
    s = cliente.get("/api/sistema/salud").json()
    assert s["estado"] == "ok" and s["pool"]["identidadInstancia"]
    r = cliente.get("/api/filiales", headers={"Origin": "http://localhost:5500"})
    assert r.headers["access-control-allow-origin"] == "http://localhost:5500"
