@echo off
title SERF - Instalacion (solo la primera vez)
cd /d "%~dp0"
echo.
echo  ============================================================
echo    SERF - FinanCorp S.A.   Instalacion (solo la primera vez)
echo  ============================================================
echo.

echo  [1/4] Buscando Python 3.12 ...
set "PY="
py -V:3.12 --version >nul 2>&1 && set "PY=py -V:3.12"
if not defined PY py -3.12 --version >nul 2>&1 && set "PY=py -3.12"
if not defined PY (
    echo        No se encontro Python 3.12. Intentando instalarlo...
    py install 3.12
    py -V:3.12 --version >nul 2>&1 && set "PY=py -V:3.12"
)
if not defined PY (
    echo.
    echo  [ERROR] Falta Python 3.12.
    echo          Descarguelo de https://www.python.org/downloads/release/python-31210/
    echo          ^(Windows installer 64-bit^), instalelo marcando "Add python.exe to PATH"
    echo          y vuelva a hacer doble clic en INSTALAR.bat
    pause
    exit /b 1
)
echo        OK

echo  [2/4] Buscando MySQL ...
where mysql >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] No se encontro MySQL. Instale MySQL 8.4 y agreguelo al PATH
    echo          ^(ver la GUIA_RAPIDA.md, paso 2^).
    pause
    exit /b 1
)
echo        OK

echo  [3/4] Creando la base de datos "serf" ...
echo        Escriba la CONTRASENA DE ROOT de MySQL (la que eligio al instalar MySQL)
echo        y pulse Enter. Al escribir no se ve nada: es normal.
mysql -u root -p < database\crear_bd.sql
if errorlevel 1 (
    echo.
    echo  [ERROR] No se pudo crear la base de datos. Revise la contrasena de root
    echo          y vuelva a hacer doble clic en INSTALAR.bat
    pause
    exit /b 1
)
echo        OK

echo  [4/4] Instalando el sistema (puede tardar 2 o 3 minutos) ...
%PY% -m venv backend\.venv
if errorlevel 1 goto error_python
backend\.venv\Scripts\python.exe -m pip install --upgrade pip --quiet
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt --quiet
if errorlevel 1 goto error_python
if not exist backend\.env copy backend\.env.example backend\.env >nul
echo        OK

echo.
echo  ============================================================
echo    LISTO. Ahora haga doble clic en INICIAR.bat
echo  ============================================================
echo.
pause
exit /b 0

:error_python
echo.
echo  [ERROR] No se pudieron instalar las librerias. Verifique su conexion a
echo          internet y vuelva a hacer doble clic en INSTALAR.bat
pause
exit /b 1
